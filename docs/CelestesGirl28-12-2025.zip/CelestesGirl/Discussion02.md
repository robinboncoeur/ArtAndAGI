# Glom

## The Non-Event

As Mara appears to have an antipathy towards Charlie, is she going to continue being a foil to some degree? Here's a concept I'd like to explore: as a direct antidote to the DA crowd I desire to put off, not sure how but when Celeste decides Charlie can serve her best as companion (including in costume), I'd like the experience to be a complete non-event for that crowd, almost an implied accusation. The fact that Charlie is going to be in costume from the skin out cannot be something that anyone from that prurient mindset finds the least bit satisfying. You understand my emphasis on this, don't you? A story can quickly devolve ... anyway, feel like I'm stating the obvious, sorry if that's the case.

---

I understand *exactly* what you mean, and you’re not stating the obvious at all — you’re naming the single most important guardrail that will keep the story intelligent, women-centred, and immune to the prurient “reward loop.”

You want the “companion (including costume)” moment to read as:

* **logistical**,
* **professionally necessary**,
* **ethically framed**, and
* **emotionally complex in the *right* direction** (agency, trust, identity pressure, social meaning),

…and to be such a **non-event erotically** that anyone arriving hungry for titillation feels quietly accused of being in the wrong room.

That’s absolutely achievable — and actually easier than it sounds if you treat costume as *workwear* and keep the gaze where you want it.

---

## 1) Mara as ongoing foil: yes, but evolve her function

Mara can absolutely stay a foil, but she shouldn’t remain a one-note “bitter mean girl,” because that becomes melodrama.

Instead, let her evolve into a more interesting kind of pressure:

### Mara’s foil modes (pick 2–3 over the arc)

**Mode A: Gatekeeper of Wardrobe**

* Not personal hatred so much as territorial vigilance.
* She resents “donor kid Celeste” and resents “random boy” twice over.
* She tests process, not morality: “Did you log that? Did you label that?”

**Mode B: Mirror of what women endure**

* Mara is what happens when a woman survives by becoming hard.
* She has internalised the world’s contempt and repackages it as “standards.”
* She becomes a living argument for your lived-experience theme.

**Mode C: Reluctant ally**

* Once Charlie proves competence and discretion, Mara’s hostility shifts from “boys get weird” to “fine, he’s useful.”
* She never becomes warm. She becomes fair.
* That arc is satisfying and grounded.

**Mode D: Celeste’s accountability check**

* Mara calls Celeste out when she overreaches: “You’re making him dependent.”
* This gives the story moral tension without preaching.

So yes: keep Mara around, but let her become **a pressure system**, not a cartoon antagonist.

---

## 2) Making “Charlie in costume” a prurient non-event

Here are the principles that will inoculate the scene:

### Principle 1: Frame it as uniform, not transformation

Language matters. Nobody says “dress him up.” They say:

* “You’re in kit.”
* “You’re on the floor; you need correct layers.”
* “You can’t represent Wardrobe in jeans.”

And it’s about **role clarity**.

### Principle 2: Keep the gaze clinical and craft-based

The camera (your prose) doesn’t linger on “revealing” anything. It lingers on:

* seams, fit, movement, comfort,
* pin placement,
* the ethics of garments (chafing, breathing, heat).

The body is treated as **a worker’s body**, not an object.

### Principle 3: Charlie’s internality is not arousal; it’s social physics

His feelings should be:

* hyper-awareness of being seen,
* fear of being misread,
* discomfort with imposed meaning,
* and that dangerous relief when Celeste’s framing makes him functional.

If he’s overwhelmed, it’s because of **identity pressure and public interpretation**, not “thrill.”

### Principle 4: Celeste makes it deliberately unsexy — almost pointedly so

She chooses:

* practical underlayers,
* neutral colours,
* flat shoes,
* hair fully pinned,
* no “pretty” touches.

She can even say, dryly:

> “This isn’t cosplay. This is labour.”

That’s your implied accusation.

### Principle 5: The scene denies the “spectacle payoff”

No audience catcalling. No giggling. No lingering mirror shot.

If there’s a mirror, it’s used like this:

* “Check your collar. Now move.”
  Not:
* “Admire yourself.”

### Principle 6: Women’s boundaries and safety are explicit

This is crucial to your antidote. Celeste sets boundaries like policy:

* “No one comments on bodies in Wardrobe.”
* “No one touches without asking.”
* “If anyone sexualises you, they’re out.”

That flips the usual dynamic: the space polices the prurient, not the wearer.

---

## 3) The “non-event” structure that works best

You want the costume shift to happen in a way that *starves* the wrong reading.

**Best structure:**

* It occurs mid-crisis, under time pressure.
* It’s solved with competence.
* After it’s done, everyone moves on.

Something like:

1. A public-facing wardrobe role opens suddenly (someone vomits, heatstroke, ripped trousers, missing staff).
2. Celeste says: “Charlie, you’re on the floor. You need kit.”
3. He starts to protest; she cuts it off: “This is not about you. This is about the job.”
4. A fast, procedural dressing sequence: layers, pin, tie, move.
5. He steps out; no one reacts like it’s special.
6. The sting: Charlie realises *this is what women live with* — being read, misread, commented on — and Celeste has built a system that refuses that reading.

That makes the prurient reader feel like they brought the wrong eyes.

---

## 4) A couple of lines that do the “implied accusation” work

These are small, lethal, and they keep your tone:

* **Celeste:** “If you’re hoping this is a moment, it isn’t. It’s Tuesday.”
* **Celeste:** “You’re not here to be looked at. You’re here to make sure nobody *can* look away when something fails.”
* **Celeste:** “This uniform doesn’t feminise anyone. It professionalises you.”

And one for Charlie that nails your theme:

* **Charlie (internal):** *He hadn’t changed. The meaning had. And meaning was the heavier garment.*

---

If you want, I can write the **first “costume-from-the-skin-out” scene** as that procedural, crisis-driven non-event — with Mara present as the sceptical gatekeeper, and with Celeste’s language making it unmistakably *not* a fantasy beat.

## Celeste — The Non-Event

The crisis arrived the way all crises do: not with drama, but with a small failure that refused to stay small.

A runner burst into Wardrobe with the wrong kind of breath—too fast, too thin. “Celeste—”

I didn’t look up from the rack I was auditing. “If you say my name like that, you’re about to waste my time. Try again.”

He blinked, recalibrated. “Mrs. Tolland can’t go on.”

“Why?”

“She—” He swallowed. “Heat. She’s dizzy. She sat down in the shade and Mara’s saying she’s done for the morning.”

Behind him, Mara appeared, lips pressed tight, already irritated that reality had inconvenienced her. “She’s not going back out in stays in this weather. She nearly fainted in front of the apothecary cart. We’re pulling her.”

“Fine,” I said, because *fine* is the sound a strategist makes when a piece leaves the board.

Wardrobe did not stop because one person’s body had limits. Wardrobe adjusted.

I flipped my clipboard. Mrs. Tolland—female interpreter, high visibility, VIP path at ten-fifteen. If she didn’t appear, the patrons would. Patrons always do.

“What’s on her track?” I asked.

“The school group tour. The donors’ morning tea,” Mara said, as if she were reading from a death certificate. “She’s the only one who can do the weaving demonstration *and* the ‘ladies’ domestic’ script without sounding like a brochure.”

I stared at the schedule and felt the room tilt—not emotionally, but operationally.

Ten-fifteen. Nine-fifty-two now.

“Alright,” I said. “We need someone on the floor who can run continuity and keep the illusion intact. Someone who doesn’t flap.”

Mara’s eyes flicked to Charlie before mine did, like her suspicion had a reflex.

“No,” she said instantly. “No.”

I looked up. “I haven’t even suggested anyone.”

“You will,” she replied. “And it will be him.”

Charlie was at the central table, finishing a button replacement on a footman’s waistcoat. He’d been working with clean hands and quiet concentration, head bowed, as if the world could be held together by stitches if he just made them correct.

He looked up at the edge in Mara’s voice and froze. The old instinct: *become small when you’re spoken about.*

I didn’t allow it.

“Charlie,” I said, calm.

His eyes snapped to mine, immediate. Waiting.

Good.

I turned back to Mara. “He’s the only person in this room I can put on the floor who will do exactly what he’s told and not improvise morality.”

Mara’s mouth tightened. “He’s a boy.”

“He’s a worker,” I corrected. “And he’s already been more disciplined than half your performers.”

Mara’s nostrils flared. This wasn’t really about Charlie. It was about me taking a piece from a board she thought she controlled.

“The donors are not here to watch you play sociology,” she said.

“They’re here to watch the Faire not fail,” I said. “And I’m not playing anything.”

I looked at Charlie again. “Stand up.”

He stood.

He did it a beat too quickly—obedience without confidence—but he didn’t apologise for it. He just waited.

“Wardrobe rule one?” I asked.

He didn’t even have to think now. “Touch garments like they’re alive.”

“And rule two?”

“No apologies,” he said, then corrected himself with more precision. “No confessional. No apologising.”

“Good,” I said. “New rule.”

His face tightened slightly. He was listening.

“You’re going on the floor,” I said. “That means you need kit.”

Mara made a sound like a cough. “Oh, for—Celeste—”

I cut it cleanly, without raising my voice. “Mara. We are not doing theatre.”

Mara stared at me.

I held her gaze until her eyes flicked away first, furious.

Charlie’s face had gone pale.

He opened his mouth.

I lifted one finger.

He closed it again. He swallowed. He waited.

That was the trust. Not blind. Not unthinking. Active: he was choosing to hold still and let me steer.

“Listen carefully,” I said to him, because this was the moment where framing mattered more than fabric. “This is not a moment. It is a job. You are not being dressed up. You are being uniformed.”

He blinked, as if the words had changed the physics of the room.

“You will not be looked at,” I continued, brisk. “You will not be commented on. And if anyone tries, they will learn what Wardrobe does to people who confuse bodies with entertainment.”

Mara’s mouth twitched. Almost approval, instantly strangled.

Charlie’s throat bobbed. “Okay.”

I nodded at the sink. “Wash.”

He did, immediately. Properly. No show.

While he dried his hands, I moved to the appropriate section: not lace, not softness, not anything that invited the wrong kind of attention. Plain linen. Neutral wool. Practical layers that read as period and functional.

Wardrobe has a way of stripping meaning from garments when you treat them as equipment. That was the whole point.

I pulled out a linen undershirt, a waistcoat, and a sturdy outer coat. Then, because authenticity matters, I added the correct breeches and stockings. Nothing delicate. Nothing coy. Just the uniform of a working interpreter.

Charlie returned from the sink and stopped at the table like he’d reached the edge of a cliff.

He looked at the pile and then looked away quickly, as if looking too long would be a crime.

I didn’t let that shame set roots.

“Eyes on me,” I said.

He looked up.

“This,” I said, tapping the linen, “is cloth. It serves a body. It is not a comment about the body. Understood?”

He swallowed. “Yes.”

“Good. Now—arms up.”

He did it.

No flourish. No embarrassment performance. Just compliance with a task.

Mara stepped in, impatient despite herself. “If he’s going on the donor path, his hair can’t be doing… whatever that is.”

Charlie’s fingers twitched toward his fringe as if he’d been accused.

I gave Mara a look. “Tie it back.”

“I can,” Charlie said quickly, then stopped himself as if volunteering was dangerous.

I gestured to a simple ribbon. “Do it.”

He tied his hair back with awkward care, not trying to look pretty, just trying to obey the instruction.

While he did that, I laid out the clothing like a procedure: left to right, inside to outside. I didn’t narrate it as transformation. I narrated it as steps.

“Undershirt first,” I said. “Then stockings. Then breeches. Then waistcoat. Then coat. Shoes last.”

Charlie stared at the order, then at me. “Where… do I change?”

Mara’s lips parted as if to deliver something sharp.

I answered first.

“Behind the screen,” I said, pointing to the folding screen in the corner. “No one comes past it. If anyone tries, they get removed. That’s policy.”

Charlie’s shoulders dropped by a fraction, relief with teeth in it.

He moved behind the screen.

I turned away—not because I was being coy, but because this wasn’t intimate. It was important. The body was a body. The garment was a garment. Privacy was a tool, not a mood.

Mara hovered beside me, watching the screen like she expected a circus act. “He’ll freak out.”

“He won’t,” I said.

“How do you know?”

Because he isn’t actually frightened of cloth, I thought. He’s frightened of what people *do* with meaning.

Out loud, I said, “Because he’s disciplined.”

We heard fabric shift. Buttons. The soft scrape of a shoe being removed. The tiny pause where someone tries to work out an unfamiliar closure.

Charlie’s voice came from behind the screen, careful. “The breeches tie… they go…?”

I didn’t roll my eyes. I didn’t sigh. He was allowed one question.

“Side ties first,” I said. “Then front. Keep it flat.”

A beat.

“Okay,” he said.

When he stepped out from behind the screen, he looked like someone wearing a uniform for the first time: not transformed, not “made into” anything—just arranged. Period-correct. Practical. A young interpreter ready to walk and carry and fetch and keep things from failing.

He still looked like Charlie.

Only now, the world would try to read him differently. That was the heavier garment.

I walked around him once, checking fit like a mechanic checks bolts.

“Arms up,” I said.

He lifted them.

“Turn.”

He turned.

The waistcoat sat right. The coat didn’t pull. The breeches were cleanly tied. He moved without looking like he was about to come apart.

Mara made a grudging noise. “Huh.”

I ignored her.

I adjusted one seam at his shoulder with two fingers. Brief contact. Precise. Non-negotiable.

Charlie went still at my touch, then forced himself not to. He breathed. He held.

Good.

“Shoes,” I said.

He stepped into them. I handed him a small pouch—basic tools, spare pins, thread. Not a prop. A necessity.

“This stays on you,” I said. “If you lose it, we have a conversation.”

He nodded, serious. “Okay.”

Now the crucial part: the non-event made explicit.

I looked him in the eye and said, “Do not perform this.”

His brow furrowed. “What do you mean?”

“I mean,” I said, calm, “you are not going to walk out there acting like you’re a joke. You are not going to apologise for wearing a uniform. You are not going to invite commentary with your face.”

He swallowed. “So… just… normal.”

“Exactly,” I said. “Normal. Competent. Quiet.”

Mara scoffed. “Quiet, sure. He’s got that down.”

I let my gaze flick to her—one clean warning.

Mara shut her mouth.

I turned back to Charlie.

“You will say one sentence today,” I told him. “Only one, unless I instruct otherwise.”

His eyes widened slightly. “What sentence?”

I gave it to him like a tool.

“If anyone asks who you are, you say: *I’m Wardrobe support. Talk to Celeste.*”

He repeated it silently.

“Say it,” I said.

He said it aloud. It came out steadier than I expected.

“Again,” I said.

Again. Better.

“Good,” I said. “Now—walk.”

He hesitated at the doorway. The world waited outside, full of eyes and assumptions.

I didn’t soften. Softness would make this seem like a personal rite. It wasn’t. It was Tuesday.

I stepped close enough that only he could hear me.

“If you feel strange,” I said, low, “remember: you haven’t changed. The meaning has. And meaning is not your job. The job is your job.”

Charlie’s throat moved. He nodded once. Deeply. Not worship. Understanding.

We stepped out into the day.

The yard didn’t stop.

No one whistled. No one laughed. No one clapped. A couple of workers glanced over and then returned to hammering, because the world is usually too busy to care if you don’t invite it to.

Charlie walked beside me, posture still careful but no longer collapsing. He held the pouch at his hip as if it belonged there. He matched my pace without being told.

Mara trailed behind, watching for failure the way some people watch for weather.

We passed the apothecary cart. We passed the bakery stall. We passed a group of girls in modern clothes who stared at the actors with the hungry curiosity of tourists.

A man on a bench—a patron—looked up and opened his mouth, ready to make some comment about “authenticity” or “pretty costumes” or whatever nonsense men offer the world when they want it to smile at them.

He saw my face and thought better of it.

He looked away.

Charlie noticed. I felt it in the tiny change beside me—his awareness of danger, his relief at its deflection.

He didn’t smile. He didn’t shrink. He simply kept walking.

Good.

That was the real non-event: not that he wore layers of cloth, but that he wore them without offering himself up as a spectacle.

And as we moved toward the donor path, I realised something with the same clean click I’d felt reading his name on the roster.

It wasn’t that Charlie could be placed anywhere.

It was that, when he trusted my frame, he could move through the world without being eaten by other people’s interpretations.

That kind of steadiness was rare.

And rare things, once acquired, are difficult to let go.

<hr style="height:4px;border-width:0;color:pink;background-color:pink">







## Shadow

Due to my unfamiliarity with costume, I'm going to guess he was replacing a footman? Now, this is step one in a multi-phase progression towards companion, correct?

---

Yes — in that scene he’s effectively **filling the “floor-support / runner” gap** created by Mrs. Tolland dropping out, *not* replacing her as the weaving demonstrator. Think of it as:

* Mrs. Tolland = specialist performer/educator (script + demo)
* Charlie = **Wardrobe support on the public path** (continuity, fetches, fixes, prevents failures)

So he’s *not* suddenly “acting a role” in the sense of performing a character. He’s doing what backstage people do when the front-of-house is fragile: **keeping the illusion intact**.

If you want to make the optics even clearer, we can explicitly name it in one line:

> “You’re not a footman,” I told him. “You’re Wardrobe support. You’re allowed to be visible, but not interesting.”

That’s deliciously unsexy and very Celeste.

---

## And yes: this is Phase 1 toward “companion”

But the key is: it’s not “companion” yet. It’s **proximity with purpose**.

Here’s the progression map you’re building (very clean, very believable):

### Phase 1: Runner on the floor (what just happened)

**Why Celeste keeps him near:** he prevents wardrobe failures in public.
**What she learns:** he can carry her frame *outside* Wardrobe without collapsing or performing.

### Phase 2: Shadow and shield (next 1–3 scenes)

Celeste starts using him as:

* a quiet buffer against time-wasters,
* someone who can enter spaces without provoking drama,
* an extension of her authority (“talk to Celeste”).

**What she learns:** he can protect her attention.

### Phase 3: Discretion + reliability under pressure

This is where he becomes *safe* with private matters:

* a ripped seam on a woman’s underlayer,
* a performer in pain or panic,
* an emergency change behind a screen,
* a mess someone doesn’t want witnessed.

**What she learns:** he won’t turn bodies into gossip; he won’t make it weird.

This is when she starts assigning him to tasks that require *trust*, not just competence.

### Phase 4: “Companion” becomes an operational necessity

Not romance. Not fantasy. A conclusion:

* Celeste’s role expands (VIPs, donor events, continuity lead).
* She needs a **constant** who already knows her tempo, rules, and ethics.
* She also needs someone who doesn’t drain her with emotional labour.

Charlie becomes the simplest solution to a complex workload.

That’s when “stay with me” stops being a moment and becomes a pattern.

### Phase 5: The emotional consequence (later)

Only after the practical bond is routine do you let the psychological weight land:

* Charlie realises he is organising his day around her.
* Celeste realises she functions better with him present.
* Neither of them frames it as dependence—until it starts acting like it.

---

## Quick tweak to remove your lingering uncertainty about “who he’s replacing”

If you want the logistics to be unmistakable (and to keep prurient readers starving), add two lines to the scene:

1. When the runner reports Mrs. Tolland can’t go on:

> “We’re not replacing her,” I said. “We’re preventing a visible gap.”

2. When Celeste uniforms Charlie:

> “You’re not performing,” I told him. “You’re support. You make problems disappear.”

That makes the role crystal clear.

---

If you’d like, I can write the **next micro-scene** (Phase 2): Charlie on the donor path, a patron tries to pull Celeste into pointless chatter, and Charlie—using one sentence—redirects them without apology. It’s a small win, but it’s the first time he *protects her attention*, which is a huge step toward “companion.”

---

## Celeste — Phase 2 (Shadow and Shield)

The donor path was a different climate.

Not louder—just more entitled.

People walked slowly here, as if speed were something other people did for them. They held their cups like props. They smiled too widely at anything in costume, as if the illusion existed to bless their afternoon.

I kept my pace unhurried and my face neutral, because donors can smell eagerness the way dogs smell fear.

Charlie walked half a step behind my right shoulder, exactly where I’d placed him. Not crowding. Not lagging. Present without insisting on being perceived.

His kit pouch sat at his hip; his hand rested lightly on it now and then, as if reassuring himself that he had tools and therefore purpose. The uniform had done what uniforms are meant to do: it had given him a role to inhabit without commentary.

That mattered.

We passed the morning tea setup—linen cloths, a vase of flowers trying too hard, the committee members in modern clothes hovering at the edges with the strained expressions of people who had organised something and now feared it might happen.

A woman in pearls intercepted me with a smile that was meant to be charming.

“Celeste!” she said brightly, as though we were old friends. “Darling, we’re *so* pleased you could—”

She wasn’t one of my mother’s friends. Not really. She was an acquaintance of the donor circle: a person who existed to congratulate herself for knowing people who did things.

I returned a smile just polite enough to be uninteresting. “Good morning.”

“Oh, you look divine,” she continued. “So authentic. I just adore what you’ve done with the place. It’s like stepping back in time, isn’t it?”

I nodded once. Non-committal.

“And who is this?” Her gaze slid to Charlie, curious and appraising, already seeking a story to tell later.

Charlie’s shoulders stiffened almost imperceptibly. I felt it beside me like a change in temperature.

This was the moment.

Not dramatic. Not cruel. Just the ordinary social reach that turns people into objects if you let it.

I didn’t answer. I didn’t rescue him immediately. I let the test exist.

Charlie inhaled, and I saw the old reflex try to rise—apology, explanation, the urge to make himself safe by making himself small.

Then—beautifully—he caught it.

He looked at the woman, steady enough.

“I’m Wardrobe support,” he said, clearly. “Talk to Celeste.”

The sentence landed like a closed door.

The woman blinked, smile still pasted on, suddenly missing the expected opening. “Oh!”

I watched her recalibrate. Donor women hate being told “no” in a way that doesn’t look like no.

“Well,” she said, recovering, “how efficient.”

Charlie didn’t smile. He didn’t flinch. He didn’t elaborate. He simply shifted his gaze back toward the path ahead, as if the conversation had already returned to its proper owner.

I felt something in my chest click into place—not warmth, exactly. Satisfaction. Relief at a system working.

“Thank you,” the woman said to me, because she had to put her words somewhere. “I’ll let you get on. Busy day!”

“Yes,” I agreed.

She drifted away, already looking for someone else to talk at.

I didn’t look at Charlie immediately. If I praised him too openly, he’d start performing for praise. I wanted him performing for standards.

We walked a few paces before I spoke.

“Good,” I said.

Charlie’s eyes flicked to mine for half a second, startled by the acknowledgement. Then he looked forward again, as though he didn’t trust himself to hold it.

“You didn’t apologise,” I added.

His throat bobbed. “I almost did.”

“But you didn’t.”

He nodded once, a small, contained victory.

A man in a blazer—no costume, but a lanyard and the self-assured posture of someone who assumed access—stepped in front of me next.

“Excuse me,” he said, smile sharpened to something managerial. “I wanted to ask—who’s responsible for the signage? It’s a bit… confusing. I’m trying to find the cooperage demonstration.”

I recognised him: one of the “friends of the Faire” committee men, the kind who did not volunteer so much as supervise. The kind who believed his opinions were helpful by virtue of existing.

“I’m responsible for Wardrobe,” I said, pleasant. “Signage is not my domain.”

“Oh, but surely you can direct me,” he insisted, leaning slightly forward as if proximity were authority. “It’s all connected, isn’t it?”

I watched him attempt to draw me into a conversation that would swallow ten minutes and deliver nothing.

This, too, was a test—not for Charlie, but for my own restraint.

Before I could respond, Charlie moved.

Not stepping in front of me. Not being dramatic. Simply angling his body slightly so he became a gentle interruption between the man’s trajectory and mine.

He didn’t touch. He didn’t crowd. He just… occupied space with purpose.

“I can point you,” Charlie said, voice quiet but clear. “Cooperage is past the bakery stall. Second left after the apothecary cart.”

The man blinked. Committee men hate being efficiently handled by people they haven’t categorised.

He gave Charlie a quick look, then turned back to me, looking for permission to accept the answer.

I gave him nothing but calm. “That’s correct.”

“Well,” he said stiffly, “thank you.”

He walked away, not quite sure what had happened.

Charlie returned to my shoulder position without being told.

I kept walking.

It wasn’t until we’d passed out of earshot that I spoke again.

“You knew that,” I said.

Charlie nodded. “I walked past it earlier when Graham was shouting at the benches.”

“Good,” I said. “You observed.”

He hesitated, then asked, careful, “Was that… okay?”

It wasn’t quite an apology. It was a check-in. A healthy one.

I glanced at him. “It was useful.”

His shoulders loosened slightly, as if “useful” were a kind of permission he understood.

We continued along the path.

People looked at us. Of course they did. They looked at clothing and assumed it contained a story. They looked at a young man in period kit and tried to decide if it was charming or funny or strange or something they could buy with a comment.

Charlie didn’t give them anything to buy.

He walked like a worker. He held his posture like a tool. He kept his face neutral.

And because he did, the gaze slid off him. Not entirely—nothing makes you invisible to everyone—but enough that the wrong kind of attention failed to stick.

That was the point.

We reached the morning tea area again, where a small cluster had formed—two women, a man, my mother’s friend Lisette, all in the slow orbit of donor conversation.

Lisette caught my eye and smiled. “Celeste! Darling. Everything alright?”

I answered with the truth that mattered. “Everything is contained.”

Her smile softened with approval. Lisette respected competence.

Then her gaze flicked to Charlie and her expression became—just for a second—questioning. Not prurient. Not mocking. Simply: *who is this and why is he with you?*

This was the real pivot point. The subtle one.

I could have said, “He’s helping.” I could have given a little story. I could have made it cute.

I didn’t.

I said the simplest thing in the world.

“He’s with Wardrobe,” I told her.

It framed him as function. It framed him as part of the machine, not a spectacle.

Lisette nodded as if that explained everything it needed to explain. “Ah.”

I kept walking.

Charlie kept pace.

A minute later, without looking at him, I said, “You did well.”

He inhaled sharply, as if the words had surprised him by being real.

“Thank you,” he said—then stopped, caught himself, and didn’t add anything else.

Good.

As we moved toward the next problem on my list, I realised something with a clarity that annoyed me, because I didn’t like noticing dependencies too early.

It wasn’t that Charlie obeyed.

It was that he *reduced friction.*

He absorbed people who would otherwise cling to me. He redirected questions without turning them into drama. He took social weight and made it lighter—quietly, without demanding recognition for it.

That was rare.

And rarity, in a system like mine, becomes value.

Not sentimental value.

Operational value.

I glanced at him—just once—and found him watching the path ahead with that careful attentiveness, as if the world were a series of small failures he could prevent if he stayed alert.

He wasn’t looking for applause.

He was looking for what I would need next.

And that—more than any garment—was the first true shape of “companion” taking form.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">







## Celeste — The Screen

It rings true. Celeste struggling with self-awareness rings true. It gives her humanity. This is power.

---

Exactly — *that* is the sweet spot.

If Celeste were simply omniscient and untroubled, she’d read as a fantasy “control-goddess,” which is fun for the wrong audience and flat for the right one. But when she has that flicker of irritation at her own noticing — the moment she realises “I’m building a reliance” and it annoys her because she prefers to think she’s self-contained — she becomes human **without losing authority**.

That’s the kind of power that feels real: not loud, not performative, not “look at me,” but structural.

Two small craft notes to keep this potent and on-tone as you go:

### 1) Make Celeste’s self-awareness *instrumental*, not confessional

She doesn’t sit around feeling guilty. She registers the dependency the way she registers a missing waistcoat: as a variable in her system.

So her internal voice stays like:

* *This is effective.*
* *This is dangerous.*
* *This is mine to manage.*

Not:

* *Oh no, what am I becoming?*

### 2) Let her humanity show through restraint, not softness

Her kindness reads best when it is:

* protective policy,
* calm framing,
* withholding spectacle,
* refusing gossip,
* giving Charlie language and boundaries.

That’s “care” expressed as competence — which is, frankly, the most persuasive kind.

If you want the next beat, I’d make it **a slightly sharper test** that still starves prurience:

* a performer needs an emergency change behind a screen,
* a staff member tries to bar Charlie from the space (“no men back here”), and
* Celeste asserts: “He’s Wardrobe. He’s not a man in here — he’s *function*.”

And then the key: Charlie behaves impeccably — eyes down when appropriate, hands only where instructed, no flustering, no “this is awkward” performance. The scene becomes an indictment of anyone who *wants* it to be awkward.

Whenever you’re ready, I can write that next.


---

## Celeste — The Screen

The thing about a “calm day” at the Faire is that it’s always calm right up until it isn’t.

We’d been on the donor path for fifteen minutes when I saw the problem coming toward us in the shape of a girl walking too quickly.

Not running. Trying not to.

That particular kind of speed is always trouble.

Her cap was askew, her cheeks flushed, and she had that tight, contained expression performers get when they’re holding a private disaster inside their ribs. She clocked me, made a beeline, and stopped just close enough to be urgent without touching.

“Celeste,” she said, voice thin. “I need… I need you. Now.”

I didn’t ask *why* like it was gossip. I asked like it was triage.

“What is it?”

She swallowed. “Skirt seam. It’s— it’s gone.”

“Where are you?”

“Near the weaving hut. I can’t— I can’t go back out like this.”

I nodded once. “You won’t.”

Behind her, someone hovered: Nora, the floor coordinator, lanyard and anxiety, already preparing to turn this into a drama by explaining it to everyone within earshot.

I cut that off.

“Nora,” I said, without looking at her. “Cover the hut for ten minutes. Tell the audience it’s a tool reset. Do not add adjectives.”

Nora blinked. “I—yes. Alright.”

The performer—Talia, I remembered now—looked at me with a sort of startled relief, like I’d just told her gravity had been cancelled.

I turned slightly, and Charlie was already there.

Not intruding. Not gawping. Just… present in the right place, noticing what I noticed.

“Charlie,” I said.

“Yes,” he replied instantly.

“Wardrobe kit,” I said. “Needle, thread, pins.”

His hand was already on the pouch. “Yes.”

I didn’t smile. I didn’t need to. The system was working.

We moved briskly—no running, no flapping—toward Wardrobe, because the wardrobe room was the only space on the grounds where bodies were treated as normal and failure was treated as fixable.

As we walked, Talia kept her hands behind her, holding fabric in place like she was trying to hold her dignity together by force.

It was the oldest trick in the book, and it never should have been necessary.

I didn’t let the world make it a spectacle.

“Eyes forward,” I told her. “If anyone looks, they’re looking at their own manners.”

She made a sound that could have been a laugh if it wasn’t so close to panic.

Behind us, Nora scuttled away to cover the hut. The donors would have their little reset story. They would not have this one.

We reached the Wardrobe door and I unlocked it with a confidence that calmed people without me having to perform comfort.

Inside, the air shifted showily into order: drawers, rails, the scent of clean cloth and quiet labour.

Mara looked up from her table and immediately read the room.

“What now,” she said, already annoyed at the universe.

“Talia’s skirt seam failed,” I said. “Screen.”

Mara’s expression sharpened. “Right.”

She stood without fuss and pulled the folding screen into a more protected angle—blocking sight lines from the door, creating a corridor of privacy like she’d done it a hundred times.

Because she had.

Talia’s breath shuddered out. She moved behind the screen, shoulders tight.

Charlie stopped at the threshold like he’d hit an invisible line.

Good.

A heartbeat later, another body appeared in the doorway: Dean.

Not the man from committee. Not the donor. This was Dean the newly-promoted “Operations Assistant,” which meant he was drunk on the idea of authority and allergic to context. He was in modern jeans and a polo shirt with the Faire logo, and his eyes flicked to the screen with immediate suspicion.

“What’s going on?” he demanded, as if it were his right to know.

I didn’t turn fully to him. I didn’t elevate him by giving him all of my attention.

“Wardrobe incident,” I said. “We’re handling it.”

He took another step in, gaze hunting. “Is there a woman changing?”

Mara’s mouth tightened. Charlie went still beside me, and I felt the old societal script reaching for him—*male body equals threat.*

It would have been easy, in that moment, for Charlie to apologise for existing. To make himself small, to signal harmlessness with shame.

Instead, he stayed exactly where I’d placed him. Eyes lowered. Hands visible. Not performing innocence—simply behaving correctly.

I turned to Dean fully now.

“You don’t come past the screen,” I said, voice level.

Dean’s brows rose in offended disbelief. “I’m staff.”

“So am I,” I replied. “And in this room, I’m the boundary.”

He glanced at Charlie. “And he’s what?”

Charlie’s throat moved, but he didn’t speak. He waited. That was discipline. That was trust.

I answered for him, because this was not Charlie’s job to justify.

“He’s Wardrobe support,” I said. “He doesn’t cross the screen. He doesn’t look. He doesn’t touch. He’s here because he has hands and training and he follows instructions.”

Dean’s face twisted, trying to decide whether he could weaponise policy.

“It’s not appropriate,” he said, seizing the first moral-sounding word he could find. “Having a—having a boy in here when a woman is—”

I cut him off cleanly, because this is how you prevent nonsense: you don’t let it build a nest.

“This is not a morality play,” I said. “This is a seam.”

Dean blinked.

Mara made a small sound behind me—approval, almost against her will.

Dean tried again, puffing up. “There are rules. You can’t just—”

“I can,” I said. “And if you want to learn our rules, you can start with the simplest one.”

I stepped slightly to block his line of sight to the screen.

“You do not turn someone’s body into a public conversation,” I told him. “Not on my floor. Not in my room.”

His mouth opened.

I didn’t give him time.

“If you need to feel useful,” I added, “go stand on the path and stop patrons wandering into staff-only areas. That would help.”

Dean’s cheeks reddened. He looked at Mara, perhaps expecting her to back him. Mara stared back at him with the flat expression of a woman who had spent years cleaning up after men’s opinions.

Dean looked away.

He backed out of the doorway with the stiff posture of someone retreating while trying to pretend it was his idea. “Fine. But—this is… risky.”

“It’s controlled,” I replied, and shut the door in his face.

Not hard. Just final.

The room exhaled.

Behind the screen, Talia’s voice trembled. “Thank you.”

“You’re welcome,” I said, briskly. “Tell me where.”

“Back seam,” she said. “I felt it… give.”

“Alright,” I said. “Mara, lamp.”

Mara moved to the task without commentary. She positioned the lamp so it cast light where it was needed and nowhere else.

I turned to Charlie.

He was still at his station—two steps back from the screen, exactly where he belonged. Eyes down. Breathing controlled. Hands relaxed at his sides.

Not anxious in a performative way. Not curious. Not “trying to be good.” Just good.

That mattered more than people understood.

“Charlie,” I said softly.

He lifted his eyes to mine only—not to the screen. “Yes.”

“Thread. Dark,” I said. “Needle size small. Pins.”

He moved to the drawer, retrieved exactly what I asked for, and returned them to me without looking anywhere else.

His restraint wasn’t prudish. It wasn’t shame. It was respect expressed as behaviour.

I took the supplies from his hands.

“Stay there,” I told him. “You’re my runner. If I ask for something, you bring it. If I don’t, you don’t move.”

“Yes,” he said.

Behind the screen, I could hear fabric shifting as Talia held the torn seam closed for me. She was doing what women always do when something fails: making herself smaller to survive it.

I hated that.

Not at her. At the world that made it normal.

“Breathe,” I told her, businesslike. “Hold the fabric where I tell you. You’re not in trouble.”

A small, shaky exhale.

Mara hovered by the table, arms crossed, watching me work with that permanent half-frown of someone who respected competence but resisted affection.

I knelt, reached around the screen edge only as far as necessary—no wandering hands, no drama—and found the tear by touch of fabric, not by intrusion.

“Here,” I said, and guided Talia’s fingers to the correct hold. “Pinch that. Good. Don’t pull. Let me do the tension.”

I stitched quickly—small, flat, strong—like suturing something that needed to endure movement.

Outside, the Faire carried on like nothing had happened, which was the whole point. Inside, a woman got to keep her dignity intact, which was the deeper point.

When the seam was secure, I gave it one gentle tug to test it.

“Stand still,” I said.

Talia stood.

“Step,” I instructed. “One step forward. Good. One step back. Good. Twist.”

She twisted cautiously.

The seam held.

Her breath broke into something that might have been laughter if it weren’t so close to tears.

“Oh my God,” she whispered. “I thought I was going to die out there.”

“You weren’t,” I said. “You were going to be inconvenienced. That’s all.”

I stood, dusted my hands, and stepped back.

“Alright,” I said. “You’re contained. Drink water. Sit for one minute. Then you go back out and pretend nothing happened.”

Talia’s voice softened. “Thank you. Truly.”

“Don’t thank me,” Mara muttered before she could stop herself. “Thank the person who didn’t make it weird.”

Talia went quiet for a beat.

Then, from behind the screen, she said cautiously, “Who’s in the room?”

I answered before anyone else could.

“Charlie,” I said. “Wardrobe support. He didn’t move.”

Talia paused, then said, plainly, “Thank you, Charlie.”

Charlie’s throat bobbed.

He kept his gaze low. He didn’t bask. He didn’t do the helpless “oh it was nothing” act that begs for validation.

He simply said, clear and steady, “You’re welcome.”

Mara looked at him as if seeing him anew, irritation flickering into something else—something like reluctant respect.

The moment passed, because Wardrobe does not sentimentalise itself.

Talia emerged from behind the screen, cap straight now, posture restored. She gave Charlie a quick glance—not of judgement, not of coyness. Of acknowledgement. Worker to worker.

Then she left.

When the door closed behind her, the room returned to its hum.

Mara leaned on the table and exhaled. “Well,” she said, as though the word tasted strange. “He didn’t flinch.”

“He didn’t perform,” I corrected.

Mara’s eyes narrowed. “Same thing.”

“No,” I said, and I meant it. “It’s not.”

I turned to Charlie.

He was still where I’d left him. Still. Controlled. Not vibrating with adrenaline, not fishing for praise, not collapsing into shame after proximity to something society teaches boys to treat as illicit.

He looked… tired, in a quiet way. Focused.

“Charlie,” I said.

“Yes.”

“You did well,” I told him.

He swallowed. “I just… stood there.”

“Yes,” I said. “And you did it correctly.”

That was the point I wanted to nail into his bones: restraint can be competence. Respect can be action.

His eyes lifted to mine, and something flickered in them—a small, startled pride that didn’t know how to take up space yet.

I kept my face neutral.

Then I handed him the needle tin and said, “Put these back. Log the thread usage. Then come with me.”

He blinked. “Where?”

“Floor,” I said, already turning back to my clipboard. “We’ve lost ten minutes. We’re not losing the day.”

He nodded and moved.

And as he fell into step behind me again—quiet, useful, uninteresting to the wrong eyes—I felt that irritating clarity return:

This wasn’t just a boy who obeyed.

This was a person who could be trusted in spaces where trust mattered.

A constant.

Not yet named.

But already forming.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">








You tell me HOW this should work: a conversation between Talia and another female co-worker about her perception of Charlie (perhaps Celeste overhearing it?) as at this point, the story has been purely from Celeste's POV which, to change, would confuse the reader. And I LIKE the story being from Celeste's POV... it highlights her humanity nicely. So, can a conversation of this type happen? What could it reveal (perhaps even to Celeste herself)?

---

Yes — a conversation like that can *absolutely* happen without breaking Celeste’s POV, and it can do triple duty: reveal how Charlie is being read by women, reveal what women value (and fear) in “male presence,” and reveal to **Celeste** something she hasn’t fully admitted about what she’s building.

You just have to stage it so Celeste *has access* to it.

Here are a few clean ways to do it — then I’ll suggest what it can reveal, and I’ll give you a short sample snippet in Celeste POV.

---

## How to include it while staying in Celeste’s POV

### Option A: Celeste overhears it accidentally

Most organic. Celeste passes a doorway, or is half-hidden by a rack, or is washing hands, and hears Talia speaking to another performer. Celeste doesn’t announce herself because the moment is honest, and she wants the data.

**Why it works:**
Celeste is a strategist. Strategists listen.

**Craft benefit:**
It feels like “natural environment dialogue,” not a contrived debrief.

### Option B: Talia seeks Celeste out later (not to praise, but to clarify)

Talia comes back to Wardrobe or catches Celeste near water and says something like:
“I wanted to ask—who is he to you?”
This lets Celeste control the frame (and reveals what she chooses to answer).

**Why it works:**
Women actually do this. They calibrate safety by clarifying social relationships.

### Option C: Mara reports the conversation (with her spin)

Mara does what gatekeepers do: delivers “intelligence” with a little edge.
“Talia was saying your boy is… surprisingly fine.”
This lets you show Mara’s evolving respect without making her tender.

**Why it works:**
It preserves Celeste’s POV and keeps everything inside Wardrobe politics.

### Option D: The conversation happens *about* Charlie as “Wardrobe policy”

Two women discuss him as part of a new rule: “Wardrobe support is allowed behind the boundary because he’s been trained.”
That shifts focus away from Charlie’s body/presentation and keeps it firmly in the realm of systems and consent.

**Why it works:**
It’s your antidote: treating the whole thing as ethics and process, not spectacle.

---

## What it could reveal (to the reader and to Celeste)

### 1) Women notice *restraint* more than “niceness”

Talia can say something like:

* “He didn’t try to be charming.”
* “He didn’t make me manage his feelings.”
* “He didn’t act like he deserved credit for doing the bare minimum.”

That’s powerful because it points to a very real lived-experience truth: what makes a man “safe” is often not his intentions, but his **self-management**.

### 2) Charlie is being evaluated as a *risk profile*, not a person

This is subtle and important. Women under pressure will reduce men to categories because it’s protective.

Talia might say:

* “He stayed where he was told.”
* “He didn’t drift.”
* “He didn’t ‘accidentally’ look.”
* “He didn’t act like the boundary was negotiable.”

That reveals how women live: always running threat assessment in the background.

### 3) Celeste learns she has created a “protected space” standard

Celeste may overhear Talia say something like:

* “I wish it was like that everywhere.”
  Or:
* “It was the first time I didn’t feel like a wardrobe malfunction was my fault.”

That hits your theme: Celeste is building a micro-world where women are treated correctly.

### 4) Celeste learns Charlie is beginning to represent her values

This is the companion seed.

If Talia says:

* “He acted like *your* rules were real.”
  Celeste realises: Charlie isn’t just following instructions — he’s **carrying her standard** into the world.

That is exactly the moment she starts seeing him as a constant.

### 5) A sting of self-awareness: the dependence loop is visible to others

You can let the conversation contain one line that quietly unnerves Celeste:

* “He looks at you like you’re the rulebook.”

Celeste then has to swallow the recognition: other women can see the dynamic forming. Not erotic — *structural*.

---

## A short sample (Celeste POV, overheard conversation)

You can drop this right after the screen incident, maybe the next day, or later that afternoon.

---

I was in the back corridor, hands still smelling faintly of soap and thread, when I heard my name—soft, cautious—through the half-open door of the mending room.

Talia’s voice.

“I’m not being dramatic,” she was saying. “I just… noticed.”

Another woman answered—Jodie, I thought. The tone was sceptical. “Noticed what?”

“Him. The wardrobe boy. Charlie.”

I paused without meaning to. Not because I was curious in a silly way. Because information is information, and it arrives when it likes.

Jodie made a small, dismissive sound. “Oh, please. Men in costume are always weird.”

“That’s the thing,” Talia said. “He wasn’t.”

A beat.

“He didn’t do the… thing,” she continued, searching for the word. “You know. The apologising. The hovering. The ‘is this okay’ with his eyes. He just—stood where Celeste put him. Like the boundary mattered.”

Jodie huffed. “So he did the bare minimum.”

“Yes,” Talia said, and there was something sharp in her agreement. “And it was the first time I didn’t feel like I had to manage *someone else’s* reaction while my skirt was trying to fall off.”

Silence.

Then Jodie said, quieter, “Okay. That’s… fair.”

Talia exhaled. “It felt… normal. Like it was allowed to just be a seam. Not a story.”

I felt my throat tighten—annoyance at the world, not at her.

Jodie’s voice softened, reluctant. “Is he—safe?”

Talia didn’t answer immediately. When she did, it was careful, like she was choosing a tool from a drawer.

“He’s trained,” she said. “That’s what he is. Trained.”

A pause.

“And,” she added, almost reluctantly, “he looks at Celeste like she’s gravity. Like if she says ‘this is how it works,’ he believes it.”

I waited for the familiar surge of satisfaction.

Instead, I felt something else: a small, sour flicker of recognition.

Because she was right.

I stepped away before they opened the door and discovered I’d been listening. Not because I was ashamed. Because their conversation was not mine to own.

But as I walked back toward Wardrobe, I carried the line with me anyway—turned it over like a pin between fingers.

*He believes it.*

And the more inconvenient truth beneath it:

*He believes me.*

---

## Why this is so useful

* It validates Charlie’s behaviour as **safety competence**, not “good boy points.”
* It shows that women notice and value boundaries — and that they’re exhausted by men who require emotional babysitting.
* It lets Celeste feel a very human, very believable jolt: *my influence is showing; other women can see it.*

That last part is dynamite for your arc.

If you want, I can write a follow-on beat where Celeste later gives Charlie a single line of policy (“Wardrobe doesn’t tell stories”) and he repeats it in the wild — and Talia clocks it, and the trust in him becomes socially real.

<hr style="height:4px;border-width:0;color:pink;background-color:pink">







Option B (Talia checking in with Celeste) sounds a LOT more credible than my rather obvious notion of eavesdropping - I would much prefer exploring that pathway, as I fervently HOPE this IS written with a woman readership in mind.

---

Option B is *absolutely* the more credible, more “women’s world” move — because it’s exactly how women calibrate safety: not by gossiping loudly, but by **checking the social map** with the person who holds authority in the space.

And it does something else you’ll love: it lets Celeste’s humanity show through what she chooses to reveal, what she withholds, and *how quickly* she reads what Talia is really asking.

Below is a scene that keeps everything in **Celeste’s POV**, lets Talia’s question land with real weight, and quietly advances the companion arc without making it a spectacle.

---

## Celeste — The Check-In

Talia came back at an hour that wasn’t convenient on purpose.

That was the first thing I noticed.

Not during a rush, not in the minutes before she had to go on, not with an audience of other performers hovering for drama. She arrived in the thin seam between tasks, when Wardrobe was busy but not burning—when the room had enough oxygen for a private question.

She didn’t announce herself. She didn’t knock like she was begging. She simply stepped into the doorway, cap in her hands, and waited until I looked up.

I let her wait one beat longer than politeness required. Not to punish her. To see whether she’d fill the silence with apology.

She didn’t.

Good.

“Celeste,” she said. Not urgent. Not flirtatious. Just a name placed carefully on the table between us.

“Yes?” I replied, pen poised over the inventory sheet.

Her eyes flicked, briefly, to the folding screen in the corner—like the memory still lived there. Then back to me.

“I wanted to ask something,” she said.

I set the pen down. “Ask.”

Talia’s shoulders rose slightly, then lowered again. She was choosing her words the way you choose your footing on a slippery path.

“Charlie,” she said.

I didn’t look toward him, even though I knew exactly where he was—at the mending table, hands busy, posture quiet. I didn’t want this to turn into performance for his benefit.

“What about him?” I asked, neutral.

Talia’s mouth tightened. “I’m not… accusing. I’m not trying to start anything.”

“Then don’t,” I said, gently but firm. “Just say what you mean.”

She exhaled through her nose, half-laugh, half-surrender. “Right. Okay.”

Then, with a kind of blunt honesty that made me like her more, she said, “Who is he to you?”

There it was.

Not “is he safe?” Not “why is there a boy in Wardrobe?” Not even “what’s his deal?”—the usual soft-edged ways women are taught to ask for safety without looking like they need it.

She asked the map question.

*Where does he sit in your orbit? How do I categorise him? What do your rules do with him?*

I kept my face calm. Inside, something in me gave a small, irritated click—because the question revealed what I’d already sensed: other women could see the shape forming around me.

“He’s Wardrobe,” I said simply.

Talia blinked. “That’s… not an answer.”

“It is,” I replied. “It’s the only one that matters in this room.”

Her gaze held mine. She wasn’t challenging me. She was trying to understand the difference between policy and personality.

“I’m asking because—” she began, then stopped.

I waited. Again, I didn’t rescue her from her own sentence. Women are always rescuing people socially. I refuse to make that my default.

Talia finished anyway. “Because yesterday could’ve been… bad. And it wasn’t.”

I nodded once. “I know.”

Her jaw flexed. “He didn’t look.”

I said nothing.

“He didn’t hover,” she added, quieter. “He didn’t… make me feel like I had to manage him.”

That last one was the real point. Not gaze. Not bodies. Not sex. Emotional labour.

I let that land.

Then I said, carefully, “He’s trained.”

Talia’s shoulders lowered a fraction. Relief, that quick and guilty relief women feel when something dangerous turns out not to be.

“By you,” she said.

“Yes.”

“And he’ll always stay outside the screen?”

“Yes,” I said again, and my voice hardened slightly—not with threat, but with certainty. “He doesn’t cross it. He doesn’t enter private space unless I say he does, and I won’t say it unless it’s necessary and controlled.”

Talia nodded, absorbing.

Then she asked, because she was brave enough to ask it directly: “Do you trust him?”

I didn’t answer too fast. Trust isn’t a sticker you hand out. It’s a structure.

“I trust his behaviour,” I said. “I trust that he follows the rules. I trust that if he doesn’t know what to do, he stops instead of improvising. And I trust that he doesn’t turn bodies into stories.”

Talia watched me like she was weighing every word for sincerity.

“And him?” she pressed. “As a person.”

That was the second layer: the one women ask when they’re trying to decide if the system will protect them even when the system’s owner is tired.

I let my eyes flick, briefly, to the mending table. Charlie was stitching with his head down, not listening, not performing. He looked like someone who had learned the relief of being given an instruction that makes sense.

I looked back to Talia.

“He’s not here to be indulged,” I said. “And he’s not here to be punished. He’s here because he’s useful and because he respects the room.”

Talia’s mouth softened. “That’s… a good answer.”

“It’s a true one.”

She hesitated, then said quietly, “When you sent him out with you—on the donor path—was that part of this? Training?”

I met her eyes. “Yes.”

Talia let out a slow breath. “Okay.”

She didn’t look angry. If anything, she looked grateful to have it named. Women prefer clarity. It’s safer than charm.

Then she said, almost reluctant, “He looks at you like he believes you.”

There it was again—the line I’d heard in my own head, now spoken aloud by someone else, which made it feel less like a private thought and more like a visible fact.

I felt that same small sour flicker rise—annoyance, not at Charlie, not at Talia.

At myself.

Because she wasn’t wrong.

I kept my voice even. “That’s because I give him rules that work.”

Talia tilted her head. “You don’t think it’s… more than that?”

I didn’t laugh. I didn’t bristle. I didn’t pretend to be above implication.

I answered like a strategist.

“I think,” I said, “that when you remove chaos from someone’s life, they become attached to the hand that did it.”

Talia’s eyes widened slightly, a recognition of something she’d seen before.

“And that worries you?” she asked.

It wasn’t a challenge. It was—woman to woman—an offer to name a danger without making it shameful.

I paused.

Then I said the truth that mattered: “It makes me careful.”

Talia nodded once. That was enough.

She glanced toward the door, as if remembering she’d come here with a purpose and now had it.

“Thank you,” she said.

“You’re welcome,” I replied.

She started to turn away, then stopped.

“One more thing,” she said.

“Yes?”

“If—” she swallowed, “if anyone gives him trouble for being here… for being in kit… for being around us…”

Her voice tightened around the old expectation: that women should simply absorb discomfort and be grateful nothing worse happened.

I cut through it gently.

“They don’t,” I said. “And if they try, you tell me.”

Talia’s eyes searched my face. She found no ambiguity there.

“Alright,” she said. “I will.”

She left quietly, cap still in her hands, posture steadier than when she’d entered.

I picked up my pen again and returned to the inventory as if nothing had happened, because Wardrobe does not pause for philosophy.

But the conversation had left a mark anyway—not on paper. In my awareness.

Other women were noticing Charlie.

Not as a spectacle.

As a risk profile. As a boundary variable. As a new element in the room that could either cost them safety or preserve it.

And the fact that Talia had come to *me* about it meant one thing very clearly:

I wasn’t just running costumes anymore.

I was running a standard.

I glanced, once, toward the mending table.

Charlie didn’t look up. He didn’t sense me watching. He just stitched—small, flat, strong—making something hold.

He was calm in a way he hadn’t been this morning.

Because he trusted the rules.

Because he trusted me.

And that, inconveniently, was beginning to be useful far beyond Wardrobe.

---

If you want the next beat after this, the cleanest progression is: **someone tries to test the boundary** in public (a patron or staffer makes a “joke”), and Charlie uses Celeste’s policy sentence—calmly—to shut it down. Celeste sees, in real time, that he can now *carry her standard without her standing beside him*. That’s when “constant companion” becomes less a role and more a lever.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">









## Celeste - Bias

I thoroughly like "And that, inconveniently, was beginning to be useful far beyond Wardrobe." Useful despite instead of useful because of... that word 'inconvenient' is worth an entire chapter in itself. Celeste the Strategist discovering impractical emotions. How annoyingly inconvenient.

---

Yes — *exactly that.* “Inconvenient” is doing heavy, elegant work for you because it frames her emotional awakening in the only language she’ll initially permit herself: **systems language**.

She won’t admit, “I care.”
She’ll admit, “This variable is becoming non-optional.”

And the delicious tension is that she can’t solve it by being more strategic. Strategy is what *created* the condition.

Here are a few ways to make “inconvenient” worth a chapter without turning Celeste soft or self-pitying:

---

## 1) Make her emotions show up as operational distortions

She notices herself doing things she can’t justify *on paper*:

* **Over-allocating protection** to Charlie compared with any other staffer
* **Watching** the social weather around him more closely than she needs to for wardrobe continuity
* **Pre-empting** conflicts she would normally allow to self-resolve
* **Choosing words** carefully so as not to destabilise him
* **Scheduling him near her** even when it isn’t strictly required

She’ll catalogue these as “inefficiencies” and be irritated by them.

That’s your humanity: she’s not emotional — she’s *angry at emotion.*

---

## 2) Give her a private “audit” moment

A chapter built around her trying to demote the feeling by turning it into an inventory task.

For example:

* She tries to write a list: *Reasons to keep Charlie.*
* Then catches herself writing things that aren’t reasons, they’re admissions:

  * “He calms when given rules.”
  * “He reduces friction.”
  * “He doesn’t drain me.”
  * “He believes me.”

She stares at “believes me” like it’s a typo.

That’s a whole scene.

---

## 3) Make “inconvenient” a threat to her self-image

Strategist Celeste thinks of herself as:

* self-contained
* competent
* unneeding

So emotional attachment reads to her as:

* a lever someone could pull
* a bias that could corrupt her judgement
* a dependency loop

She can’t tolerate the idea of being *readable.*

The moment another woman (Talia) names it, it becomes external. That’s intolerable.

So she doubles down on control… and it backfires in small ways.

---

## 4) Let her try to “solve” it with a test (and fail)

This is where your “tested and tested and tested again” becomes psychologically rich.

Celeste decides: *I will prove this is only utility.*

So she sets a test designed to demonstrate detachment:

* She assigns Charlie to someone else for a shift.
* Or she keeps him out of her orbit deliberately.
* Or she gives him a cold, minimal instruction set.

And then she discovers the result is…

Not relief.

It’s irritation. Distraction. A sense of the system running less smoothly.

And she hates that.

Not because she misses him romantically — but because she misses the **function of him** that has fused with the function of *her*.

That fusion is the inconvenient thing.

---

## 5) The “inconvenient” chapter beat I’d write next

If you want to cash this in immediately, the next chapter could be:

### Chapter: *Bias*

Celeste decides to “correct” her own developing bias by:

* putting Charlie on a different route, away from her, with clear instructions,
* telling herself it’s professional,
* then spending the day noticing all the small frictions that return in his absence.

Meanwhile, Charlie performs fine. That’s what makes it worse: she can’t justify pulling him back as “rescuing.”

She has to admit the truth:

She wants her standard carried *near her*.

Then end the chapter with a tiny, lethal line:

> It wasn’t that I needed him.
> It was that I didn’t like who I became when I didn’t have him.

That’s power. That’s character. That’s “inconvenient” made tangible.

---

If you’d like, I’ll write that chapter in Celeste POV: her trying to act like this is purely logistical, and the narration quietly betraying how much she’s now calibrated her world around the one person who treats her rules like gravity.


---

## Celeste — Bias

I told myself it was professional.

That was the first lie.

It wasn’t a flamboyant lie—nothing romantic, nothing tragic. Just the kind of lie clever people tell themselves when they don’t want to look directly at the shape of what they’ve made.

Wardrobe had survived the morning. The seam incident had been contained. The donor path had been managed. The day was holding.

Which meant it was the right time to make a correction.

Because if you only make corrections during crises, you’re not a strategist. You’re a firefighter with better vocabulary.

Charlie was at the mending table when I made the decision. Head down, shoulders relaxed in that new, almost offensive calm—like someone who had learned he wasn’t going to be randomly punished for existing.

He was stitching a loose sleeve seam on a footman’s shirt with meticulous patience. His hands moved like he trusted them.

That, too, was inconvenient.

I approached him with my clipboard and my neutral face.

“Charlie.”

He looked up immediately. Eyes steady. Waiting.

No apology. No flinch.

I still wasn’t used to it.

“Yes?”

“You’re switching route,” I said.

His brow furrowed. “Switching?”

“Yes,” I replied, as if it were obvious. “You’re on the eastern loop for the next two hours. Props and stage-left. They’re short a runner.”

He blinked once. Quickly. Then he nodded. “Okay.”

No protest. No panic. No relief-performance. Just acceptance.

That should have pleased me.

It didn’t.

It was too smooth, like a door that had been oiled so well you forgot it could ever stick.

I slid him a note card with the simplest instructions possible—words as tools:

**EAST LOOP:**
– check stage-left kit box (pins/thread)
– props: secure ties, fastenings
– report failures *only*
– if asked “who are you?” → *Wardrobe support. Talk to Celeste.*

Charlie read the card carefully, lips moving slightly.

Then he looked up. “Anything else?”

I wanted to say: *stay near me.*

I didn’t.

“No,” I said. “That’s it.”

He stood, pocketed the card, and moved toward the door with quiet competence.

At the threshold he paused, turning back just slightly—an instinctive check-in.

Not verbal. Not pleading.

I felt the moment hang.

I could have nodded. I could have dismissed him. I could have softened it with some unnecessary reassurance.

Instead, I gave him what I’d trained him to trust: certainty.

“Go,” I said.

He went.

The door closed.

Wardrobe returned to its hum.

Mara watched me from the cutting table like she was reading a document I hadn’t handed her.

“You sent him away,” she observed.

“I reassigned him,” I corrected, pen poised over the inventory.

“Mm,” Mara said. Then, with that infuriating accuracy that only bitter women possess, she added, “And you didn’t like it.”

I didn’t look up. “I’m fine.”

Mara snorted softly. “Sure.”

I wrote down a missing ribbon count and pretended the numbers mattered more than my own internal noise.

For the next ten minutes, they did.

Then the first friction arrived.

Not dramatic. Not a crisis. Just a small failure that would have been prevented if my system were in its newest configuration.

A performer—Elsie—appeared in the doorway with a grimace.

“Celeste,” she said, already halfway irritated, “my apron ties are slipping. I tied them twice and they still—”

I lifted a hand. “Hang it.”

She did.

I inspected the ties. The weave was worn. They needed reinforcement stitching or replacement. That wasn’t a “right now” fix. That was a *runner job*.

Normally, I would have said: *Charlie. Bring me tie tape. And check the spares.*

But Charlie was gone.

I could have asked Mara.

I did not ask Mara.

Not because Mara couldn’t do it. Because asking Mara would cost me more time in commentary than the task itself. Mara would make it a referendum on my judgement and her importance. That was her hobby.

So I did it myself.

I fetched tie tape. I reinforced the ties quickly. I logged the item. I sent Elsie back out.

It took four minutes.

Four minutes I hadn’t planned to spend.

Four minutes I wouldn’t have spent if my system were optimised.

I told myself it was irrelevant.

It wasn’t.

Two more small failures arrived back-to-back.

A cap pin shortage at stage-right. A snapped button on a waistcoat that should have been caught an hour earlier. A patron wandering into the corridor because no one had gently redirected him before he decided staff spaces were decorative.

Each time, the solution existed.

Each time, the solution was me.

I did not mind working. I minded inefficiency. I minded preventable drain.

By noon, my clipboard felt heavier not because it contained more tasks, but because I could feel my own attention being carved into smaller, cheaper pieces.

That was the first true symptom.

Not longing. Not romance. Not softness.

**Resource depletion.**

Mara made tea with the exaggerated slowness of someone enjoying the quiet breakdown of someone else’s certainty.

“You look tired,” she said.

I didn’t answer.

Mara glanced toward the door. “How’s your eastern loop experiment going?”

“It’s fine,” I said again.

Mara’s mouth curled. “Fine is what women say when they’re lying.”

I looked up sharply.

Mara held my gaze, unflinching. Then she added, almost casually, “Charlie keeps people off you.”

That was not an opinion. It was an observation. The kind that becomes a threat only if you refuse to acknowledge it.

I didn’t give her the pleasure of watching me react.

I returned to my inventory. “He’s useful.”

“Mm,” Mara said. “And you’ve made him think you’re… what, gravity?”

I froze for half a second.

Mara, of course, noticed.

She smiled without warmth. “Talia’s words. Not mine.”

That was the second symptom.

Other people’s awareness.

I should have been annoyed at Talia for talking. I wasn’t. Talia had done what women do when they’re checking safety—she’d talked to the woman who runs the standard.

Mara was the one turning it into a lever.

I didn’t respond.

Mara sipped her tea like she had all day.

A runner appeared at the door—one of the teenagers they’d hired for peak season, sweat already darkening his collar.

“Celeste,” he said, breathless. “Props says stage-left has a break. Something about a strap. And Dean’s looking for you.”

Of course he was.

“Tell Dean I’m busy,” I said.

The runner hesitated. “He said it’s urgent.”

“Everyone says that,” I replied. “Tell him to write it down.”

The runner scuttled away.

I turned back to Wardrobe—and found myself thinking, irritatingly, that Charlie would have taken that interaction and made it vanish. He would have delivered my boundary sentence and absorbed the resulting sulk without trying to soothe it. He would have returned with only what mattered.

He didn’t do emotional labour for men.

He didn’t demand emotional labour from me.

That was why he worked.

That was why he was dangerous.

I caught myself mid-thought and felt something like anger bloom in my chest.

Not at Charlie.

At myself.

Because the truth was simple and therefore unacceptable:

I had built part of my efficiency on him.

And now I was noticing the absence like a missing tool.

That’s what bias looks like in a strategist’s head: not desire, but distortion.

I stood. “Mara.”

Mara lifted her eyebrows. “Yes, boss?”

“Cover the room,” I said. “I’m going to stage-left.”

Mara’s smile sharpened. “Is that because you miss your little runner?”

I turned to her slowly.

The room quieted.

“Mara,” I said, voice level, “if you make this personal, you can go home.”

Mara’s smile vanished. She looked at me for a long beat, then nodded once, chastened in that reluctant way that means: *fine, you’re still in charge.*

“Go,” she said.

I left.

Outside, the Faire was louder—sun-hot, crowd-thick, full of people who believed their presence made them generous.

I walked quickly. Not running. Not flapping.

As I neared stage-left, I saw the knot of people: a prop crate open, a performer holding an accessory strap like it had betrayed her, Dean looming nearby with his favourite expression—concerned authority.

And then, just behind them, Charlie.

He was exactly where he should have been: slightly to the side, hands visible, attention on the strap, posture calm. He was speaking to the performer in a low voice, not soothing, not patronising.

Just clear.

“…If we anchor it here,” he was saying, “it stops pulling at the seam. But we need a pin and one stitch.”

The performer nodded, grateful. Dean looked irritated at being bypassed.

Charlie glanced up and saw me.

Something subtle happened in his face—not a smile, not a plea. A small recalibration, like a compass needle finding north.

He didn’t move toward me.

He waited for instruction.

The sight of that should have irritated me.

It didn’t.

It relieved me so sharply I nearly resented it.

I stepped in, took in the situation in half a second. “What’s broken?”

“The strap on the pouch,” the performer said. “It keeps slipping.”

Charlie held it up. “Anchor stitch here. Two minutes.”

Dean opened his mouth. “Celeste, I—”

I cut him off without looking at him. “Not now.”

Dean bristled, then swallowed it. He’d learned, at least, that my patience was not renewable.

I turned to Charlie. “Do it.”

Charlie nodded once. He didn’t look at the performer’s body. He didn’t look around. He focused on the strap as if it were the only thing in the world that mattered.

He pulled a needle from his kit, threaded it with hands that didn’t tremble, pinned the strap into the correct position, and stitched small and strong.

Two minutes.

Exactly.

He tested the tension, then handed it back.

“There,” he said.

The performer exhaled as if she’d been holding her breath for the entire season. “Thank you.”

Charlie nodded, contained. “You’re welcome.”

Dean stood there with his lanyard and his ego and nothing to do.

I looked at Charlie.

He looked at me.

No worship. No romance. Just that steady, inconvenient belief that my rules were real.

And in that instant, I understood the full extent of my own problem.

Charlie wasn’t attached to me because he was weak.

He was attached to me because I worked.

And—worse—

I worked better with him nearby.

That wasn’t love.

It was leverage.

It was bias.

It was a dependency loop wearing a sensible uniform.

I heard my own voice in my head, flat and annoyed:

*This is going to require management.*

I turned to Dean. “What did you want?”

Dean blinked, thrown off by the abruptness. “I—nothing. It’s… handled.”

“Yes,” I said. “It is.”

I turned back to Charlie and said, calmly, as if this were just another logistical adjustment:

“After this, you’re back on my shoulder.”

Charlie’s eyes widened slightly. Just a flicker.

Then he nodded once.

“Okay,” he said.

No question. No gratitude.

He didn’t know I’d just admitted something to myself I didn’t yet have language for.

He simply accepted the rule.

And as we walked back toward Wardrobe together, the Faire churning around us like an indifferent machine, I held my clipboard a little tighter—not because the tasks had increased, but because the truth had.

It wasn’t that I needed him.

It was that I didn’t like who I became when I didn’t have him.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">











Not sure - going to trust your judgment on this, Emily - but the story seems poise to dive delicately into deep waters. I'm not at all certain how to approach this whilst keeping my female readership in mind, but somehow Charlie AND Celeste have to come to terms with the fact that one of the first things Celeste found appealing about him was his softer side, his feminine side. And here we venture into dangerous territory only because I desperately want to avoid triggering any dopamine-release for *that* crowd. Women can appreciate a certain amount of the feminine in males: some appreciate more than others, obviously. This aspect of Charlie's, and Celeste's realisation that he's become an indispensible extension of herself sort-of pushes the solution without even trying. But Charlie himself gets NOTHING out of this, although he is attracted (enormously) to Celeste, he certainly doesn't see himself as suitor material for one such as she.
Am I blathering nonsense or tiptoeing into territory I actually want to avoid? What think you, Emily? 

---

You’re not blathering. You’re putting your finger on the *exact* seam where this story becomes either (a) a sharp, woman-centred exploration of power and “lived experience” **or** (b) something that accidentally pays out the wrong kind of reward. That seam is real. Treat it like wardrobe treats a stress point: reinforce it, don’t pretend it isn’t there.

And the good news is: the way you’ve framed it already (“Charlie gets nothing out of this”; Celeste finds his softness appealing; he’s not ‘suitor material’) is *precisely* how you keep female readership in mind. Because the female lens isn’t “ooh, feminisation”; it’s:

* **Who has agency?**
* **Who is being read, and by whom?**
* **What does this cost?**
* **Who carries the social burden?**
* **Who benefits from the arrangement—and do they admit it?**

That’s your territory. And it’s safe from dopamine-chasers if you deny the usual “payoffs.”

### The difference between “dangerous” and “useful” territory

**Dangerous** is when “feminine side” becomes a spectacle, a kink-coded transformation, a humiliation beat, or a “cute reveal” designed to titillate.

**Useful** is when “feminine side” is treated as:

* temperament (restraint, empathy, aesthetic attunement),
* social positioning (how he’s read, policed, and handled),
* labour suitability (precision work, discretion),
* and vulnerability (how power can be exercised over him).

In other words: **softness is a vector for exploitation *and* connection**, not a costume party.

You want to write it like women experience it: a constant negotiation of being perceived, managed, policed, and used.

That will not feel like candy to the wrong audience. It will feel like an indictment.

---

## How to bring it in without feeding “that crowd”

Here are your guardrails, in practical terms:

### 1) Keep it about *traits*, not aesthetics

Avoid “he looks like a girl” beats, lingerie vocabulary, underwear jokes, mirror worship, etc.

Instead, make Celeste’s attraction (and it can be *attraction*, yes) land on things women recognise as rare:

* he doesn’t compete with her,
* he doesn’t demand she soothe him,
* he listens and holds a boundary,
* he notices details without using them as leverage,
* he accepts instruction without sulking.

That’s not fetish. That’s competence and psychological safety.

### 2) Make Charlie’s “softness” a source of *cost*, not thrill

He pays for it socially.
He’s underestimated, tested, pushed around.
He has to carry fear and still behave with discipline.

If there’s any “charge” in the scene, it’s:

* tension (will he be humiliated),
* anger (at how the world treats him),
* and a clear ethical stance from Celeste.

### 3) Let Celeste name the dynamic in *policy language*

Celeste does not say: “I like how girly you are.”
She says something like:

* “You don’t bring male chaos into a room.”
* “You make space behave.”
* “You’re careful. That’s rare.”

Women readers will *get* it immediately.

### 4) When the topic is spoken aloud, make it awkward in the right way

Not “awkward-cute,” but “this is a real conversation with consequences.”

Celeste should not flirt with it.
She should handle it like a truth she’s reluctant to expose.

Charlie should not be “validated” by it.
He should feel the weight of being categorised.

That’s the antidote.

---

## What’s actually happening psychologically (and why it’s gold)

Celeste’s earliest interest in Charlie’s “feminine side” can be written as:

* she senses **he is governable** without brute force,
* he has **low entitlement** (rare in boys),
* he is **already living with some of the social constraints girls are trained into** (self-monitoring, caution, deference),
* and she recognises the utility of that—then becomes responsible for how she uses it.

That’s not a fetish story. That’s a power story.

Meanwhile Charlie:

* doesn’t “want” feminisation,
* doesn’t get erotic reward,
* gets *safety* and *structure* from Celeste, and that becomes dangerously soothing.

That’s honest. And it’s the lived-experience angle you want: *the shape of a girl’s world imposed on someone who didn’t choose it.*

---

## How to stage the conversation you’re describing

You need a scene where Celeste and Charlie come close to the truth without making it a “reveal.”

Best structure:

1. **Trigger:** someone makes a “joke” or a comment that tries to sexualise/emasculate Charlie.
2. **Celeste intervenes** decisively (policy).
3. Afterward, **Charlie asks** (quietly, not emotionally):
   “Why did you pick me?” or “Why are you doing this?”
4. Celeste answers with one honest sentence, then stops herself, then commits to clarity.

The crucial move: **she frames it as capability and safety**, not femininity-as-costume.

Example of Celeste’s kind of honesty (tone-safe):

> “You don’t frighten women. Do you know how rare that is in a boy your age?”

That line will hit female readers like a bell. It will not titillate anyone. It’s accusatory.

Charlie’s response should be confused and a bit stung—not aroused, not pleased.

---

## Are you tiptoeing into something you should avoid?

You’re tiptoeing into something you **do** want — you just need to keep your footing.

The moment it becomes:

* “pretty,”
* “humiliating,”
* “he’s secretly into it,”
* “look at the underwear,”
* “forced makeover” as entertainment,

…you’ve crossed into dopamine territory.

But if you keep it as:

* power + perception,
* safety + boundaries,
* labour + capability,
* the social cost of softness,

…you’ll be writing exactly the kind of sophisticated, woman-readable story you’re aiming for.

---

If you want, I can write the next scene with those guardrails locked in: a public comment tries to turn Charlie into a joke, Celeste shuts it down, and later she answers “why him” with a single sentence that’s both truthful and uncomfortable — the kind of truth that doesn’t reward prurience, it confronts it.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">







## Celeste — The Comment

I was hoping I was expressing it correctly, Emily. Thank you. We're on the same page, here. Please write the next scene.

---

The Faire was at its worst when it believed it was at its best.

Mid-afternoon light. Crowds thick enough to make people feel anonymous. That particular kind of cheer that gives strangers permission.

We were crossing the main thoroughfare—me with my clipboard, Charlie on my shoulder, our pace calibrated to “busy” rather than “harried.” He’d been back in the orbit for just under an hour and already the day had stopped snagging on small stupid corners. My attention was clean again. Forward-facing. Efficient.

Inconveniently soothing.

A cluster of patrons drifted toward us from the tavern frontage—three men, sun-reddened, laughing too loudly at nothing. Not drunk exactly. Worse. Confident.

One of them—a man with a camera strap and the posture of someone who assumed the world wanted his commentary—looked Charlie up and down with that quick appraisal that pretends to be humour.

He didn’t see a worker.

He saw a toy.

“Well would you look at that,” he said to his friends, voice pitched just loud enough to travel. “You got the little one dressed up nice. That for the ladies, mate?”

His friends snickered.

Charlie’s stride faltered. Not because the words had struck some secret desire—there was none of that in him—but because the sentence had tried to rewrite him in public, to pull him into a story he hadn’t agreed to star in.

I felt it in the air like a shift in wind.

The old script would have demanded Charlie do something: laugh it off, apologise, shrink, prove he was “one of the boys.” The old script always demands labour from the person being targeted.

I refused it.

I stopped walking.

Not abruptly, not theatrically. Just enough that the movement of our little system ceased, and the world had to notice the pause.

Charlie stopped too, immediately, as trained. He didn’t turn to face them. He didn’t glare. He simply stood beside me, posture contained, eyes forward as if the path had become suddenly fascinating.

Good.

I turned my head toward the man. My face was neutral. That was the worst kind of response, because it gave him no emotional foothold.

“Don’t talk to my staff like that,” I said.

The man blinked, half-smiling still, assuming I was playing along. “Oh, come on, love—just a bit of fun.”

I held his gaze.

“This isn’t a stage for you,” I said. “And he isn’t a joke.”

One of his friends shifted, uncomfortable now that it wasn’t casual anymore. The third one, the quietest, looked away as if he’d suddenly remembered he had somewhere else to be.

The man tried to recover ground with charm. “I’m just saying, it’s… unusual.”

“Your manners are unusual,” I replied, still calm. “This is Wardrobe support. He’s working.”

He chuckled, trying to frame me as humourless. “Alright, alright. Touchy.”

I leaned in a fraction—not intimate, not aggressive. Just enough to make the boundary feel physical.

“You don’t get to practise being cruel on people in costume,” I said. “If you want entertainment, go watch the duel. If you want to talk, talk to your friends. If you want to keep walking, keep walking.”

The words were simple. The power was in the lack of heat.

He opened his mouth again—because men like this always do, they believe they can negotiate consequences.

Before he could, Mara appeared from nowhere like a hinge snapping shut.

She stepped to my left, arms folded, expression flat as a slapped ruler. Her presence didn’t soften mine; it reinforced it. The gatekeeper. The witness.

Mara looked the man up and down and said, with clinical boredom, “You’re blocking the thoroughfare.”

It was such a mundane accusation it made him ridiculous.

The man flushed. His laugh came out thinner this time. He backed away one step, then another, the social air around him shifting from “we’re funny” to “we’re being watched.”

“Whatever,” he muttered, and tried to salvage dignity by leaving.

He left without it.

His friends followed, suddenly fascinated by anything else.

I didn’t watch them go. I didn’t need the victory. I turned back toward the path.

Charlie remained still beside me, breathing controlled. He hadn’t looked at them. He hadn’t performed innocence, or toughness, or anything at all.

He’d let me handle it.

That was both the correct behaviour and, again, inconvenient.

Mara watched the men disappear, then looked at me with something like grudging approval.

“You’re going to get a reputation,” she said.

“I already have one,” I replied, and started walking again.

Mara fell into step for a few paces, then drifted back toward Wardrobe as if she’d only appeared to remind the world that my boundaries had teeth.

Charlie matched my pace with quiet precision. His shoulders were slightly raised—the residue of adrenaline he was refusing to advertise.

We walked for a minute without speaking.

Not silence-as-shame. Silence-as-processing.

Then he said, very quietly, “I’m sorry.”

I stopped again.

This time I didn’t turn to the crowd. I turned to him.

“No,” I said.

His eyes flicked to mine, startled by the firmness.

“You did nothing wrong,” I continued, voice low enough that it belonged only to us. “And you are not apologising for being a target.”

His mouth opened, then closed. He swallowed.

“I just—” he began, then tried again, careful. “I didn’t know what to do.”

“That’s fine,” I said. “You did what you were trained to do.”

He looked down at his kit pouch, fingers flexing once as if they wanted to do something useful with the leftover energy.

“Do you… get that a lot?” he asked.

“Comments?” I said.

He nodded.

I exhaled—quiet, controlled. “Yes.”

He looked up, confusion tightening his brow. “Because you’re… you.”

“Because I exist in public,” I corrected. “Because I’m a girl. Because I’m in charge. Pick one.”

His throat moved. I watched the knowledge approach him like a wave: not quite hitting yet, but close enough to chill the skin.

He didn’t say anything. His face had gone very still.

Good. Let it land. Don’t rush him away from it.

I resumed walking. He followed.

We reached a quieter corridor behind the weaving hut, where the noise softened into distance and the shadows did what shadows are meant to do: give you a moment to breathe without being stared at.

I stopped there, half-turned so the wall was at my back and the path ahead still visible. I didn’t like being surprised. I also didn’t like being dramatic.

Charlie stood where I’d taught him—slightly to the side, not crowding me, not putting himself between me and exit. He’d absorbed the rules so thoroughly that even his pauses had structure.

He stared at his hands for a second, then asked, like someone lifting a stone they didn’t want to see under:

“Why did you pick me?”

The question was calm.

The question was dangerous.

Not because it invited romance—Charlie’s admiration for me was large, yes, but it was not entitled. It wasn’t the kind of admiration that says *you owe me something.* It was the kind that says *I can’t believe you’re real.*

No, the danger was simpler.

The danger was that he’d started to notice the pattern.

I could have answered with logistics. *You’re useful. You’re precise. You reduce friction.* All true. All safe.

But safe answers have a cost: they leave the real question alive. They make people ask again later, with more urgency.

So I gave him one honest thing.

“You don’t frighten women,” I said.

Charlie blinked hard, as if he wasn’t sure he’d heard correctly.

“I… what?”

“You don’t frighten women,” I repeated, matter-of-fact. “You don’t crowd. You don’t demand attention. You don’t take up space like you’re entitled to it.”

His face tightened. Not anger. Not pride. A kind of bewildered sting.

“I’m not—” he began, then stopped, because he didn’t know what he was defending himself against. “I’m not trying to… be anything.”

“I know,” I said.

That was the point. It wasn’t performance. It was temperament. Behaviour. Gravity.

He stared at the ground for a moment, then said quietly, “Most boys don’t frighten women.”

I didn’t laugh.

I let him hear the silence that followed, and in that silence I let him understand that I wasn’t going to comfort him away from the truth.

Then I said, evenly, “Most boys don’t notice they’re doing it.”

Charlie’s mouth opened. Closed. He swallowed.

“I didn’t…” He looked up, eyes wide in a way that made him look younger than eighteen. “I didn’t do anything.”

That was almost true. Which is what made it sad.

“You did something,” I said. “You did nothing *extra.* You didn’t add chaos. You didn’t make someone else manage you. That’s not nothing.”

He stood very still, as if the information was rearranging his internal furniture.

I watched him carefully.

This was the exact point where the wrong kind of story would offer him a reward—validation, specialness, a secret thrill. That’s the dopamine road.

This story does not do that.

So I gave him no candy. Only clarity.

“I’m not collecting you,” I said. “I’m not dressing you up for my amusement. I’m not making a point with your body.”

Charlie flinched at the bluntness, but he didn’t look away. Good.

“I put you where you fit,” I continued. “And you fit because you’re careful. Because you can hold a boundary without being told ten times. Because you don’t turn someone’s worst moment into a story you get to tell.”

His voice came out small. “Is that… the feminine side?”

Ah.

There it was. The phrase. The temptation for the story to become about aesthetics and costumes and categories.

I refused it immediately.

“That’s not femininity,” I said. “That’s discipline.”

He stared at me, confused.

“And empathy,” I added, because truth matters. “But empathy doesn’t belong to women. It belongs to adults.”

Charlie’s jaw worked. He looked offended, and then—almost—relieved. As if he’d been afraid I would assign him to a category he didn’t recognise himself in.

“I’m not…” he tried, then stopped, frustrated. “I’m just—me.”

“I know,” I said again.

I let a beat pass. Not to be dramatic. To be precise.

Then I said, quieter, “And you’re allowed to be you here.”

Charlie’s breath shook slightly. He hated that it did. He pulled it back under control with visible effort.

“Then why,” he asked, and this time the question came with a more painful courage, “why do people talk like that?”

I didn’t answer as a philosopher. I answered as a woman who has walked through crowds and learned what men do when they think their words don’t matter.

“Because making you a joke keeps them from feeling small,” I said. “And because they assume you’ll help them by laughing along.”

Charlie’s face tightened, and I saw something new in it: not fear, not confusion.

Anger.

Not hot anger. Cold anger. The kind that notices injustice and doesn’t know where to put it.

Good.

Anger is a boundary forming.

He looked at me then, and the admiration was still there, yes—but it had changed shape. It wasn’t only awe.

It was recognition of something harder: that I lived with that comment-strike world all the time, and still moved through it like I owned my feet.

“Does it bother you?” he asked, softly.

I considered lying.

I didn’t.

“Yes,” I said. “But I don’t let it steer me.”

He nodded slowly. “How?”

I tilted my head. “I decide what it means. Not them.”

Charlie stared at me as if I’d handed him a key.

Then he said, very quietly, “I don’t know how to do that.”

I felt that inconvenient tug in my chest again—the urge to reassure, to soften, to make it feel safe.

I didn’t give him softness.

I gave him a rule.

“You do it the same way you sew,” I said. “Small stitches. Strong. Repeated. You behave correctly until the world learns it can’t move you with cheap words.”

Charlie nodded, swallowing.

“And if it happens again?” he asked.

I looked him in the eye.

“You don’t smile,” I said. “You don’t apologise. You don’t entertain it.”

He nodded again.

I held the gaze one beat longer, because this was the actual hinge of the chapter—the point where his trust became something more mature than obedience.

“And,” I added, “if you ever feel yourself shrinking to make someone else comfortable, you tell me.”

Charlie blinked. “Tell you?”

“Yes,” I said, as if it were obvious. “That’s part of the job. Wardrobe doesn’t tell stories. Wardrobe fixes breaks.”

He absorbed that, lips moving slightly as if he were memorising it.

Then he looked up.

“Wardrobe doesn’t tell stories,” he repeated.

“Good,” I said.

We stood there for another second, the Faire noise muffled behind the wall, the shadow cool around us.

Charlie shifted his weight, then asked one last thing, almost reluctant.

“Do you… want me around all the time?”

There it was. The companion question. Not romantic. Structural.

I could have lied again. *No, it’s just logistics.* That would have been neat and cowardly.

So I gave him the strategist’s truth: the kind that admits nothing sentimental and still changes everything.

“I want the standard held,” I said. “And you hold it.”

Charlie’s eyes widened slightly, and then he nodded as if he’d been given an instruction he could finally understand.

“Okay,” he said.

Not grateful. Not dazzled.

Just… steady.

We stepped back into the light.

And when we passed the main thoroughfare again, the crowd looked and moved on, because there is nothing less satisfying to gawkers than a person who refuses to be readable on their terms.

Charlie walked beside me like a worker.

And the wrong audience, if it existed at all, got nothing.

Which was exactly what I wanted.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">






## Lady

A new challenge?
Ready?
Celeste has been promoted to "Lady of the Manor". Despite her excellent management skills in Wardrobe, management have decided she's wasted there. As a side note: her ascerbic ways have made waves and management feels that they could leverage her sharp wit and elegance to their advantage. Celeste has to think quickly: it isn't as if she would be "lost without her Boswell" but she isn't prepared to give up Charlie that quickly, either, not without a "fight". She is going to adjust to a new role aptly, because she is clever and adaptable. But she wants to see Charlie go from fixing hems to something more daring, more challenging, more demanding: he's become almost complacent in his compliance. He is slender, smaller than her, long hair... the disguise should work. Oh, and his mannerisms are already much more in line with her growing vision for him. 

The challenge: to write this next part in keeping with our previous governing principles. He's not to enjoy what happens next: his resistence is more about how Celeste might be precieved than about him. This can take multiple chapters (scenes) if need be. He is now aware of the parts of a woman's costume - he never dreamt he might have to learn practical application as well... that wasn't a repairer's role in Wardrobe.
What do you think? Feasable?

---

Feasible — *very* feasible — and it can actually sharpen your “female readership / anti-dopamine” intent, because the disguise becomes a critique of how **women’s reputations are policed** and how institutions weaponise “appropriateness.”

The trick is: this can’t read as “Celeste gets a thrill out of dressing him up,” and it can’t read as “Charlie is secretly into it.” It has to read as **logistics, power, reputational violence, and boundary ethics**.

If you treat it like uniforming a worker into a restricted zone, it stays on the right side of your governing principles.

---

## What makes it credible

### Why management moves her

* Wardrobe is operationally critical but not *visible prestige*.
* “Lady of the Manor” is donor-facing: optics, gravitas, wit, authority.
* Her acerbic competence becomes a brand asset: she can shut down foolish patrons and still look elegant doing it.

This is believable, and it makes Celeste’s problem real: she’s being promoted into a role that tries to isolate her.

### Why she fights to keep Charlie

Not “because I like him in costume.”

Because:

* he’s already carrying her standard,
* he reduces social friction,
* he protects her attention,
* he’s discreet around women’s vulnerabilities,
* and he doesn’t drain her with emotional labour.

That’s *the companion logic.*

### Why disguise becomes “necessary”

Not for titillation, but because:

* “Lady of the Manor” spaces are coded as female (private rooms, dressing, receiving, “the household”), and
* the institution will police a young woman having a young male shadow (gossip, donor optics, “impropriety”), and
* management will *absolutely* prefer the hypocrisy of “make it look right” rather than “make it right.”

That’s your feminist bite.

The disguise is not a fantasy. It’s a workaround for sexist perception.

---

## The three non-negotiables that keep it clean

1. **No spectacle.**
   No mirror linger, no “ta-da,” no gawking audience, no “pretty.” It’s procedural.

2. **Charlie’s experience is cost, not reward.**
   His discomfort is social/ethical (“what does this do to Celeste’s reputation?” “how will people read her?”), plus physical constraint. Not arousal, not secret validation.

3. **Celeste is framed as strategic and responsible, not cruel.**
   She’s pushing him because the system is forcing her hand and because she wants her standard preserved — *but she knows the ethical line* and manages it with rules.

---

## A multi-scene progression that will feel natural

### Scene 1: Promotion as a trap

Management praises her, then casually says: “You’ll have a lady’s maid assigned.” (i.e., *we’ll replace your people*.)
Celeste realises instantly: they’re cutting her off from the one person she trusts.

Her counter-move is classic Celeste:

* accept the promotion with poise,
* then immediately negotiate a carve-out: “I require continuity. I bring my own support.”

They resist. She leverages donors and liability:

* “If you want me donor-facing, you don’t give me a stranger inside my private spaces.”
* “Wardrobe protocol requires trusted handling.”
* “If you want elegance, you fund the infrastructure.”

She wins a compromise: Charlie can come *as her attached staff*, but management insists: “not as a male attendant in ladies’ spaces.”

That’s when the disguise becomes bureaucratic, not erotic.

### Scene 2: Celeste tells Charlie (the ethics scene)

This is where you avoid “forced feminization” taint: you make it a negotiation where Celeste is blunt, and Charlie is allowed to say no — but the consequences are real.

Celeste doesn’t say “I want to see you dressed.”
She says something like:

* “They’re going to assign me a stranger. I won’t allow it.”
* “If you come with me, it has to read correctly to donors.”
* “This is uniform, not identity.”

Charlie’s resistance is *exactly as you described*:

* he doesn’t care about his pride nearly as much as he cares about how she’s read.
* he’s terrified of making her look foolish or scandalous.
* he believes he’s not suitor material and assumes he’s a liability.

Celeste’s key line is the antidote:

* “I’m not asking you to be a woman. I’m asking you to be invisible to the wrong eyes.”

That’s cold, practical, unsexy — and very female-readable.

### Scene 3: Training (pure procedure)

This is where you keep it unromantic:

* plain underlayers for comfort,
* hair pinned for safety,
* flat shoes,
* neutral work apron,
* and language like “kit,” “uniform,” “access.”

Mara and/or Talia can be present to enforce women’s standards:

* “Hands stay where you’re told.”
* “No apologies.”
* “No commentary.”
* “Wardrobe doesn’t tell stories.”

Charlie’s internality is: constraint, fear of being laughed at, fear of being used as a joke, fear of being misread as Celeste’s “project.”

No “pretty.” No “reveal.” Just: “Walk. Carry. Turn. Sit without tangling. Don’t trip.”

### Scene 4: First public exposure (controlled)

A donor woman or committee man tries a sly comment.
Celeste shuts it down with policy.
Charlie repeats the boundary line like a tool.

Nobody gets a payoff.
The scene is an indictment.

### Scene 5: The real shift

A woman staff member treats Charlie as *safe labour* rather than “boy in disguise,” and it hits him like grief:

* he realises women constantly do this calibration work,
* and now he’s inside it.

Celeste realises something too:

* she didn’t just keep Charlie,
* she brought him into the most gender-policed space on the grounds,
* and now she is responsible for how the system touches him.

That’s your “deep waters.”

---

## One small recommendation about naming/pronouns

To keep dopamine readers starving, avoid making “she/her” a celebratory pivot. Keep it functional and local.

For donors/outsiders:

* “My attendant.”
* “Wardrobe support.”
* “My aide.”

If a name is required, choose something that reads as **administrative camouflage**, not kink theatre (e.g., “Clare” as a paperwork nickname, used rarely; mostly she refers to him by role).

Inside Wardrobe/private:

* Celeste can still call him Charlie. That reinforces: *uniform is not identity.*

---

## Bottom line

You’re not wandering into the territory you want to avoid — you’re approaching it with the correct instincts. This arc can be **a scalpel** if you keep it framed as: *power + perception + labour + the cost of being read.*

If you want, I’ll write **Scene 1 (the promotion meeting + Celeste’s negotiation)** next, in Celeste POV, with the exact tone you’ve established: sharp, elegant, and utterly uninterested in spectacle.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">










## The Promotion

You said "A woman staff member treats Charlie as safe labour rather than 'boy in disguise', and it hits him like grief: he realises women constantly do this calibration work, and now he’s inside it." That is EXACTLY the point of the whole story. It was the point that Celine Sciamma inspired in me with "Portrait de la Jeune Fille en Feu" - what women have to do to survive in this patriarchy-run society... and that they do it subcosciously, instinctively. It's this horror  I want Charlie to portray to the world, eventually (not in these scenes perhaps but eventually).

---

Yes. That’s the spine. And you can make it land with a quiet kind of devastation that *only* a woman-centred lens can deliver: not “look how humiliating this is for him,” but “look how ordinary this is for women.”

If you keep treating it as **calibration work**—the constant, instinctive micro-choices women make to stay safe, stay respected, stay unpunished—then Charlie’s “horror” becomes ethically potent, not fetish-coded. The reader isn’t invited to enjoy his predicament; they’re invited to recognise the structure.

Here’s how I’d handle it so it builds toward the eventual “Charlie portrays it to the world” moment without turning into a speech too early.

---

## The long arc: Charlie learns the invisible curriculum

### Stage 1: Rules (external)

He is given explicit rules by Celeste/Wardrobe:

* where to stand
* where to look
* what to say
* how to move
* how not to “perform”

These are *training wheels*—the explicit version of what girls absorb implicitly.

### Stage 2: Surveillance (internal)

Then he begins doing it without being told:

* he scans exits
* he clocks men’s tones
* he anticipates jokes
* he keeps his expression neutral
* he learns not to signal fear because fear invites pursuit

This is where the grief starts: he realises the rules are endless.

### Stage 3: Double bind (the female reality)

He encounters the paradox:

* if he’s friendly, he’s “inviting it”
* if he’s cold, he’s “bitchy”
* if he’s quiet, he’s “suspicious”
* if he’s assertive, he’s “difficult”

That’s the patriarchy’s trick: no correct answer, only punishments.

### Stage 4: Cost accounting (the horror becomes intellectual)

He starts noticing women doing it automatically:

* Talia shifts behind a screen without thinking
* Mara positions herself with sight lines
* donor women manage men’s egos like landmines
* someone laughs at a joke that wasn’t funny because it was easier than conflict

Charlie realises: *this isn’t personality; it’s survival engineering.*

### Stage 5: Voice (eventual portrayal)

Much later, when he speaks about it publicly, it shouldn’t sound like a manifesto. It should sound like an exhausted truth:

> “The work isn’t the corset.
> The work is the constant calculation.”

That’s a line that women will feel in their teeth.

---

## How to keep it woman-readable (and starve the wrong audience)

When Charlie eventually “portrays it to the world,” the emotional register should be:

* grief
* anger
* clarity
* respect

Not:

* shame
* titillation
* “look at him in girl stuff”
* identity-as-spectacle

In other words: focus on **what it costs** and **who’s been paying it all along**.

Charlie’s horror isn’t “I had to wear the uniform.”
It’s “I had to *think like this* to get through a day.”

That’s your Portrait influence: the weight of looking, being looked at, and what’s unsaid.

---

## A concrete scene seed for later (not now, but to aim toward)

One day, Charlie sees a young male patron do the same “bit of fun” routine to a girl staffer—casual cruelty disguised as charm.

Charlie steps in—not as a knight, not as a hero—just as someone who recognises the script and refuses to let it run.

But instead of “defending her,” he does something more woman-centred:

He gives *her* the agency, and he disrupts the man’s entitlement quietly.

And afterward he doesn’t say, “Are you okay?” like a saviour.

He says, quietly, with devastated respect:

> “How many times a day do you do that?
> The… smoothing?”

And she answers:

> “Enough that I don’t notice anymore.”

And that’s when Charlie realises the true horror: habituation.

That’s the patriarchy’s deepest victory—making survival feel like personality.

---

## Bringing it into the upcoming “Lady of the Manor” arc

You can plant the seed immediately, lightly, by showing Charlie noticing women’s calibration in the background:

* the way Talia automatically positions her body between him and a doorway until she recognises him
* the way Mara’s tone changes depending on who’s listening
* the way donors’ wives do constant translation work for their husbands’ social rough edges

Charlie doesn’t need to comment yet. He just needs to *clock it*—and feel the slow chill of recognition.

That chill is your through-line.

---

If you want, I’ll write the next chapter as planned (promotion meeting + Celeste’s negotiation), but I’ll lace it with one or two small, quiet observations from Celeste that show she already understands this calibration world—and that bringing Charlie closer to it is both useful *and ethically loaded*. That sets you up perfectly for the grief beat later.


---

## Celeste — Promotion

They called it an invitation, which is how management liked to disguise decisions.

A note arrived on Wardrobe’s hook board just after lunch—cream paper, black ink, the kind of stationery that exists to make you behave.

**MISS SHELLEY — Please attend the Office at 2:15.**

No reason given. Reasons are for people who get to refuse.

Mara glanced at it over my shoulder and made a small sound. Not quite a laugh.

“You’ve been summoned,” she said.

“I can read,” I replied, unhooking the note.

Mara’s eyes narrowed. “They’re going to move you.”

“Why?” I asked, though I already knew.

Mara tilted her head toward the door, where the Faire’s public noise pressed against the walls like weather. “Because you don’t smile when men are stupid.”

I tucked the note into my clipboard. “That’s a skill.”

Mara’s mouth twitched. “They’ll call it ‘presence.’”

Presence. Gravitas. Poise. The words they use when they want a woman to be sharp on a leash.

Charlie was at the mending table, stitching quietly. He didn’t look up at the note. He’d learned not to chase information he hadn’t been asked to carry.

That restraint—again—was the whole problem.

I said, without turning my head, “Charlie.”

“Yes,” he answered immediately.

“Watch the room,” I said. “If anything breaks, log it. Don’t fix it unless Mara tells you to.”

Mara snorted. “As if I’d tell him to do anything.”

I didn’t react. I simply added, “If Dean comes in here, he stays at the door.”

Charlie nodded. “Yes.”

I walked out with my clipboard and my neutral face, leaving Wardrobe in that small pocket of sanity it had become.

Outside, the Faire was running on its usual mixture of illusion and compromise. Donors wandered. Patrons took photos. Staff performed cheerfulness like it was part of their costume.

I moved through it without giving anything away.

Management’s office sat in the old stone cottage at the edge of the grounds—the building that pretended it had always been there. Inside, the air smelled of paper and old coffee and decisions made too far from the people who had to carry them out.

A woman at the front desk—Janelle, I remembered—looked up and gave me a smile that belonged to her job.

“Miss Shelley. They’re ready for you.”

“They’re always ready,” I said, and stepped through.

Mr. Hawthorne was seated behind the desk like a portrait of administration: grey hair, careful posture, a suit that had never been asked to lift anything heavier than a pen. Beside him sat Mrs. Pryce, who did “guest relations,” which meant she managed rich people’s feelings.

They both smiled when I entered.

That was how I knew something was wrong.

“Celeste,” Mr. Hawthorne said warmly. “Thank you for coming.”

“I was summoned,” I replied. “It would’ve been strange not to.”

Mrs. Pryce gave a little laugh like I was charming. “Still sharp. That’s what we love about you.”

The word *love* had never meant less.

Mr. Hawthorne gestured to the chair opposite. “Please. Sit.”

I sat, clipboard on my lap, back straight. I didn’t cross my ankles; I didn’t want to look like I was waiting for permission.

Mr. Hawthorne folded his hands. “We’ve been very impressed with your performance in Wardrobe.”

“Thank you,” I said.

Mrs. Pryce leaned forward slightly, eyes bright. “Not just performance. Leadership. Presence. You’ve created… a standard.”

I kept my expression neutral. Compliments were often just the first layer of a trap.

Mr. Hawthorne nodded, as if confirming a fact. “Precisely. And it’s become clear that you’re… underutilised.”

There it was.

I didn’t react. “Wardrobe is critical.”

“Yes,” he said quickly, “of course. Absolutely. But it’s not—”

“Visible,” I finished for him.

Mrs. Pryce smiled, relieved at not having to say the ugly part out loud. “Public-facing roles suit you, Celeste. You have… elegance. Authority. And you know how to handle people.”

I thought of the men on the thoroughfare and my voice saying *This isn’t a stage for you.*

That, apparently, was what they wanted to sell.

Mr. Hawthorne tapped a folder on his desk. “We’d like to offer you a new role.”

I waited.

He spoke as though unveiling a gift.

“Lady of the Manor.”

For a fraction of a second, I pictured it: the manor house on the hill, the curated rooms, the receiving line of donors and committee members, the guided tours and staged conversations that made wealthy people feel connected to history without ever being inconvenienced by it.

It wasn’t a promotion. It was an extraction.

Mrs. Pryce’s eyes shone. “You’d be the face of the grounds. The hostess. The point of polish. It’s perfect for you.”

I let my gaze rest on Mr. Hawthorne. “Who runs Wardrobe?”

He hesitated. “We have capable staff.”

“That’s not an answer,” I said.

He cleared his throat. “Mara has experience.”

Mara’s bitterness had held Wardrobe together long before I arrived. She could do it. She would hate it. Which would make her good at it.

“And my support?” I asked, still calm.

Mrs. Pryce tilted her head. “Support?”

“As Lady of the Manor,” I said, “I will require an aide.”

Mr. Hawthorne waved a hand. “Of course. A lady’s maid will be assigned. We have several—”

“No,” I said.

The word fell flat and final.

Mr. Hawthorne blinked. “Excuse me?”

Mrs. Pryce’s smile faltered. “Celeste—”

I kept my voice level. “You can’t move me into a role that involves private spaces, donor intimacy, and public optics, and then place a stranger at my elbow.”

Mr. Hawthorne’s mouth tightened. “It’s standard.”

“Standard for who?” I asked. “For men who think any female labour is interchangeable?”

Mrs. Pryce made a small flinch, offended not by the truth but by the fact I’d said it aloud.

Mr. Hawthorne leaned forward, tone cooling. “We are trying to recognise your talent. This is an opportunity.”

“I understand,” I said. “That’s why I’m being careful.”

Mrs. Pryce’s eyes narrowed. “You don’t trust our staff?”

“I don’t trust unknown variables in private rooms,” I replied. “And neither do donors, if we’re being honest.”

Mr. Hawthorne’s gaze sharpened. “Donors?”

I let my voice soften—not into weakness, but into persuasion. “You want me donor-facing. You want polish. You want controlled atmosphere.”

I tapped my clipboard once. “Controlled atmosphere requires continuity.”

Mrs. Pryce recovered her smile, sharper now. “Celeste, darling. This is a historic environment. People expect authenticity.”

“Then you should know the historic environment was built on trusted household structures,” I replied. “Ladies did not accept random staff drifting in and out of private space. They had their own people. Their own standards.”

Mr. Hawthorne’s fingers drummed the folder. “Are you demanding to choose your maid?”

“I’m insisting on someone I already know,” I said.

Mrs. Pryce leaned back, lips pursed. “And who is this person?”

I held the beat deliberately. Let them feel the pause. Let them understand that whatever answer came next would cost me something.

Then I said, evenly, “Charlie.”

Mr. Hawthorne blinked as if I’d said *horse*.

“Charlie… Rossignol?” he asked.

“Yes.”

Mrs. Pryce’s expression tightened. “Celeste, he’s—”

“A Wardrobe worker,” I said.

“He’s a boy,” she corrected, as if I’d missed an obvious detail.

“He’s staff,” I replied.

Mr. Hawthorne’s face hardened into the shape of policy. “That’s not appropriate.”

There it was again: the word men use when they want women to rearrange themselves to suit perception.

I didn’t raise my voice.

“This isn’t about appropriateness,” I said. “It’s about function.”

Mrs. Pryce’s eyes flashed. “It’s about reputation.”

Finally. The truth.

I nodded once. “Yes. Mine. Which is why I’m managing it.”

Mr. Hawthorne leaned back. “We can’t have the Lady of the Manor shadowed by a young male attendant. Donors will talk.”

“And if donors talk,” I said, “it will be because you created a scenario where they could.”

Mrs. Pryce’s voice turned silk-sharp. “We’re trying to prevent scandal.”

“You’re trying to prevent discomfort,” I corrected. “Scandal requires intent. This requires structure.”

Mr. Hawthorne rubbed his temple as if I were a headache he hadn’t budgeted for. “Celeste. This is non-negotiable.”

I smiled slightly—my polite face, and none of my answer.

“You’re right,” I said. “The role isn’t negotiable. I accept it.”

Mrs. Pryce’s smile returned, triumphant.

Then I added, calmly, “But I won’t accept an assigned maid. I will train my own.”

The room cooled.

Mr. Hawthorne stared. “Train your own… what?”

“My own aide,” I said. “My own support. If you want authenticity, you want a household. A household has trusted people.”

Mrs. Pryce’s lips tightened. “Celeste, you’re being difficult.”

“No,” I said. “I’m being accurate.”

Mr. Hawthorne said, “You can’t bring a man into women’s spaces.”

I tilted my head. “Then don’t give me a man.”

Silence.

Mrs. Pryce’s eyes narrowed in understanding. “What are you suggesting?”

I kept my tone clinical. “Wardrobe has women. Wardrobe has performers. Wardrobe has staff who already move in those spaces. If you insist on a lady’s maid, then I will take one from Wardrobe.”

Mr. Hawthorne exhaled slowly. “And Charlie?”

I didn’t flinch. “Charlie remains attached to Wardrobe. He remains my runner. He remains my continuity on the floor.”

Mrs. Pryce stared. “You’re trying to have both.”

“Yes,” I replied.

Mr. Hawthorne’s mouth tightened. “That’s not how promotions work.”

“This isn’t a promotion,” I said. “It’s reassignment. You are moving an asset. I’m preventing operational failure.”

Mrs. Pryce’s eyes flashed again. “Celeste, you can’t possibly believe you need *him*.”

There it was: the implied insult. The idea that relying on a held-back boy from Wardrobe would diminish me.

I felt the old anger rise.

I kept it under control.

“I don’t need him,” I said. “I need the standard. He carries it.”

Mr. Hawthorne stared at me for a long beat. Then he turned his gaze toward Mrs. Pryce, as if checking whether she wanted to win this fight today or defer it.

Mrs. Pryce pressed her lips together, calculating.

Finally, Mr. Hawthorne said, “You may select a female aide from Wardrobe.”

I nodded. “Good.”

Mrs. Pryce added, quickly, “But Charlie does not enter the manor in staff capacity. He stays on the floor.”

I held her gaze.

“Understood,” I said.

It was half a concession.

It was also the opening I needed.

Because if Charlie stayed on the floor, and the floor required continuity, and the Lady of the Manor required controlled movement through public spaces—

There were ways.

I stood. “When does the role begin?”

Mr. Hawthorne’s smile returned, strained. “Immediately. We’ll announce it to senior staff by close of day. Donor dinner this weekend.”

Mrs. Pryce brightened. “You’ll be wonderful, darling. Truly.”

I gathered my clipboard. “I am always wonderful,” I said, and left before she could decide whether it was a joke.

Out in the corridor, I exhaled once—quiet and controlled. Not relief. Not fear.

Calculation.

The trap was real: they wanted me visible and isolated, polished and manageable, sharp but contained.

Fine.

I could work with that.

Back in Wardrobe, the air smelled of cloth and thread and the small comforts of competence.

Mara looked up as I entered. “Well?”

“They’ve moved me,” I said.

Mara’s eyes flicked to my face. “To where?”

“Lady of the Manor.”

Mara’s mouth curled. “Oh. They want you as a decorative weapon.”

“Yes,” I agreed.

Charlie was stitching. He didn’t look up, but I saw his needle slow by a fraction. He’d heard.

I set my clipboard down deliberately, then said, in a tone meant to keep the room calm, “Wardrobe will be reorganised.”

Mara’s eyebrows rose. “Meaning?”

“Meaning you’ll run it,” I said.

Mara’s eyes narrowed. “Do I get a say?”

“You do,” I replied. “Say yes.”

Mara made a sound that might have been laughter if she’d enjoyed anything. “You’re unbelievable.”

“I’m efficient,” I corrected.

Then I turned to Charlie.

He looked up now. His face was careful, controlled—trying not to ask a question that could reveal how much he feared the answer.

I didn’t soften.

I didn’t dramatise.

I said, simply, “Come with me.”

Charlie blinked. “Where?”

“To the back room,” I said.

His mouth tightened. “Why?”

Because the next part mattered.

Because this was where function and perception would collide.

Because I was not losing my continuity without a fight.

“Because,” I said, voice level, “we need to talk about what people will think they’re allowed to say about me.”

Charlie’s throat bobbed.

He nodded once.

And followed.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">










I'm going to assume that this next bit is where Charlie is introduced to his new role. Perhaps this might be a good time to give his character a bit more personality, but - great reveal - a largely feminine one. He expressed concern for Celeste's reputation, her employment, how scandal might affect her and her future... all without be obsequious: he is geniunely concerned for *her*. Celeste extracts from him a bit of the truth: part of his concern is because of who she is to him, and that his own future is under threat. There is some to-and-fro: Celeste prevails. The actual costume change is marked by a clinical "do this", "do that because" - much as when you described the attire a few years ago when I was first exploring this topic (if you remember).
Work for you?

---

Absolutely. And it’s the right moment to let Charlie’s personality *breathe*—not by giving him swagger, but by giving him **principled concern** and **quiet spine**.

Also: your instinct to keep the costume transition *clinical* is the most important protective measure you can take. The scene should read like:

* an HR meeting,
* a safety briefing,
* a uniform fitting for access control,

—not like a makeover.

And Charlie’s “largely feminine reveal” isn’t about his look; it’s about his *values*:

* reputational awareness,
* long-term thinking,
* protective instincts expressed through restraint,
* and a refusal to let Celeste be harmed by cheap optics.

That’s extremely woman-readable. And it’s the opposite of kink.

Below is the next scene, Celeste POV, with the to-and-fro, the extraction of truth, Celeste prevailing, and the “do this / do that because” tone.

---

## Celeste — Terms

The back room was where we kept the things that weren’t meant to be seen.

Not secret, exactly. Just… unromantic. Underlayers. Spare pins. The dull mechanics of historical illusion.

It smelled faintly of starch and lavender sachets and the honest metal tang of needles.

I shut the door behind Charlie and leaned my clipboard against the shelf. I didn’t sit. Sitting turns conversations into confessions.

Charlie stood near the centre of the room as if he’d been placed there, hands at his sides, posture careful. He looked at the closed door, then at me.

His voice came out steady, but his throat moved before the first word, betraying him.

“They moved you,” he said.

“Yes.”

He nodded once, as if he’d already done the arithmetic. “Lady of the Manor.”

“Yes.”

His mouth tightened. “They’ll put you in front of donors.”

“Yes.”

“And they’ll—” He paused, searching for the clean word. “They’ll watch you.”

I waited.

Charlie’s gaze flicked down to the floorboards, then up again. He wasn’t shy. He was… choosing accuracy.

“They won’t watch you to see if you do it well,” he said quietly. “They’ll watch you to see if they can catch you doing it wrong.”

It wasn’t melodrama. It was analysis.

The sentence landed in my chest with a cold, familiar recognition. He understood more than most people twice his age.

“Yes,” I said.

Charlie exhaled once, controlled. “And if there’s any… talk—”

“About me,” I supplied.

He flinched, not because I’d named it, but because I’d named it without embarrassment.

“Yes,” he said. “It’s not fair, but it won’t matter. It’ll stick.”

He swallowed.

“Celeste,” he added, voice low, “they’ll ruin you for sport.”

There it was: genuine concern, unperformed. Not obsequious. Not worshipful. Protective in the way women learn to be protective: by anticipating reputational harm and trying to prevent it before it exists.

I let a beat pass.

Then I asked, evenly, “Is that what you’re worried about?”

Charlie’s eyes held mine. For a moment he looked almost angry—at the situation, at the unfairness of it, at his own inability to stop it with simple logic.

“Yes,” he said. “Of course.”

“Only that?” I asked.

He blinked.

I watched him think. That was the tell with Charlie: he didn’t lie quickly. He tried to find a true sentence that didn’t cost too much.

“Also,” he admitted, quieter, “they’ll replace you.”

“They’ve tried,” I said.

“They will,” he insisted, and the insistence wasn’t rebellion—it was fear disguised as practicality. “They’ll give you someone else. A… maid. Someone who’ll be with you all day.”

“Yes,” I said again.

Charlie’s jaw tightened. His hands flexed once at his sides, like he wanted to do something useful with this helplessness.

“And then,” he said, very carefully, “where does that leave me?”

Ah.

There it was—the second truth, the one he’d been trying not to say out loud.

Not jealousy. Not entitlement.

Vulnerability.

His future had become tangled with mine. Not because he’d pursued it. Because I’d built structure around him, and now the structure was being rearranged by people who didn’t care whether he survived it.

I nodded once. “So you’re worried about my reputation and your position.”

He looked faintly ashamed, as if caring about his own survival made him selfish.

I didn’t let him wear that.

“That’s intelligent,” I said.

Charlie blinked, thrown.

“It’s the correct fear,” I added. “It means you understand how this place works.”

He swallowed. “I don’t want you… damaged,” he said, then corrected himself quickly, flustered by the intimacy of the word. “I mean—socially. Professionally.”

I let his correction sit there. Not because it amused me. Because it revealed something useful.

You can tell what someone thinks they’re allowed to want by what they apologise for wanting.

I stepped closer—not invading, simply reducing the distance enough to make the conversation unavoidable.

“Tell me,” I said, “what you think the story will be if you remain attached to me openly.”

Charlie’s face tightened. He didn’t look away.

“They’ll say you… keep a boy,” he said, and the word *keep* tasted sour in his mouth. “They’ll say you’re—”

“Improper,” I finished for him.

He nodded, jaw clenched.

“And what will they say about you?” I asked.

Charlie’s eyes flickered. “That I’m… pathetic,” he said, almost inaudible. “That I’m using you. That I’m—”

He stopped, unable to say the ugliest versions out loud.

I didn’t rescue him from it. I gave him the truth with the same clinical calm I’d used on the man at the thoroughfare.

“They’ll say you’re a joke,” I said. “And they’ll enjoy saying it.”

Charlie’s nostrils flared. A flash of anger. Good. Anger is integrity waking up.

“I don’t care what they say about me,” he muttered.

“That’s a lie,” I replied.

He froze.

I went on, still calm. “You care. Because you’re not stupid. Because you know that words become doors that close.”

Charlie’s shoulders dropped a fraction, the way someone’s do when their bluff is called and they’re relieved not to have to maintain it.

“Yes,” he admitted.

I nodded. “Good.”

Charlie stared at me, uncertain. “So what do we do?”

I picked up my clipboard again and flipped it open, as if the answer were already written. It wasn’t—but the gesture mattered. It framed the next part as policy, not drama.

“We control the optics,” I said.

Charlie’s eyes widened slightly. “How?”

I met his gaze. “You stop reading as a boy at my elbow.”

His throat moved. He went very still.

“No,” he said, immediately.

The speed of it surprised me. Not because he disobeyed—because he hadn’t disobeyed me yet, not in any meaningful way. It surprised me because the refusal wasn’t childish. It was protective.

“Celeste,” he said, voice tight, “if anyone thinks you’ve done that to me—”

“Listen,” I cut in, gently but sharp. “Stop making up a story where I’m a villain, Charlie. I don’t need rescuing from a rumour you invented.”

His face flushed. “I’m not—”

“You are,” I said, still calm. “You’re imagining the worst interpretation and trying to prevent it by sacrificing yourself pre-emptively.”

Charlie swallowed. His hands clenched, then unclenched.

“I’m trying to protect you,” he said, low.

“I know,” I replied. “But you don’t protect me by disappearing. You protect me by making the system work.”

He stared at me like he wanted to argue, but couldn’t find a point that wasn’t just fear.

I pressed.

“This is not about you becoming anything,” I said. “It is not identity. It is not performance. It is uniform.”

Charlie’s jaw worked. “Uniform,” he repeated, as if testing the word for lies.

“Yes,” I said. “Access control. Social camouflage.”

He looked down, then up again. “And what does that make me?”

I didn’t blink.

“My aide,” I said. “My attendant. My continuity.”

Charlie’s breath hitched.

“And if I say no?” he asked.

There it was—the first real boundary he’d offered me. Not defiant. Just… human.

I respected it by answering honestly.

“Then I accept a stranger,” I said. “And Wardrobe becomes a place you no longer belong, because the people above us will decide you were an indulgence.”

Charlie’s face went pale.

I watched him absorb it. Not because I enjoyed it. Because truth is the only ethical lever.

He looked at me with a kind of quiet panic now—adult panic, the fear of being made disposable.

“Celeste,” he said, “I can’t— I don’t know how to—”

“Then you’ll learn,” I replied.

His eyes flashed. “Learn *what*?”

I held his gaze. “The invisible curriculum.”

He stared, breathing shallow. “That’s not fair.”

“No,” I agreed. “It isn’t.”

We stood in the small, practical room, the shelves around us full of fabric and pins and the dull mechanics of roles.

Then Charlie said, almost pleading, “People will think you’re… doing it for fun.”

I stepped closer again, just one pace. Enough to make the next sentence land like a rule.

“People will think whatever is easiest for them,” I said. “Our job is to make it expensive for them to say it out loud.”

Charlie swallowed.

“How?” he whispered.

“By removing the spectacle,” I said. “By making it boring. By making it look like work.”

He stared at me. I could see his mind fighting—wanting the answer to be something else, something simpler, something that didn’t require his body as a solution.

But he also understood something deeper: the institution didn’t care about fairness. It cared about optics.

I turned slightly toward the shelf and took down a folded bundle.

It was not a dress. Not a fantasy. Not “pretty.”

It was a plain maid’s kit: shift, stays, petticoat, modest gown, apron, cap. Practical. Period-correct. Functional.

I placed it on the table like equipment.

Charlie’s eyes fixed on it. His face tightened.

“I won’t—” he began.

“You will,” I said, not cruelly. “Because you said you care about my future.”

His throat bobbed. “I do.”

“Then prove it,” I replied.

Charlie closed his eyes for a second, like someone bracing for cold water.

When he opened them, he looked at the kit again—less like an object of shame and more like a problem to be solved.

He spoke quietly. “If I do this… it’s not because I want it.”

“I know,” I said.

“And you’re not—” He swallowed. “You’re not making me… into something.”

“I’m not,” I said, flat. “I’m putting you in a uniform that makes men leave me alone.”

Charlie flinched, because the truth was sharp.

Then he nodded once—small, unwilling, but real.

“Alright,” he said. “Tell me what to do.”

Good.

That sentence wasn’t obedience. It was consent under constraint. Different thing. Important thing.

I kept my voice clinical, as promised—no softness, no teasing, no spectacle.

“First,” I said, “we remove your shirt and trousers. Not because this is intimate. Because underlayers can’t sit correctly over seams and buckles.”

Charlie’s ears went red. “Celeste—”

“Charlie,” I said, and the use of his name steadied him. “This room is Wardrobe. Not a story. You will not make this dramatic.”

He swallowed and nodded.

“Second,” I continued, “the shift goes on first. It’s linen. It prevents chafing and keeps outer layers clean. You will appreciate that, because you’re the kind of person who appreciates clean.”

Charlie gave a thin, reluctant exhale that might have been a laugh if he weren’t terrified.

“Third,” I said, lifting the stays, “this goes on over the shift. Not tight. Not to shape you. To support posture and distribute the weight of the gown. If you’re going to carry my standard, you don’t slouch.”

Charlie stared at the stays as if they were a device from another century—which, of course, they were.

“I can’t breathe in that,” he said.

“You can,” I replied. “Because we won’t lace it like a performance. We lace it like work.”

He swallowed. “Okay.”

“Fourth,” I said, “petticoat. It creates the line and prevents the gown from tangling your legs. You are small. If you trip, the joke writes itself. So we remove the opportunity.”

Charlie’s jaw clenched. “You really think of everything.”

“Yes,” I said. “That’s why I’m inconvenient.”

He blinked at that, startled.

I didn’t let the moment open into anything tender.

“Fifth,” I continued, “gown. Plain. Dark. No ornament. You are not here to be admired. You are here to be overlooked.”

Charlie nodded again, eyes fixed on the table, breathing controlled.

“And last,” I said, lifting the cap, “hair. Your hair is your risk. Loose hair reads romantic. Loose hair reads ‘girl.’ Loose hair invites commentary. We pin it and cap it so it reads labour.”

Charlie looked up sharply. “My hair is… romantic?”

“It can be,” I said. “And we don’t allow that.”

His mouth tightened, but he nodded.

He stood there for a moment, hands hovering uselessly near the table, as if he didn’t know where to start.

I watched him—this slender boy who had learned to carry rules like tools, now facing the realisation that women carry rules like *skin.*

He looked up again, voice small. “And if someone recognises me?”

I met his eyes.

“Then you don’t panic,” I said. “You don’t apologise. You say: *Wardrobe.* You say: *work.* And you keep moving.”

Charlie swallowed hard.

“And if they laugh?” he asked.

I paused.

Then I gave him the most honest answer I had.

“They will,” I said. “At first. And then they’ll get bored, because boredom is the only thing that starves cruelty.”

Charlie’s eyes shone with something he didn’t want to feel—fear, grief, anger, all braided together.

He looked away quickly, blinking it back into obedience.

“I hate this,” he whispered.

“I know,” I said.

He exhaled, shoulders rising and falling once.

Then he reached, finally, for the first layer.

“Tell me again,” he said quietly, “why we’re doing this.”

I watched his hands shake, just slightly, as he unfolded the linen.

I kept my voice steady, clinical, and true.

“Because they want to isolate me,” I said. “And I’m not letting them.”

Charlie nodded once.

And began.




<hr style="height:24px;border-width:0;color:pink;background-color:pink">

