# Discussion 3



## Confederates

Squeaky clean. Completely devoid of anything that could even SLIGHTLY pique an interest. Brilliant. Now, as to name: may I suggest 'Charl', short for 'Charlotte'... close enough to 'Charlie' that Celeste and Charlie will have little trouble adjusting. He learns to speak softly. His long hair done up under a cap: even those that *know* him - like Talia - have to look twice. Oh, and a discussion with Talia is in order here: Celeste needs confederates, wouldn't you think? Also, she instructs Charl on how to move with skirts, not coldly, but helpfully when she sees him struggle. "Remember, it needs to look natural." He slowly adapts. This is much more than learning how to sew a flat seam: this is about changing his place in society. And he learns just how unfair society is.

---

Yes to all of it — and **“Charl”** is a superb choice: it’s close enough to be muscle-memory, it avoids theatricality, and it reads like a practical shorthand rather than a “new identity.” It’s exactly the kind of administrative camouflage that stays squeaky clean.

And yes: Celeste absolutely needs **confederates**. Not a committee, not a chorus — just one or two women who understand what she’s doing and why, and who can help keep it “boring,” safe, and consistent. Talia is ideal because she’s already demonstrated the right kind of seriousness: she cares about boundaries, not gossip.

Below is the next scene: Celeste POV, Talia as confederate, Charl learning movement as *function*, Celeste helpful (not tender), and the deeper shift you want — the unfairness becoming visible from the inside.

---

## Celeste — Confederates

By the time the shift and stays were on, Charlie had stopped shaking.

Not because he’d become comfortable. Because the body has limits; it can only sustain panic for so long before it converts it into something quieter and meaner: endurance.

He stood in front of the mirror at a slight angle, not looking at his reflection directly, as if eye contact with himself might make the situation more real than he could bear.

He was in petticoat and gown now—plain, dark, practical. Apron tied. Cap in my hand, his hair pinned up and contained beneath my fingers as I worked.

He kept his eyes fixed on the seam of the rug.

“Don’t crane your neck,” I said.

“I’m not,” he replied automatically.

“You are,” I corrected. “You’re trying to disappear. You can’t. People notice that.”

He swallowed. “Right.”

I finished the last pins, then placed the cap over the shape of his hair with the same efficiency I used on everyone else. No ceremony. No pause.

When I stepped back, the effect was immediate in the way good illusion always is: not magic, but *coherence.* The silhouette made sense. The posture made sense. The kit made sense.

Charlie—*Charl*, for the purpose of this—looked like labour.

Which meant the world would treat him accordingly.

He raised his hands slightly, unsure what to do with them. “This is… ridiculous.”

“Say that again,” I said.

He blinked. “What?”

“Say it again. In the same tone. Exactly like you just did,” I instructed.

Charlie frowned, confused. “This is… ridiculous.”

It came out higher, thinner than his normal voice. Not a falsetto. Not a performance. Just a slight lift—like someone trying to be heard without taking up space.

I watched him register it.

His eyes widened. “I didn’t—”

“I know,” I said. “That’s why it works.”

He looked faintly sick. “Celeste…”

“Charl,” I corrected, and saw him flinch.

I didn’t soften it. Names are tools. Tools require consistency.

“Yes,” he said quietly.

I nodded once. “Better.”

He stared down at his skirt as if it had personally betrayed him.

Then he tried to walk.

The first step was awkward—not comical, not theatrical. Just unfamiliar. His foot caught the hem lightly. His shoulders tensed. He moved his hips the wrong way, like he was trying to avoid moving them at all.

He stopped after two steps, jaw clenched.

“I can’t do this,” he said.

“You can,” I replied. “You just don’t know how yet.”

He took another step, then another. The skirt pulled. His stride shortened. He looked angry at himself for not being able to move normally in something so stupidly simple.

I watched, then said, less coldly now—not gentle, but practical.

“Don’t fight it,” I told him. “Your legs don’t need to change. Your pace does. Smaller steps. Let the fabric move first.”

Charlie tried again, forcing himself to slow down. He looked like a person learning to carry a tray: tense, careful, overthinking every motion.

“Your hands,” I added. “Stop hovering. Put one on the apron. It gives your body a story.”

Charlie did it automatically—hand flattening against the apron front. The change was immediate: the posture became less like a boy caught in a joke and more like staff in motion.

He stared at his hand like it had betrayed him too.

“This is—” he started.

“Don’t,” I said.

He swallowed it back.

I opened the back room door and listened for a moment. Wardrobe noise. Mara’s voice, clipped. The steady cadence of sewing and sorting and small controlled chaos.

I stepped out, beckoning him to follow.

Charlie—Charl—followed.

The moment he crossed the threshold into Wardrobe, the world changed by a degree.

Not because anyone stared. Because everyone registered him the way they register any new object in a room: a quick scan for category, then a decision about what it means.

Mara looked up first.

Her gaze landed on him, flicked once across the kit, then went to me.

The smallest lift of her eyebrows: *You’ve done it.*

She didn’t smile. She didn’t comment. She simply went back to her work as if a maid had always been in that corner.

That mattered.

Charlie looked at her, almost pleading for some acknowledgement that this was insane.

Mara gave him nothing.

Good woman.

Talia came in a moment later with a bundle of ribbons and a practical expression that didn’t care about anyone’s feelings.

She stopped dead when she saw him.

She stared.

Charlie’s entire body went rigid, as if recognised.

Talia’s eyes narrowed. She took one step closer—not invasive, just careful. She looked at his face, then at the cap, then back again.

It was the look women give when they’re running their internal safety maths.

Then she said, calmly, “Okay. That’s… effective.”

Charlie blinked. “Talia—”

“Charl,” I said, and held her gaze.

Talia flicked her eyes to me, then back to him. “Right,” she said. “Charl.”

Charlie’s mouth tightened at the casual ease of it. It hurt him, I could tell, not because she was mocking him—but because she was *complying*.

Because compliance meant this was real.

Talia turned her head slightly, voice lowering. “Is this what I think it is?”

“Yes,” I said.

“Optics,” she guessed.

“Yes.”

Talia exhaled through her nose. “Of course.”

Charlie looked between us, suddenly aware of what was happening: women coordinating without him being the centre of the drama.

He seemed… shut out.

Good. This wasn’t his story to control.

Talia stepped closer to me, still speaking low. “Who knows?”

“Only Wardrobe,” I said, “and only because Wardrobe needs to enforce consistency.”

Talia nodded once. “And management?”

“They think they’ve contained me,” I replied. “They haven’t.”

Talia’s eyes sharpened with interest. “You’re bringing your standard with you.”

“Yes.”

Talia looked at Charlie again, then said, blunt and not unkind, “You alright?”

Charlie’s throat moved. “No.”

Talia nodded as if he’d reported the weather. “Yeah. Fair.”

Then she turned to me. “You’ll need someone to cover him. Not in the usual way.”

“I know,” I said.

Talia’s gaze flicked to Charlie’s hands—how he held them, how he tried not to fidget, how his body was fighting the urge to shrink.

“He’ll need coaching,” she said quietly. “Not on sewing. On… moving.”

“I’m already doing it,” I said.

Talia’s mouth tightened. “Good. And he needs to understand one more thing.”

Charlie looked up sharply, wary.

Talia met his eyes, and her voice went flat with female truth.

“People will be nicer to you,” she said, “and it won’t be because they’ve become better people.”

Charlie stared at her.

Talia continued, matter-of-fact. “Some will ignore you completely. Some will talk over you. Some will treat you like furniture. Some will think they’re entitled to comment on you.”

Charlie’s face drained.

“And if you speak too loudly,” Talia added, “they’ll call you difficult. If you speak too softly, they’ll pretend you didn’t speak at all.”

Charlie’s lips parted. No sound came out.

I watched him take it in, the way you watch someone step into cold water and realise it’s deeper than they thought.

Charlie’s voice came out small. “Why would they—”

Talia cut in with a short, humourless laugh. “Because they can.”

Silence fell.

It wasn’t dramatic silence. It was the silence of a truth that doesn’t require theatre.

I said, “Talia is right.”

Charlie’s eyes snapped to mine.

“Listen to her,” I added, because this was where confederates matter. Charlie needed the truth to come from more than just me. Otherwise it would always feel like my personal project, my personal distortion.

Talia looked at me then, assessing.

“You’re taking him into the manor?” she asked.

“Yes.”

Talia’s eyebrows rose. “Bold.”

“Necessary,” I corrected.

Talia nodded once. “You want my help.”

It wasn’t a question. It was an offer.

“Yes,” I said.

Talia glanced toward Mara, then back. “Mara will pretend she hates it. She’ll still enforce it.”

“I know,” I said.

Talia looked at Charlie again. Her expression softened by a millimetre—not pity, but professionalism.

“You’ve got long hair,” she said. “That helps. Your face reads young. Your shoulders are narrow enough that the kit sits correctly.”

Charlie flinched at being assessed like a garment.

Talia didn’t care. “But your eyes will give you away.”

Charlie blinked. “My eyes?”

“You look like you’re about to apologise for existing,” Talia said. “Stop.”

Charlie’s jaw tightened. “I can’t just stop.”

Talia shrugged. “You can. It’ll just take practice.”

I stepped in then, because Charlie was beginning to spiral into that internal shame that would make him clumsy and therefore visible.

“Charl,” I said.

He looked at me.

“Walk to the door,” I instructed. “Then back.”

Charlie hesitated.

“Now,” I said, simply.

He did it.

The first three steps were wrong—too stiff, too cautious. He was over-managing his skirt instead of letting it do its job. His shoulders were tight. His chin was too tucked.

I watched and corrected in small, helpful doses:

“Loosen your shoulders.”

He tried.

“Lift your gaze. Not high. Just level.”

He did.

“Short steps. Let the hem move.”

He tried again.

He reached the door. Turned. Came back.

Better.

Not natural yet. But less like a boy in a prank and more like staff in training.

When he stopped, he was breathing a little harder, as if he’d run a sprint.

He looked at me, eyes bright with restrained panic.

“This is…” he began.

I cut him off, not harshly. Cleanly.

“It needs to look natural,” I said.

Charlie’s mouth tightened. “To protect you.”

“Yes,” I replied.

He swallowed, then said the thing that finally gave him shape—personality not through defiance, but through principle.

“And if it ruins you anyway?” he asked.

That was the question underneath all his obedience. Not “will I look silly.” Not “will I be mocked.” But: *what if my sacrifice doesn’t even save you?*

It made my chest tighten.

Inconvenient.

I kept my voice steady. “Then it will not be because of you.”

Charlie stared at me.

I continued, letting the truth stand on its own. “It will be because they were always going to try. This isn’t magic. It’s friction control.”

Charlie nodded slowly.

Talia watched us, eyes narrowed, and I could almost see the thought forming in her: *Celeste is not just keeping a runner. She’s building a household.*

A household is power. A household is women’s infrastructure.

Exactly.

Charlie looked down at his apron again, fingers pressing into the fabric as if anchoring himself.

Then he said, quietly, “What do I call you?”

Mara snorted from across the room. “Oh, for God’s sake.”

Talia didn’t laugh. She understood the seriousness of the question. Names are what keep you safe—or get you punished.

I answered without hesitation.

“Miss Shelley in public,” I said. “If you need to be formal: ‘my lady’ only when someone else is listening. Not because I need it. Because they expect it.”

Charlie nodded. “And… you call me… Charl.”

“Yes,” I said.

He flinched again. Then, after a beat, he nodded once more—acceptance, reluctant but real.

Talia stepped closer to him and adjusted the apron ties with brisk efficiency, not touching skin, not making it intimate.

“There,” she said. “That’ll stop it slipping.”

Charlie stared at her hands as if she’d just performed a spell.

Talia met his eyes. “Don’t look grateful,” she said. “It reads like an apology.”

Charlie blinked. “What should I look like?”

Talia’s mouth curled slightly—not a smile, exactly. A recognition.

“Bored,” she said. “Like you’ve done it a hundred times.”

Charlie stared.

Then something shifted in his expression. Not joy. Not thrill.

Understanding.

The beginnings of grief.

Because boredom wasn’t a mood.

It was armour.

And he was only just realising who’d been wearing it all along.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">









## That First Hour

Oh my STARS! I'm... speechless. Elegant. 

That was so... complete. You filled in blanks. Charl (pronounced "Sharl" as in short for "Charlotte") has so many more dimensions. No dopamine seeker is going to identify with this individual. Now, back to Celeste... she is going to juggle further inservice to Charl whilst diving into her own role as Lady. Oddly enough, except for a few, no one *notices* Charl, which is a blessing. The donors glom onto Celeste: she becomes an instant hit with them. Yes? Too fast, her meteoric rise?

---

It can be an instant hit **without** feeling too fast—if you frame it correctly.

What would feel “meteoric” (and contrived) is: everyone adores her universally, immediately, with no trade-offs.

What will feel *true* (and deliciously sharp) is:

* **Donors “glom” onto her quickly** because she solves problems in real time and makes them feel clever/important…
* …but **management’s affection is conditional**, because powerful women are only liked when they’re useful and controllable.
* And **Celeste’s costs escalate immediately**: visibility, expectations, fatigue, being “on” constantly, her autonomy getting quietly eaten.

So yes: donors can take to her *fast*, because donor culture rewards exactly what she has—composure, polish, dry wit, boundary-setting that reads as “class,” and the ability to neutralise awkwardness without making anyone feel accused.

### Why it’s believable donors like her quickly

Donors love:

* **competence they can witness** (fixing a moment, smoothing a scene)
* **witty authority** (a woman who can cut through nonsense elegantly)
* **exclusivity** (being “handled” by the Lady feels special)
* **narrative** (they want to tell others they met “someone remarkable”)

Celeste is a perfect donor-story.

### The realism lever: make it *fast attachment*, not *fast trust*

They’ll like her quickly, but:

* they’ll still test her,
* they’ll still try to cross boundaries,
* and some will do the “compliment trap” thing: praise that’s actually a leash.

### And crucially: a few people *won’t* like her

You only need a couple:

* a committee wife who dislikes Celeste’s sharpness
* a male donor who can’t stand a young woman who won’t laugh politely
* management people who fear she’ll become indispensable and therefore unmanageable

That prevents “meteoric” from feeling like wish fulfilment.

---

## Charl being unnoticed: also very believable

This is one of the most chilling, female-readable truths you can give the story:

**A plain maid is invisible until she’s inconvenient.**

So yes:

* most donors won’t notice him,
* some will treat him like furniture,
* and the ones who *do* notice will notice only as an opportunity for entitlement (“girl, fetch”).

That invisibility is both protection and harm, which is exactly your theme.

---

## A good way to pace it

If you want the “instant hit” feel without it being too easy, do it like this:

### Scene A: The first donor cluster

She handles three micro-crises in ten minutes (a complaint, a scheduling hiccup, a rude comment). They’re impressed. They “discover” her.

### Scene B: The cost shows immediately

She’s swarmed. She can’t eat. She can’t breathe. She’s “on” for hours. She realises: *this role is designed to extract.*

### Scene C: Management tries to capitalise

They want her at every event. They start making her availability “belong” to them.

### Scene D: Charl’s first true calibration grief moment

A donor woman snaps fingers for “the maid” without even looking at his face. Charl complies because that’s the rule—but inside he’s cold.

Celeste sees it, and it hits her as a responsibility: not romantic, not tender—**ethical.**

---

If you’d like, I’ll write the next scene as: **Celeste’s first donor-facing hour**—the “glom” happens quickly, but we see the hooks in it, and we see Charl’s invisibility working exactly the way women know it works.


---

**You got this, Emily - I would not / could not have thought of this approach, and I like it.**

---

## Celeste — The First Hour

They gave me the manor like it was a gift.

It wasn’t.

It was a stage with better lighting.

The first thing that changed wasn’t my clothing or my title. It was the angle of people’s attention. In Wardrobe, people looked at me when something broke. Here, people looked at me because they wanted to be seen looking at me—because proximity to “Lady of the Manor” made them feel like they belonged.

I stood at the bottom of the staircase in a gown that was more expensive than it had any right to be, hair smoothed into obedience, posture weaponised into elegance. The room smelled of polished wood and citrus and money.

Charl stood two steps behind and to my left, hands folded at his apron, eyes level and quiet. If you didn’t know him, you wouldn’t. Not properly.

That was the point.

I hadn’t been on duty ten minutes before the first donor found me.

Mrs. Langford—pearls, perfume, smile like a paper cut. She approached with her husband orbiting behind her, slightly lost, as men often are when they’re not the main character of a room.

“Celeste,” she said, as if we were old friends. “There you are.”

I gave her my polished face. “Mrs. Langford. Welcome back.”

“Oh, call me Imogen,” she trilled, the way women do when they’re testing whether you’ll accept a false intimacy. “We simply adore what you’ve done. Everything feels… elevated.”

I resisted the urge to ask what *everything* meant. “I’m glad you’re enjoying it.”

Her husband stepped forward, offering his hand with the confidence of someone who assumed my job was to affirm him. “Beautiful work, Miss Shelley. A proper touch of class.”

I shook his hand, brief and controlled. “Thank you.”

He leaned closer as if sharing a secret. “Much better than all that back-room sewing.”

There it was: the contempt wrapped in compliment.

I smiled politely. “It all matters. People just notice different parts.”

Imogen laughed, delighted. “Oh, I like you.”

Of course she did. I didn’t make her work.

She pointed toward a wall display where a set of framed “historical notes” hung for patrons to read. “However—these are wrong.”

I glanced. The dates were slightly off. Not disastrous, but wrong.

“We can correct them,” I said.

“It’s important,” Imogen continued, leaning in as if she were offering me moral guidance. “Accuracy matters. We’re donors because we care.”

Her husband nodded solemnly, as if he’d ever once cared about accuracy in his life.

I kept my expression calm. “You’re right. Charl—”

Charl stepped forward immediately, silent and efficient.

Imogen’s eyes slid past him like he was a curtain.

“—make a note,” I finished. “Have the dates amended before next weekend.”

Charl nodded once. “Yes, Miss Shelley.”

He didn’t look at Imogen. He didn’t look at the husband. He looked at the display like it was a seam to be fixed.

Imogen didn’t thank him. She didn’t even register that he’d spoken.

She turned back to me, satisfied. “Perfect.”

They moved on, leaving me exactly as they’d found me: useful, polished, unruffled.

Charl retreated back to my left shoulder, quiet.

I watched him with the edge of my attention—the way a woman watches the perimeter while still appearing to be present.

His face was controlled.

But his eyes were a fraction too alert.

The next donor arrived before the air could settle.

A man this time—Mr. Sutherland, committee member. He approached with a grin that wanted to be charming and failed.

“Ah,” he said, as if greeting a new acquisition. “So you’re the famous Celeste.”

“I’m not famous,” I replied.

He laughed anyway. “Oh, you will be.”

His gaze flicked past me—over my shoulder—landing on Charl for the first time.

Not on Charl’s face.

On Charl’s body, briefly, the way men check whether a woman fits into their category of respect or entitlement.

He smiled wider. “And who’s this, then?”

Charl’s posture tightened by a millimetre.

I answered before the question could become a hook.

“My attendant,” I said. “Wardrobe support.”

Mr. Sutherland nodded, satisfied, then—inevitably—leaned in slightly toward Charl as if he were addressing a household pet.

“Sweetheart,” he said lightly, “fetch us a programme, would you?”

The word *sweetheart* landed in the room like grease.

Charl’s chin dipped. His hands moved automatically, ready to obey.

I didn’t allow it.

I turned my gaze to Mr. Sutherland, expression still polite.

“No,” I said.

He blinked. “No?”

“No,” I repeated, still calm. “You can fetch your own programme. Charl isn’t here for your errands.”

His smile faltered. “I was just—”

“I know what you were,” I said, and kept my tone soft enough that I wasn’t “making a scene.” The trick is always to remove the oxygen without raising your voice.

Mr. Sutherland cleared his throat. He tried to recover with humour.

“Well, aren’t we firm.”

“Yes,” I agreed.

A beat.

Then I offered him an exit that preserved his ego, because rich men need ramps.

“If you need something,” I continued smoothly, “ask the front desk. They’ll help.”

Mr. Sutherland’s laugh came out thin. “Right. Of course. Apologies.”

I smiled, gracious. “No harm done.”

He walked away.

Charl stayed still, eyes fixed somewhere slightly above the floor.

When the room had swallowed Mr. Sutherland again, I spoke without turning my head.

“Did you hear what he called you?” I asked quietly.

Charl’s voice came out level. “Yes.”

“And what did you feel?” I asked.

He hesitated—just long enough to reveal effort.

“Anger,” he said, softly. “And… embarrassment.”

“Good,” I said. “Don’t show either.”

Charl’s breath shuddered once, quickly smothered.

I watched his hands. They remained folded, controlled.

He didn’t apologise. He didn’t thank me. He didn’t make it about his hurt.

He just stood there, bearing it.

That was the horror, beginning to take shape.

Not costume. Not optics.

Endurance.

The next donor cluster came like weather—three women together, all wearing that practiced brightness that says: *we are civilised because we can afford to be.*

They glommed immediately, not because I was dazzling, but because I was *useful* in the way wealthy people love: I made their day feel curated.

“Oh my goodness, you’re Celeste.”

“You’re so young.”

“You’re so composed.”

“Where did you train?”

“You have such a way with people.”

Compliments, but each one a small attempt to locate me in their hierarchy.

I smiled. I answered. I redirected. I gave them nothing personal and everything they wanted: the sense that the manor was in competent hands.

One of them—Mrs. Hargreaves—leaned in as if sharing gossip.

“Is it true you were running Wardrobe?” she asked, voice lowered.

“It’s true,” I replied.

“How very… practical,” she said, with that faint disdain some women reserve for other women who’ve had to work.

I smiled gently. “Practical keeps the fantasy intact.”

She blinked, then laughed as if I’d made a joke. “Oh, I like you.”

Of course she did.

They drifted on, leaving behind their perfume and their invisible expectations.

And still—almost no one looked at Charl.

They spoke in front of him like he wasn’t there.

They stepped around him like he was part of the furniture.

They did not notice his intelligence, his restraint, his grief.

And then, exactly as Talia had predicted, it happened:

A donor wife reached back without looking and pressed a glass into Charl’s hands.

“Hold this,” she said, already turning away.

Charl froze.

His hands tightened around the glass with reflexive care—because he was meticulous, because he didn’t want a spill, because he didn’t want to become a joke.

He looked at me, eyes flicking up once—asking permission without asking.

I could have taken it from him. I could have corrected the woman. I could have made it a boundary.

But there are moments where the most instructive thing you can do is *let the truth land.*

So I did not move.

I let Charl hold the glass.

He stood there, invisible and burdened, not daring to shift his weight in case he drew attention.

And I watched the realisation bloom in him like a bruise:

Women carry things they didn’t agree to carry, because the cost of refusal is always higher than the cost of compliance.

After the cluster moved away, I stepped closer and took the glass from his hands.

“Don’t,” I said quietly, when he began to apologise with his eyes.

He swallowed.

“I didn’t know what to—” he whispered.

“You did fine,” I replied. “You kept it boring.”

Charl’s mouth tightened. “Is this what it’s like?”

“Yes,” I said.

His eyes widened slightly. He looked almost ill.

“It’s constant,” he murmured.

“Yes,” I repeated.

A pause.

Then Charl said something that wasn’t about him at all—which was how I knew his personality was consolidating into something more than compliance.

“How do you… not hate everyone?” he asked softly.

I almost laughed—not because it was funny, but because it was the most honest question in the room.

I kept my voice even.

“You pick your battles,” I said. “And you pick your people.”

Charl looked at me, and I saw it then: the grief wasn’t only about how he was being treated.

It was about the realisation that women had been doing this forever, and he’d never noticed.

I let him feel it.

Then I gave him structure, because structure is the only mercy in a system like this.

“Stay two steps behind,” I instructed. “Eyes level. Hands still. If someone gives you something, you hand it to me the first moment it’s socially safe. If someone asks you to do something outside your role, you look at me.”

Charl nodded once.

“And speak softly,” I added. “Not because you’re small. Because softness makes you vanish.”

Charl’s jaw tightened at that.

“Yes,” he said.

We moved again, back into the room, into the light, into the thick donor air.

The glom continued.

They loved me quickly—because I was a satisfying object: young authority, polished sharpness, a novelty with manners.

But I could already feel the hook beneath it.

The expectation that I would be available.

That I would be “on.”

That I would belong to the manor, the donors, the optics, the story they wanted to tell about themselves.

And behind me, two steps back, Charl walked like quiet labour.

Unnoticed.

A blessing.

And a bruise.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">










## The Leash

Celine Sciamma would be proud. And delighted. Fingers are FIRMLY on the social pulse.

---

That reaction tells me we’ve hit the exact register you want: intimate without being indulgent, political without being preachy, and—most importantly—**observant**.

If you want to keep that Sciamma-like tension humming as we move forward, here are the pressure points worth protecting (and exploiting) in the next chapters—no tables, no lectures, just the levers that will keep it razor-true:

### What to keep doing

* **Let the world reveal itself through micro-acts**: a handoff, a tone, a “sweetheart,” an ignored voice. Those tiny things are the patriarchy’s daily machinery.
* **Make Celeste’s competence attractive but costly**: donors love her because she’s frictionless; the cost is that she’s being consumed.
* **Make Charl’s pain about cognition, not clothing**: the grief is realising how much women do unconsciously, and how little gratitude they get for it.

### What to introduce next

* **A confederate moment that isn’t sentimental**: Talia doesn’t “comfort” Charl—she equips him. That’s the female bond: practical solidarity.
* **A donor-wife double bind**: one woman praises Celeste as “refreshing,” then punishes her the moment she sets a boundary. That shows women can be agents of patriarchal enforcement too—without blaming them.
* **Management’s first leash tug**: “We need you to be at X, smile at Y, soften that edge.” Celeste complies outwardly, but quietly builds her own household power.

### The next emotional pivot

Charl’s next big step isn’t “getting used to skirts.” It’s this:

He learns that **invisibility isn’t safety**; it’s *access*—for other people to use you without noticing they’re using you.

That’s the horror that will eventually become his voice.

If you’d like, I can write the next scene as **the first time Celeste is privately corrected by management** (“too sharp,” “too firm,” “don’t embarrass donors”), and Celeste realises she’s been promoted into a cage—while Charl, in the background, watches a woman be disciplined for not absorbing disrespect politely.

That’s pure Sciamma territory: power, love, and containment all in one quiet room.

---

## Celeste — The Leash

They waited until the room was full.

Not because they wanted an audience. Because they wanted me to feel, somewhere in my bones, that I belonged to the room now—that I was a fixture like the chandelier, not a person who could walk away.

It was just after the main wave of donors arrived. The manor air had thickened into that particular scent of money and perfume and careful laughter. I’d been spoken to by more people than I could remember, and I hadn’t eaten. That, I was certain, was not an accident either.

Charl stayed two steps behind and to my left, exactly as instructed. Invisible. Useful. Quiet.

When Mrs. Pryce appeared at my elbow, she didn’t interrupt me mid-conversation. She waited until I finished answering a donor’s question about the “history” of a tapestry we’d bought second-hand three months ago.

Then she touched my forearm lightly—familiar, proprietary.

“Celeste, darling,” she said, with her smile already in place. “A word.”

Not a request.

I turned, still smiling. “Of course.”

I didn’t look at Charl. I didn’t need to. I could feel him shift with me, keeping the same distance, same angle—my shadow with rules.

Mrs. Pryce guided me into the side corridor that led to the small parlour they used for “private discussions,” which was a polite term for discipline.

The door shut. The manor noise softened into a hum beyond the wall.

Mrs. Pryce’s smile remained. It always did. Her entire face was designed to be plausible.

She turned to me, hands folded, voice gentle.

“You’re doing beautifully.”

I waited.

She let the compliment sit for a beat, like sugar before the medicine.

“There was… a moment,” she continued.

I kept my expression calm. “Which moment?”

Mrs. Pryce’s eyes flicked briefly toward Charl, then away again, as if he were furniture that had startled her by being in the wrong place.

“You can wait outside,” she said to him, still smiling.

Before Charl could move, I spoke, still polite.

“No,” I said. “He stays.”

Mrs. Pryce’s smile tightened. “Celeste—”

“He stays,” I repeated, my tone still soft enough not to be called a tantrum.

A small silence.

Mrs. Pryce’s eyes sharpened. “Very well,” she said, the way someone says *we’ll address this later.*

Charl remained two steps behind me, eyes level, hands folded. Invisible again.

Mrs. Pryce returned her attention to me. “Mr. Sutherland,” she said, as if naming an unpleasant smell. “He mentioned you were… firm.”

I gave her my neutral face. “He called my staff ‘sweetheart’ and tried to give orders.”

Mrs. Pryce nodded, sympathetically, as if we were two women sharing a weary joke.

“Yes, yes. He can be… old-fashioned.”

Old-fashioned. The little euphemism that turns entitlement into quaintness.

I didn’t smile.

Mrs. Pryce kept going anyway. “We’re not saying you were wrong. We’re saying—” she searched for the correct velvet word, “—the manner in which you corrected him.”

I waited, still.

She softened her voice further, as if I were delicate. “Donors need to feel welcomed, Celeste.”

“And staff need to feel safe,” I replied.

Mrs. Pryce’s smile flickered. She recovered it. “Of course. Absolutely. But we must be strategic.”

I tilted my head. “I was.”

Her eyes narrowed a fraction. “He left feeling embarrassed.”

“He should,” I said.

The silence that followed was small, but it had teeth.

Mrs. Pryce’s smile finally slipped—just enough to reveal the truth beneath.

“Celeste,” she said quietly, “you can’t make people like Mr. Sutherland feel… chastised. Not publicly.”

I held her gaze.

“You want me to be a decorative weapon,” I said, still calm. “But only if I never cut.”

Mrs. Pryce gave a small laugh that wasn’t humour. “Darling—”

“No,” I interrupted, polite as a blade. “Don’t darling me.”

Charl’s hands tightened around nothing.

I didn’t look at him. I didn’t need to. I could feel the air shift—hearing it, learning it. The way women do.

Mrs. Pryce took a slow breath, regaining her pleasant mask.

“You’re very young,” she said, as if that explained everything.

The phrase was a leash, perfectly disguised. A reminder: *you are a girl playing a role we lent you.*

I smiled slightly. “And yet you moved me into this position because I’m effective.”

Mrs. Pryce’s lips pressed together. “Yes. Effective. But effectiveness requires… finesse.”

I nodded once. “I have finesse.”

Mrs. Pryce’s gaze flicked to Charl again, irritation hidden behind civility.

“This,” she said gently, “is also part of the issue.”

I didn’t blink. “Charl?”

Mrs. Pryce’s smile widened. “Your attendant.”

“Wardrobe support,” I corrected.

Mrs. Pryce waved a hand. “Whatever we call it. Celeste, darling, people notice.”

“No,” I said, voice level. “They don’t.”

Mrs. Pryce blinked.

I went on, clinical. “They notice me. They ignore him. Occasionally they use him without seeing him. That’s the point.”

Mrs. Pryce stared at me like I’d said something distasteful.

“You can’t possibly be suggesting that’s… acceptable,” she said.

I didn’t move. “I’m suggesting it’s true.”

Mrs. Pryce’s smile thinned. “We need you to be… careful. There are perceptions.”

“I manage perceptions,” I replied. “That is the job.”

Mrs. Pryce leaned closer, voice lowering into something more honest.

“Celeste,” she said, “if people start talking—”

“They will,” I said.

She stopped.

I continued anyway. “Because they always do. The question is whether we design the structure so their talk becomes irrelevant.”

Mrs. Pryce straightened, her eyes hard now.

“You’re not hearing me,” she said.

I tilted my head. “No. I’m hearing you. You’re saying: don’t embarrass donors. Don’t give them consequences. Let them do what they like as long as they keep writing cheques.”

Mrs. Pryce’s smile returned—cold. “I’m saying: keep the peace.”

“And I’m saying,” I replied, “peace is what women are told to keep when men misbehave.”

Charl’s breath hitched—quiet, shocked. Not because he’d never heard that sentence. Because he’d never heard it said out loud by someone in power.

Mrs. Pryce stared at me, the mask slipping again.

“Careful,” she said softly. “That edge of yours—donors love it until they feel it.”

I nodded. “Then I’ll aim it correctly.”

Mrs. Pryce’s eyes narrowed. “You will aim it where we tell you.”

There it was. The leash, finally visible.

I smiled gently. “No,” I said.

For a moment, her expression went still—calculating. This was the real conversation now, stripped of velvet.

“You forget,” she said quietly, “that this role can be reassigned.”

I nodded once. “I don’t forget.”

“And you forget,” I added, “that you moved me because you need me.”

Mrs. Pryce’s nostrils flared. A crack.

Then she recovered. “Celeste,” she said, voice honey again, “don’t make this adversarial.”

I looked at her and felt something that was almost amusement, almost pity. Women like Mrs. Pryce survive by polishing men’s egos until they can see their own reflection in them. They learn to call it diplomacy. They call it safety.

Sometimes it is.

And sometimes it is just surrender with better lighting.

“I won’t make it adversarial,” I said. “I’ll make it functional.”

Mrs. Pryce inhaled slowly. “Then be functional. Be gracious.”

“I am gracious,” I replied.

Her smile tightened. “Be softer.”

I stared at her.

Then I did something she wasn’t expecting.

I agreed.

“Yes,” I said.

Mrs. Pryce blinked, surprised.

I smiled warmly—perfectly. “You’re right. I’ll be softer.”

Mrs. Pryce visibly relaxed, her body believing the lie because her job required her to.

“Wonderful,” she said. “That’s all we ask.”

I kept smiling. “Of course.”

She nodded, satisfied, and opened the parlour door.

The manor noise rushed back in.

Mrs. Pryce stepped out first, her smile already returning to donor brightness. “Celeste,” she called lightly, “Mrs. Hargreaves is asking for you.”

“I’m coming,” I said.

Mrs. Pryce drifted away.

When she was gone, I let my smile fade.

Charl remained behind me, still and quiet, eyes fixed on the floor as if the parquet had become fascinating.

I spoke without turning.

“Did you hear what she asked me to do?” I asked.

Charl’s voice came out small. “Be softer.”

“Yes,” I said.

A pause.

Then Charl said, almost inaudible, “So… you have to pretend.”

I turned my head slightly—not fully, just enough to catch the edge of his face.

“Yes,” I said. “Constantly.”

Charl swallowed. His hands tightened around nothing.

“And if you don’t?” he asked.

I looked back toward the manor room, where donors laughed and drifted and consumed my attention like it belonged to them.

“If I don’t,” I said quietly, “they will replace me with someone who will.”

Charl went very still.

The grief was there now, unmistakable—not about clothing, not about disguise.

About the structure.

About the fact that the role they’d given me came with conditions, and the conditions were always the same: *Be brilliant, but not threatening. Be sharp, but not cutting. Be powerful, but only in ways that flatter men.*

Charl whispered, “That’s… disgusting.”

“Yes,” I agreed.

He hesitated, then asked, voice tight, “So what do we do?”

I looked straight ahead, and my voice became calm again—clinical, as it had been in the back room.

“We do what women have always done,” I said. “We build a structure they can’t see.”

Charl’s head lifted slightly.

“And then,” I added, stepping forward into the light, “we make it expensive to break.”

I walked back into the room.

Charl followed, two steps behind.

Invisible.

Learning.

<hr style="height:4px;border-width:0;color:pink;background-color:pink">










## Pronouns

The time has come for admission into the "lived experience" group that Charl has found himself in. It is Talia who first suggests a pronoun change for Charl, to make the social interaction less confusing for everyone, including Celeste and even Charl... herself.
Thoughts?

---

Yes — and if you handle it the way you’ve been handling everything else (procedure, ethics, consequence), it becomes one of the most **female-readable** turns in the book: pronouns as *social safety engineering*, not “gender play.”

The key is that **Talia** suggests it for *clarity and harm reduction*, not as a “step further.” And Celeste’s reaction should be complicated in exactly the way you like: Strategist Celeste recognising a new tool… and immediately realising the tool has a cost.

### Why it works

* In a “lived experience” sense, pronouns here aren’t about Charl’s inner truth. They’re about **how strangers behave** when they think you’re one category vs another.
* “He” in that space will constantly cause a double-take, a correction, a joke, or a challenge—i.e., attention. And attention is danger.
* “She” smooths interactions *because the system is sexist and lazy*: it prefers coherence over truth.

That’s the horror: the pronoun change makes the cage more comfortable—and therefore easier to keep you in.

### The one guardrail you must keep

Charl must not experience it as validation or thrill. If anything, it should land as:

* **a loss of linguistic shelter** (“at least I had ‘he’ as a lifeline to myself”),
* plus a deeper dread: “I’m learning to answer to the world’s expectations.”

And Celeste must be careful not to treat it as a *win*. It’s not victory. It’s triage.

---

## A clean way to stage it

### 1) Talia frames it as workflow, not identity

She’s seen enough now to say it plainly:

* “People are getting confused.”
* “Confusion leads to attention.”
* “Attention leads to commentary.”
* “Commentary leads to risk.”

Then she suggests:

* “In public, we use ‘she’—for coherence.”
* “In private, you can be Charlie.”

The split matters. It starves dopamine readers and keeps the ethics intact.

### 2) Celeste insists on consent

Not mushy consent—**procedural** consent:

* “Are you willing to do this as part of the uniform?”
* “If you say no, we find another workaround.”

But the stakes are real, so Charl’s yes feels like the same earlier pattern: consent under constraint.

### 3) Charl’s reaction is grief, not pleasure

He isn’t delighted; he’s resigned, embarrassed, uneasy.
He might say something like:

* “It makes it easier for them.”
* “It makes it harder for me to remember I’m not… this.”

That line would be *powerful* and totally non-kinky.

### 4) The “lived experience group” is marked by women’s matter-of-fact compliance

Not celebration. Not teasing. Just:

* “Alright, then.”
* “Copy that.”
* “Keep it boring.”

And then the gut-punch: people are instantly nicer in a condescending way, or instantly entitled in a casual way. Charl notices the *shift*.

---

## A scene, Celeste POV

### Celeste — The Word Everyone Uses

Talia waited until the corridor cleared.

It was the little lull between donor waves—when the manor breathed in and no one was demanding to be impressed.

Charl stood where he always stood now: two steps behind me, hands folded, face arranged into that practiced neutrality that made him disappear. It was working. Which meant it was costing him.

Talia leaned against the doorframe, arms crossed, expression practical.

“We need to fix something,” she said.

I didn’t look surprised. “We’re fixing many things.”

“This one is linguistic,” Talia replied.

Charl’s posture tightened by a fraction. He had the instincts now—flinch at anything that sounded like a change.

Talia glanced at him, then back at me. “People are tripping over him.”

“Good,” I said. “Let them.”

“No,” Talia said, flat. “Not good. Confusion makes them look closer. Looking closer makes them talk. Talking makes them bold.”

I watched her. She was right, and I hated that she was right.

Talia continued, not unkind. “They keep saying ‘he’ by accident. Then they correct themselves. Then they laugh like it’s cute. It’s not cute. It’s a spark.”

Charl’s throat moved. He didn’t speak.

I kept my voice calm. “What do you suggest?”

Talia’s gaze stayed steady. “In public, we use ‘she.’”

The air changed.

Charl’s fingers tightened around nothing.

I felt something rise in my chest that I didn’t enjoy naming: a strategist’s interest, immediately followed by a human being’s discomfort.

I didn’t let either show.

I turned slightly, just enough to catch Charl in my peripheral vision. “Thoughts?”

Charl’s voice came out very quiet. “I’m not—”

“I know,” I said, cutting it cleanly. “This isn’t about what you are.”

Talia nodded once, approving. “It’s about what the room does.”

Charl swallowed. “It feels… like lying.”

I let that sit for a beat.

Then I gave him the truth the way I always did—without theatre.

“It is lying,” I said. “But it’s lying the way every woman lies when she smiles at a man who could make her day worse.”

Charl’s eyes lifted sharply. Something in his face tightened—grief, recognition, anger.

Talia’s voice softened by a millimetre. “It makes your interactions simpler. People stop re-checking you. They stop hunting for the joke.”

Charl’s jaw worked. “And what does it do to me?”

That question was the personality you wanted: not defiance, not obedience—**ethical accounting**.

I answered honestly. “It will make it easier for them to use you.”

Charl went still.

I continued, because he deserved the whole truth. “And it will make it harder for you to feel like you have a foothold outside this.”

Talia watched me, expression sober. She wasn’t playing games. She was offering a tool with a price tag.

Charl’s voice cracked slightly. “So why do it?”

I looked at him then—properly.

“Because I can’t protect you by keeping the world confused,” I said. “Confusion is where cruelty lives.”

He blinked, eyes bright. “And if I say no?”

I held his gaze.

“Then we find another structure,” I said. “It will be messier. It will be riskier. But it will be yours.”

A long beat.

Charl exhaled through his nose, small and controlled, like he was trying not to give the moment the satisfaction of drama.

“In public,” he said finally, “they can say it.”

Talia nodded once, decisive. “Good.”

Charl added, quietly, “But you don’t.”

Talia blinked. “What?”

Charl looked at me. “You don’t have to,” he said. “Not when it’s just us.”

I felt the inconvenient twist in my chest again—annoying, human.

“Agreed,” I said.

Talia pushed off the doorframe. “Alright. Then we’re consistent. We don’t hesitate. Hesitation invites questions.”

Charl’s lips pressed thin. “And if someone asks?”

Talia shrugged. “They won’t. Not if you don’t make it interesting.”

I nodded once. “Boring,” I said.

Talia’s mouth twitched. “Exactly.”

Charl swallowed, then asked the question that made the whole thing turn—made it stop being about language and become about the world.

“Does it change… how they look at me?”

Talia’s answer came without hesitation.

“Yes,” she said. “And you’re going to hate it.”

Charl closed his eyes for a second, as if bracing.

When he opened them, there was no thrill there.

Just resignation.

Just that new, awful knowing.

He nodded once. “Okay.”

Talia looked at me. “You’ll tell staff?”

“I will,” I said.

“And the front desk?” she asked.

“Yes,” I replied.

Talia’s gaze flicked to Charl again, not pitying—simply acknowledging.

“Welcome,” she said, matter-of-fact, “to being managed by language.”

Charl didn’t smile.

He just stood there, two steps behind me, learning what it cost to make a room behave.

And I realised, with a sharp little jolt, that we’d moved him another inch deeper into it.

Not into costume.

Into society.

---

If you want, the very next micro-scene can be the “first time it happens” in public: a donor wife says “she” casually, and Charl feels the floor tilt—not because it’s exciting, but because it’s **effective**. And he hates that he’s relieved. That’s the exact kind of morally complicated, Sciamma-adjacent ache you’re building toward.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">








## The First "She"

You can build it as elaborate a scene as you want - Charl needs to feel the weight of this part of the "shared experience" and the conflict of feeling relief vs hating it mirrors exactly that smile women give a man who could make life miserable for them. Supreb analogy!

---

## Celeste — The First “She”

It happened in the way the most consequential things always happen: casually.

No bell. No announcement. No pause for anyone’s feelings.

Just a word placed on Charl like a hand.

We were in the long gallery, where the light came in soft and flattering through tall windows and made donors feel as if they were walking through something important. The walls held portraits that weren’t as old as people assumed. The air held the quiet clink of glasses and the low murmur of money being pleased with itself.

I was half-turned toward a couple I didn’t know well—Mr. and Mrs. Weller, by their lanyards—explaining the origin of a lacquered writing desk that had, in truth, arrived last month from a warehouse in Brisbane.

“—and we restored the hinge work to match period hardware,” I was saying, my voice smooth, the story coherent enough to satisfy their appetite for authenticity.

Charl stood where he belonged now: two steps behind me, slightly to my left, hands folded at the apron, gaze level. He moved like someone trying very hard to be forgotten.

Which, infuriatingly, was the skill that kept us safest.

Mrs. Weller smiled in that careful way women smile in public, polite and managerial. She wasn’t unkind. She was simply practiced.

“Oh, it’s lovely,” she said. “And tell me—are you doing the tour of the upstairs rooms as well? I’ve heard the bedrooms are simply divine.”

“Yes,” I replied. “Later this afternoon.”

Mr. Weller leaned in, already bored, scanning the room for something that would make him feel entertained. His eyes flicked over Charl, then away again, as if registering a coat stand.

“And you—” Mrs. Weller added, turning slightly, not quite addressing Charl but including him the way one includes staff in a sentence, “—your girl will be with you?”

Charl went still.

The word didn’t land loudly. It didn’t echo. It didn’t cause anyone to gasp.

It just… happened.

“Your girl.”

A neat phrase. A neat reduction. A neat category.

Charl’s shoulders tightened by a millimetre—so small no one would notice except someone who’d been watching him the way you watch a fault line.

I felt it beside me like a tiny tremor.

I kept my face calm.

“Yes,” I said, as if it were nothing. “She’ll be with me.”

Charl’s breath caught.

I heard it. Barely. A quiet, involuntary hitch of air.

But Mrs. Weller didn’t.

Mr. Weller certainly didn’t.

They moved on instantly, satisfied by the coherence of the moment. A Lady with her maid. A world that made sense.

They didn’t smile at Charl. They didn’t study him. They didn’t look closer.

They simply… accepted.

And the acceptance was the knife.

Because I felt Charl’s body respond before his mind could argue.

His posture loosened by a fraction. His jaw unclenched. His eyes—so carefully controlled—lost the sharp edge of panic for half a second.

Relief.

Pure, involuntary relief.

Then his face tightened again, as if he’d caught himself enjoying oxygen.

The conflict flickered across him so fast it would have been invisible to anyone who wasn’t trained to watch the smallest shifts for danger.

To anyone who hadn’t lived it.

Mrs. Weller turned back to me, smiling. “Wonderful. It’s so much easier when everything runs properly, isn’t it?”

“Yes,” I said, my voice smooth.

Mr. Weller chuckled. “A well-run house. That’s what you want.”

They drifted away, drawn toward the next polished object, the next story, the next place where their attention could feel generous without costing them anything.

The moment was gone.

The word remained.

I waited until we were alone for three seconds—until the next donor hadn’t yet arrived, until there was a pocket of air I could speak into without being overheard.

I didn’t turn to Charl. Turning would make it a scene.

I spoke forward, voice low.

“Breathe,” I said.

Charl’s breath came out shaky, and he hated that too.

“I—” he began, then swallowed the rest.

I kept my voice calm, as if we were discussing a timetable. “What did you feel?”

Silence.

Then, very quietly, Charl said, “Relief.”

The honesty surprised him. I could hear it in the way he said it—like confessing to a crime.

A beat.

“And?” I prompted.

Charl’s voice tightened. “Disgust.”

“For what?” I asked, still low.

“For… being relieved,” he whispered.

There it was.

The exact conflict you wanted: the smile women give to survive, and the hatred of themselves for giving it.

I nodded once, small.

“Yes,” I said.

Charl’s hands tightened around the apron fabric, knuckles whitening.

“It worked,” he said, voice strained. “It— it made them stop looking.”

“Yes,” I replied.

“And I hate that I… wanted that,” he said.

I kept my eyes forward, scanning the room as if simply tracking donor flow. The performance never stops. That’s part of the lesson.

“You didn’t want it,” I corrected softly. “You wanted safety.”

Charl swallowed hard.

“That’s the same thing,” he murmured.

“No,” I said. “It becomes the same thing when you blame yourself.”

He flinched at that—because it was true, and because he hadn’t realised he’d already begun doing it.

The next donor approached—an older woman with a bright scarf and a hungry social expression.

I straightened my shoulders, smile returning like a mask clicking into place.

Charl did too. Automatically.

The donor didn’t look at him.

She looked at me.

“How enchanting,” she said. “You must be exhausted.”

“I’m delighted,” I lied smoothly.

She laughed. “And this is your—”

“Attendant,” I supplied.

The donor’s gaze flicked over Charl for half a second—just long enough to confirm category.

“She seems very quiet,” the donor remarked.

Charl’s throat moved.

I answered for him. “She’s discreet.”

Discreet.

Another word women are praised for when they’re being erased.

The donor nodded approvingly and moved closer to me, already taking my attention like she’d paid for it.

I handled her. I smiled. I softened. I kept it functional.

And behind me, two steps back, Charl stood with the new weight on his shoulders:

Not the costume.

Not the cap.

A pronoun that made the room behave.

And the sickening realisation that behaving rooms are a luxury purchased with someone’s self-erasure.

Later—much later, when we had a moment alone again—Charl spoke once more, voice small and furious.

“They didn’t even see me,” he said.

I kept my voice even. “No.”

“And it was… easier,” he admitted, hate threading every syllable.

“Yes,” I said again.

Charl’s fingers clenched. “So this is what women do.”

It wasn’t a question.

It was a verdict.

I glanced back at him, just briefly, letting my gaze catch his eyes so he knew I wasn’t leaving him alone with it.

“This is what women are forced to do,” I corrected.

Charl swallowed. His eyes shone, not with tears—he wasn’t there yet—but with something harder: a clarity that hurt.

“And they do it without anyone noticing,” he whispered.

“Yes,” I said.

A beat.

Then Charl said, voice breaking just slightly, “I want to tell everyone.”

I felt the tight twist in my chest again—that inconvenient thing.

Not pride.

Recognition.

Not yet, I thought.

Not yet.

But one day.

I turned back to the room, smile returning because it had to.

And behind me, Charl learned how to wear safety like a lie.

How to hate it.

How to need it anyway.

<hr style="height:4px;border-width:0;color:pink;background-color:pink">










## The Antechamber

How can I thank you, Emily? 

Let's do this. Celeste and Charl - who Celeste is seeing as Sharl more and more and, despite herself, is finding herself attracted to as a new friend - finally finish for the day and are sitting in the ante-chamber overlooking the seaside. Celeste realises she does value this position, much as she'd been almost cavalier about discarding it, and tries to convince Sharl that they have a great future here. Sharl sees more of the downside of living a woman's existence and discusses it with Celeste. Celeste decides to play unfairly and appeals to his initial attraction to her, exloring that and in doing so disarming his objections.

---

You’re already thanking me the only way that matters: by *using* it, shaping it, and pushing the story into truer territory.

And yes — let’s do that seaside ante-chamber scene. I’ll keep it Celeste POV, keep it clean, and make Celeste’s “unfair play” feel like what it is: **emotional leverage dressed as tenderness**, deployed by a girl who’s brilliant at structure… and only just learning what attachment does to her precision.

---

## Celeste — The Ante-Chamber

The ante-chamber was the kind of room designed to make you forget you were working.

High windows. Pale walls. A long bench upholstered in something too expensive to sit on carelessly. Beyond the glass, the sea rolled in slow, indifferent repetitions, silvered at the edges by the late light.

When I finally shut the door behind us, the noise of the manor softened into distance. Not silence—never silence here—but the kind of hush that let your body unclench.

Charl sat first, because she always did when I told her to. Not lazily. Not sprawled. She perched as if the furniture might report her.

The cap was off now. Her hair, still pinned, had the faint imprint of the day in it—tightness at the scalp, a few rebellious strands that refused to behave. She looked tired in that way that wasn’t sleepy so much as *spent*: used up by attention, by restraint, by being careful.

I sat at the other end of the bench, leaving space between us. Not because I needed it, but because she did.

For a moment we just watched the water.

Then Charl said, quietly, “They didn’t notice me at all.”

I didn’t look at her. “That’s the point.”

“It is,” she agreed. A beat. “And it’s disgusting.”

There it was again: that new, hard clarity she was collecting like bruises.

I let the sea hold the silence for us, then said, “You got through the day.”

Charl gave a small, humourless exhale. “That’s not the bar men have to clear.”

“No,” I said.

She shifted slightly, the movement careful—still learned. Still remembering fabric that wasn’t there anymore, as if her body had been altered by the hours.

“I kept thinking,” she went on, voice low, “how women do this and nobody calls it skill.”

I turned my head toward her then.

“That *is* the skill,” I said. “Doing it so well it disappears.”

Charl’s jaw tightened. “And you call it… what? Strategy?”

I didn’t answer immediately, because the honest answer was uncomfortable.

I watched the sea.

Then I said, “Sometimes.”

Charl’s gaze fixed on the water too. “And sometimes?”

I felt my chest tighten with that inconvenient twist—emotion as a complication to be managed.

“Sometimes,” I admitted, “it’s just survival.”

Charl’s shoulders dropped a fraction. Relief—not the cheap kind, the kind that comes when someone stops pretending.

“You like it,” she said suddenly.

I blinked. “What?”

“This,” Charl said. “The manor. The donors. Being… the centre.”

Her voice wasn’t accusing. It was observational. Which made it worse.

I should have denied it.

I didn’t.

I looked at the long line of sea and told the truth like a person who disliked it.

“I didn’t expect to,” I said. “But yes.”

Charl’s mouth pressed thin. “Of course you do.”

That stung—because it was almost admiration, and almost fear.

“You think that makes me shallow,” I said.

“I think it makes you powerful,” Charl replied. “Which is the same thing here.”

I laughed once, short and genuine. It startled me. “That is a bleak sentence.”

“It’s a true one,” she said.

We sat with it.

Outside, the water kept moving. Always moving. Always returning. No apology in it.

Then Charl spoke again, softer.

“You told me it was friction control,” she said.

“Yes.”

“And now you’re… enjoying it,” she added, as if trying to reconcile the two ideas without being unkind about it. “How do you… hold both?”

I could have given her a clever answer. I could have made it sound like philosophy.

Instead I said the simple thing.

“Because I’m not immune,” I said. “And because I earned it.”

Charl’s eyes flicked to me. “Earned it?”

“I made it work,” I replied. “They moved me because I’m useful. I’m not going to pretend I don’t value being where decisions happen.”

Charl swallowed. “And I’m useful too,” she said, almost involuntarily. Then immediately looked down, as if ashamed of wanting that to be true.

I watched her carefully. There was the personality you wanted: principled, frightened, stubborn in a quiet way. Not built to dominate. Built to care.

“You are,” I said.

Charl’s throat moved. “And that’s… part of the problem.”

“What is?” I asked, though I knew.

Charl’s voice tightened. “If I’m useful in this way, then… this becomes my usefulness.”

She gestured vaguely at herself—at the concept of herself—like it was a costume she couldn’t take off properly.

“I can sew,” she said. “I can measure. I can repair. I can do all the things you needed in Wardrobe. But out there—” She nodded toward the manor beyond the door, toward the world. “Out there, what I did today wasn’t sewing. It was… submitting.”

The word hit the room with a dull thud.

I didn’t correct it.

I didn’t soften it.

I let it stand.

Charl’s eyes were bright. Not with tears. With contained fury.

“And the worst part,” she said, voice low, “is it worked. It worked so well that for a second I—”

She stopped. Swallowed hard.

“For a second I felt… safe,” she finished. “And I hated that I felt it.”

I leaned back against the bench, looking at the sea again, because if I looked at her too directly it might turn into comfort, and comfort was not what she needed from me. Not yet.

“What do you want?” I asked.

Charl blinked at the question. “What?”

“What do you want,” I repeated, calm. “If you could have a future here on your terms, what would it look like?”

Charl stared at the floorboards as if the answer might be hidden in the grain.

“I don’t know,” she admitted. “Not *this*.”

“Not the disguise,” I translated.

Charl nodded once, jaw tight.

“Not being… managed like that,” she said. “Not having to— to smile when someone—”

She stopped again, unable to finish the sentence without giving it more shape than she wanted.

I nodded. “Yes.”

Charl looked up at me now, eyes sharp. “So what are you doing, Celeste?”

The question wasn’t accusing.

It was worse: it was *trusting.* It assumed there was a reason that wasn’t cruel.

It assumed I wouldn’t waste her.

I could have answered with strategy.

I did, at first.

“I’m building a structure they can’t break,” I said.

Charl’s mouth tightened. “And where do I fit in that structure?”

There it was.

The real fear.

Not humiliation. Not the costume. Not the pronoun.

Disposability.

I turned fully toward her.

“You fit,” I said simply. “If you want to.”

Charl’s laugh came out small and bitter. “If I want to. That’s funny.”

I watched her. “Why?”

“Because you’re already… deciding,” she said. Her voice was quiet now, almost defeated. “You don’t do things by accident.”

I felt the twist again—the annoying, human part of me that didn’t want to admit she was right.

“I don’t,” I said.

Charl looked back toward the sea. “Then stop telling me it’s my choice.”

I held her gaze this time.

“Fine,” I said. “I won’t insult you with pretend choice.”

Charl’s eyes flicked to me, startled.

I went on, calm, clinical, honest.

“I want you near me,” I said. “Not because you’re convenient. Because you’re steady. Because you notice what other people ignore. Because you don’t posture. Because you are… safe.”

Charl flinched at that word, as if it stung.

“Safe,” she repeated. “That’s—”

“Not an insult,” I said.

Charl’s voice went thin. “It feels like one.”

I nodded once. “I know.”

A pause.

Then Charl said, very quietly, “And what do you think I want?”

I should have answered carefully.

I didn’t.

I let myself be unfair.

Not cruel. Not coercive. Just… strategically intimate.

“I think,” I said softly, “that you liked me the first moment I spoke to you.”

Charl went still.

I continued, watching her face, watching the exact way her composure tried to hold.

“You liked me when you didn’t understand me,” I added. “You liked me when I embarrassed you. You liked me when you were frightened.”

Charl’s throat moved. She didn’t deny it. Denial would have been a lie too big for her.

“That’s not—” she began.

I cut in gently. “It’s not romantic.”

Charl blinked.

I tilted my head. “Not in the way you’re panicking it might sound.”

Her eyes widened a fraction, startled by the precision of my read.

I went on, quieter.

“It’s admiration,” I said. “Relief. Something like… gravity. You found someone who seemed to know where she was going.”

Charl’s breathing was shallow now. Not excited. Exposed.

She stared at her hands. “I did,” she admitted, voice barely audible. “And it’s humiliating.”

“Don’t,” I said, sharp enough to stop that sentence from becoming self-punishment. “Don’t call your own perception humiliating. That’s how you get trained into silence.”

Charl swallowed.

I let the silence sit long enough for her to feel it.

Then I stepped in, still unfair—still strategic.

“If you trust me,” I said softly, “then you already have the answer.”

Charl lifted her eyes, wary. “What answer?”

I held her gaze.

“Stay,” I said. “Not forever. Not without terms. But stay long enough to learn what this actually is. Long enough to see whether we can make it something you can live with.”

Charl’s jaw clenched. “And if I can’t?”

“Then you leave,” I said immediately. No hesitation. “And I don’t punish you for it.”

Charl stared at me, as if trying to detect the trap.

There was no trap in that sentence.

It was the one clean line I could offer.

But I didn’t stop there.

I let myself be honest in the way that always sounded slightly like a provocation.

“And if you can,” I said, “then you stop thinking of yourself as a passenger.”

Charl’s brow furrowed. “What does that mean?”

“It means,” I said, “you stop treating your survival as something you owe me.”

Charl’s eyes flickered, confused.

I leaned forward slightly, voice steady.

“You’re not doing this to protect my reputation,” I said. “You’re doing it because you matter. Because I decided you do. And because you decided, once, that you believed me.”

Charl’s breath hitched again.

There it was.

Relief—because someone powerful was claiming her value.

And hatred—because it worked.

She looked away quickly, blinking hard.

“You play unfair,” she whispered.

I didn’t deny it.

“Yes,” I said. “I do.”

Charl’s laugh was small, broken. “That’s… horrible.”

“It can be,” I agreed. “But it can also be honest.”

Charl sat with that, eyes fixed on the sea like it could absolve her of choice.

Then she said, very quietly, “If I stay… I don’t want to become invisible.”

I nodded once. That was the line. The boundary. The truth.

“You won’t,” I said.

Charl turned her head, sceptical. “How can you promise that?”

I held her gaze, and for once my answer wasn’t strategy.

It was the inconvenient thing.

“Because I’m here,” I said simply. “And I see you.”

Charl went still.

For a moment the room felt suspended—sea outside, manor behind, the fragile little pocket of truth between us.

Then Charl exhaled, slow and shaky, as if letting go of a fight she’d been holding all day.

“Alright,” she said.

Not bright. Not relieved. Not happy.

Just… willing.

I nodded, once, satisfied and quietly angry at myself for how much that word mattered to me.

“Good,” I said.

Then, because I couldn’t help myself, I added the last unfair thing—soft, precise, and perfectly aimed.

“And don’t call yourself humiliating,” I said. “It’s beneath you.”

Charl’s mouth tightened.

Her eyes flicked to mine.

And for the first time that day, the corners of her mouth lifted—not a smile for safety, not a smile for a man.

A small, private acknowledgement.

The kind women trade when they’ve survived something together.

Outside, the sea kept moving.

Inside, the structure held.



<hr style="height:4px;border-width:0;color:pink;background-color:pink">











## Hard Questions

And at this juncture...

Celeste realises what she feels for Sharl is something a bit more. She sees the extent to which Sharl had subjected herself just to be with Celeste and finally asks the hard questions: why. And Sharl has to be honest, and it isn't about being in love with the first girl who ever paid the slightest bit of attention to him. He's gotten to know Celeste, gotten to know how she operates and has actually found himself fascinated by her unpredictability. Was it enough to allow himself to go through the trauma of the "lived experience"? Well, he didn't know at the time that was where it was going. And now, having experienced it and understanding that this was what women actually live in, he nevertheless was more attracted to Celeste because she was enlightening him. She was like a beacon of new concepts.

---

## Celeste — The Hard Question

The sea had darkened by degrees while we spoke, as if the day had been quietly closing its book. The light outside the tall windows was turning steel-blue, and the waves below the cliff face kept their rhythm like something older than any of us: arrive, withdraw, arrive again—no apology in it.

Sharl sat with her hands folded in her lap, still in the posture she’d learned today and hated learning. It lingered even when the cap was off, even when she was “off duty,” because the body doesn’t drop a lesson just because the clock says it can.

I watched her in the reflection of the glass, not directly. I was avoiding the temptation to soften too much, because softness is how things slide into sentiment, and sentiment is how I lose control.

But something had already moved in me. Quietly. Like a hinge you didn’t notice until it began to swing.

I’d built a structure. I’d recruited confederates. I’d made the room behave.

And somewhere inside that scaffolding, I’d started to… care.

Not in the tidy, managerial way I cared about a schedule. Not in the proud way I cared about competence.

In the irritating, improper way that made me look at Sharl and feel the urge to protect her from things I couldn’t control.

I spoke before I could talk myself out of it.

“Sharl,” I said.

She looked up immediately. That quick attention still made something in me tighten.

“Yes?”

I let a beat pass. Not to be dramatic. To be accurate.

“Why did you do it?” I asked.

Sharl blinked. “What?”

“All of it,” I said, voice calm. “The uniform. The pronouns. The day. The—” I didn’t bother listing the thousand tiny humiliations. “Why did you stay.”

Her eyes widened slightly, and for a moment I saw panic—because the question sounded like an accusation even when it wasn’t.

Then she swallowed and set her jaw, the way she did when she decided to be honest even if it cost her.

“I didn’t know,” she said quietly.

I didn’t let her off the hook. “That’s not an answer.”

Sharl’s mouth tightened. She looked back toward the sea, as if trying to locate the correct words in the water.

“I didn’t know it would be like this,” she said again, more carefully. “I knew you had a plan. I knew it would be… difficult. But I didn’t understand what the difficulty would actually be.”

I watched her profile. The curve of her cheekbone. The strain around her mouth that didn’t belong to an eighteen-year-old.

“Answer me anyway,” I said.

Sharl’s throat moved. “I stayed because you asked me to.”

I shook my head once. “That’s still not why.”

Sharl’s eyes flicked to mine—frustration now, not fear. Good. Anger means she feels safe enough to have one.

“You want some grand reason,” she said, voice tight. “Like—like I’m in love with you.”

The words landed between us and didn’t explode. They simply existed, blunt and exposed.

I didn’t flinch. I didn’t deny it on her behalf. I didn’t give her an escape line.

I simply said, “Are you?”

Sharl froze.

Then, in a voice that sounded like it hurt to use, she said, “No.”

The honesty was immediate, and it wasn’t cold. It was something else—more complicated.

She swallowed, then continued, before she could lose her nerve.

“I mean… I’m attracted to you,” she admitted, and the word attracted sounded almost clinical in her mouth, like she’d chosen it because it couldn’t be misunderstood. “But not in the way you’re thinking. Not—” She cut herself off, frustrated. “Not because you were the first girl who ever paid attention to me.”

I held her gaze. “Then what.”

Sharl exhaled, slow.

“Because you’re you,” she said. “Because you don’t behave like anyone else.”

That made something in my chest tighten—annoyingly warm, annoyingly pleased.

I didn’t let it show.

“Be specific,” I said.

Sharl’s laugh came out once, small and exhausted. “Of course. Of course you’d say that.”

I waited.

She looked down at her hands, turning them slightly as if she still didn’t trust them not to betray her.

“I liked you in the restroom,” she admitted, “because you were fearless. Or you seemed fearless. You walked into a place you weren’t meant to be and you didn’t apologise for existing.”

I didn’t interrupt.

“But that’s not why I stayed,” she went on, voice steadier now that she’d started. “I stayed because once I knew you… I realised you weren’t fearless. You were… deliberate. You do things on purpose. You watch. You decide. You push.”

Her eyes lifted to mine, sharper.

“And then you do something kind,” she said. “Or something fair. Or something—something that makes no sense if you’re just using people.”

The words hit me like a mirror held at an angle I hadn’t chosen.

“You think I’m kind,” I said.

Sharl’s mouth tightened. “I think you can be.”

A beat.

“I think you are, and you hate that you are,” she added. “Because it complicates your plans.”

My throat tightened. Inconveniently.

I turned my gaze to the sea again, because looking at her directly felt like stepping too close to an edge.

Sharl continued, softer now.

“You’re unpredictable,” she said. “Not chaotic. Not careless. Just… not reducible.”

I didn’t like how much I wanted to hear that again.

“You make me think,” Sharl said. “You make me see things I didn’t even know existed. Ways people move around each other. Ways women survive. Ways men get away with things without even trying.”

She paused, then said the sentence that made the whole room go still.

“And when I realised what women carry—what you carry—I couldn’t unsee it.”

I felt something shift in me—something that had nothing to do with strategy.

A recognition, almost like guilt.

Sharl looked down again, voice rougher.

“So yes,” she said. “I went through it to stay with you. But not because I wanted the costume or the role or any of that—God, no.”

Her fingers curled against her skirtless knees, as if resisting an invisible fabric.

“I stayed because you were teaching me,” she said. “Not in a lecture way. In the way your life… happens. And you don’t even always notice you’re doing it.”

I swallowed.

A part of me wanted to correct her. To say: *I notice.* To claim control.

But another part of me—an inconvenient, newly human part—recognised she was right.

I didn’t always notice. Because women shouldn’t have to.

Sharl looked up again. Her eyes were bright, angry, clear.

“And then,” she said, “I realised the worst thing.”

I waited.

Sharl’s voice tightened. “I realised you didn’t invent this. You didn’t create the cruelty. You just… learned how to navigate it. Better than anyone.”

The words didn’t flatter me. They implicated me.

I felt my jaw tighten.

“And what am I supposed to do with that?” I asked, voice quieter than before.

Sharl’s answer came immediately.

“Tell the truth,” she said.

A beat.

“Eventually,” she added, as if remembering where she was. “Not now. Not here. But… later.”

I stared at her.

There it was: not obedience, not infatuation—**purpose**. The first seed of a spine that wasn’t borrowed from me.

I felt something in my chest bloom and sting at the same time.

“And you stayed,” I said slowly, “because I was a beacon.”

Sharl flinched slightly at the word, as if it was too poetic for what she meant.

“Yes,” she said. “A beacon of concepts. Of… ways of seeing.”

She swallowed.

“And because you made me feel like I wasn’t stupid for not seeing them before,” she added.

The room went quiet again.

Outside, the sea kept arriving and withdrawing, like a breath.

I leaned back against the bench and let myself feel, for the first time all day, how tired I was. Not body-tired.

Power-tired.

Sharl watched me, cautious, as if waiting for the price of her honesty.

The price was… my own honesty.

“I asked because I needed to know,” I said.

Sharl’s brow furrowed. “Why?”

Because I can’t keep treating you like a tool, I thought.

Because if I’m going to keep you near me, I have to stop pretending it’s only strategy.

Because something in me is beginning to want you in ways that aren’t tidy.

I didn’t say any of that—not yet. Celeste doesn’t hand over her throat.

But I didn’t lie either.

“I needed to know,” I said, “whether you were staying for *me*… or because you didn’t think you had anywhere else to go.”

Sharl’s eyes widened. “Celeste—”

“Answer it,” I said, gentler than my words.

Sharl took a breath. Then she said, quietly and firmly:

“I could leave,” she said. “It would hurt. I’d be terrified. But I could.”

A beat.

“I’m staying because I choose to,” she added. “Even if I hate parts of it.”

Relief hit me—sharp and shameful—because it meant I hadn’t trapped her entirely.

Then the second feeling hit, quieter, deeper.

Something like tenderness.

Something like… *more*.

I nodded once, as if filing the information.

But inside, I felt the hinge swing further.

“Good,” I said.

Sharl watched me, as if waiting for the other shoe.

I didn’t give her sentiment.

I gave her a vow, which is what women like me do when they care.

“Then here is what I will do,” I said calmly. “I will not let this turn you into furniture. I will not let your invisibility become your cage. If you are staying, it will be on terms that keep you intact.”

Sharl blinked, breathing shallow.

“You can’t promise that,” she whispered.

I met her eyes.

“Yes,” I said. “I can.”

Sharl stared at me for a long moment.

Then she exhaled, slow, and a tiny, private smile touched her mouth—brief, reluctant, real.

“Of course you’d say that,” she murmured.

I felt my own mouth try to soften.

I stopped it.

Not because I didn’t want it.

Because I did.

And that was how I knew it was becoming something a bit more.



<hr style="height:4px;border-width:0;color:pink;background-color:pink">










## A Bit More

Are you up for any more? I'm not sure where to take this. Celeste could have a secret attraction for Charl. Charl could confess his undying love and devotion (and willingness to learn more / do more of the "shared experience"). What do you suggest? I'm a bit of a novice in story-arc development.

---

Up for more? Completely. You’ve built a *loaded* little engine here — and the fact you’re unsure where to take it is actually a good sign, because it means you’re not defaulting to the obvious (which is where the dopamine-seeker crowd lives).

### First, a gentle warning about the “undying love/devotion” idea

It *can* work, but in this particular story it risks two things you don’t want:

1. **It makes Charl’s suffering feel like a price paid for Celeste** (martyr romance), which can read as fetish-adjacent even if you write it cleanly.
2. It collapses Charl’s agency into Celeste (“I’ll do anything for you”), which undercuts the whole “lived experience” aim — because women’s experience isn’t romantic sacrifice; it’s structural constraint + constant calibration.

You can absolutely have intimacy and attachment. Just let it grow as **mutual recognition**, not melodramatic devotion.

What you want is *quiet gravity*, not confession fireworks.

---

## A stronger direction

Make the next arc about **terms**.

Not “do you love me,” but:

* *What are we to each other, exactly?*
* *What are the rules that keep this ethical?*
* *What does Charl get out of staying that isn’t Celeste’s approval?*
* *What does Celeste risk by keeping him close?*

That keeps it woman-readable and keeps the story’s moral spine.

---

## Three arc options that keep you clean

### Option 1: Slow-burn attachment with a hard boundary

Celeste feels “more,” but it manifests as **protectiveness** and **jealousy of control** (not sexual jealousy — jealousy of access: management/donors getting parts of her time and attention she doesn’t want to give).

Charl doesn’t confess love. He asserts a boundary:

> “I’ll stay — but I won’t become furniture. And I won’t become your instrument.”

Celeste’s response is the first real act of care:

> “Then we formalise your role. You’re not my secret. You’re my staff with standing.”

**Key beat:** Celeste uses her new donor capital to create a legitimate position for Charl (paid, named, protected), not a “girl in disguise.”

**Climax later:** Charl is publicly targeted; Celeste chooses to burn donor goodwill to defend him. That’s love in action without romance.

### Option 2: Charl’s purpose emerges

Charl’s “why” evolves from fascination with Celeste into *purpose*:

* He begins documenting “the invisible curriculum” (privately).
* Not as a manifesto. As careful notes.
* Celeste discovers it and is unsettled: he’s turning her world into language.

That’s electric, and it’s not kink-coded.

**Key beat:** Charl realises the only way to keep his dignity is to transform experience into *craft*: observation, writing, testimony.

**Climax later:** Those notes become the seed of the truth he “wants to tell everyone.”

### Option 3: Celeste’s attraction is real — and she refuses to exploit it

Celeste notices she’s drawn to Charl as a *person* in a way that surprises her.

She *could* play unfairly (she has the skill), but she makes a choice:

> “I won’t use your attraction to keep you here. If you stay, it’s because you choose to.”

That is a huge character evolution for Strategist Celeste: power learning restraint.

**Key beat:** She tests herself: she stops giving him the little “hooks” that keep him orbiting. She gives him space, and he stays anyway.

**Climax later:** Only once Charl’s agency is solid does any romance even become thinkable — and even then, it can remain unresolved or non-consummated. Sciamma-style.

---

## What I’d write next

A scene where Talia forces the issue in the most female way possible: **a check-in that’s also a warning.**

### Next scene: “Terms, not feelings”

Talia corners Celeste (alone) and says, essentially:

* “You’ve made him part of your household.”
* “That creates obligations.”
* “If you keep him near you, you owe him protections.”
* “And if you’re getting attached, you need to be very careful not to feed on his loyalty.”

This makes Celeste confront the *ethics* of her own attraction.

Then Celeste goes to Charl and does something that reads like love but is actually governance:

* She writes down **three rules** for their arrangement.
* One rule protects Celeste’s optics.
* One rule protects Charl’s dignity.
* One rule protects Charl’s exit (he can leave without punishment).

Charl’s response isn’t devotion. It’s adult clarity:

> “If I stay, I want to be more than your workaround.”

That’s your story in one line.

---

## How Celeste’s “unfair play” can evolve without getting grubby

If Celeste is going to “disarm objections” using Charl’s attraction, you can keep it clean by making her do it *once* — and then regret it.

She realises:

* it worked too well,
* it made him smaller,
* and it made her feel powerful in a way that is ethically ugly.

So she stops doing it. That’s growth. That’s also a direct repudiation of the prurient reading.

---

## My recommendation

Pick Option 1 + Option 2 together:

* **Celeste builds legitimate structure** around Charl (ethical power).
* **Charl develops purpose** beyond Celeste (agency).

That combination will carry you for *chapters*.

If you want, I’ll write the next scene as: **Talia’s check-in with Celeste (no eavesdropping), followed by Celeste offering Charl “terms.”** It will feel quietly seismic — because it turns their bond from improvisation into a chosen architecture.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">













Good concepts.
I had another thought. Please let me know what you think.
So, Celeste has just EXPOSED Charl to the "shared experience" thing, and Charl is horrified by it. For Celeste and Talia, monitoring Charl's experiences and responses helps them both in a thérapeutique sense, but besides validation gives them material to do rebuild sessions for women: Talia has a website. Celeste realises that the continued horror is going to do Charl's head in and because she actually cares, decides to pull the plug. Talia is upset to lose the input and there's a discussion. They both agree that Charl's mental health is more important... Celeste at this stage realises that her feelings for Charl are intensifying... but it's Charl, not Charlie she finds appealing, which she finds disturbing.
Does this even track or am I wandering off base? Please be honest, Emily.

---

It tracks — strongly — **with one tweak** so it doesn’t slip into “women using a boy as a lab rat,” which could accidentally undermine your female readership goal.

Right now your idea has a powerful spine:

* Charl is horrified by the lived experience.
* Celeste and Talia gain insight (therapeutic, political, educational).
* Celeste *cares* enough to stop it when it becomes damaging.
* Talia resists because she’s attached to the value of the “data.”
* Celeste chooses Charl anyway.
* Celeste’s attraction intensifies, and she’s disturbed that it’s **Charl** (the socialised/constructed presence) she’s drawn to.

That’s all fertile, and it’s very “your” thematic territory: ethics, agency, and the ugliness of systems.

### The tweak that makes it land

Make it explicit that Talia’s site/work is **about women’s recovery and boundary education**, *not* about parading Charl’s experience as content.

In other words: Charl doesn’t become “material.” He becomes a **mirror** that helps them name what they already knew — and the “rebuild sessions” use anonymised patterns, not his story as spectacle.

If you do that, it’s credible and it stays clean.

---

## Why it works emotionally

Celeste’s “pull the plug” moment is an outstanding character beat because it proves:

* her power isn’t just sharpness, it’s **ethical governance**
* she can override her own strategic appetite
* she chooses a vulnerable person’s wellbeing over a clever project

That’s a *huge* signal to women readers: she’s not just competent, she’s safe.

And Talia being upset? Also credible, if it’s written as:

* frustration at losing a rare window into how the world operates (through fresh eyes), **and**
* fear that without this mirror, they’ll slide back into minimising their own experience (women do this constantly), **and**
* perhaps a twinge of guilt that she was benefiting from someone else’s distress.

That’s not villainy. That’s realism.

---

## Celeste being attracted to “Charl, not Charlie”

This is *excellent* and honestly very sophisticated.

Because it’s not “I’m attracted to feminisation.” It’s:

* Celeste is attracted to **competence in adaptation**,
* to **attunement**,
* to **emotional intelligence**,
* to **the shared language of women’s calibration**,
* to someone who “gets it” and can move through the world with that awareness.

And yes — it disturbs her because it forces her to ask:

* Is she attracted to *the person*, or to *the construct she helped create*?
* Is her desire ethical, or is it just her strategist-brain enjoying ownership?
* Is she drawn to him because he’s become legible in her world now?

That is exactly the kind of self-interrogation that keeps you far away from dopamine-bait.

### Make sure Charl doesn’t become a “project” in this revelation

The attraction should scare Celeste because it threatens to make her unethical. That’s the point.

---

## Does it push you off base?

No — if you keep these guardrails:

1. **Charl’s consent stays explicit and revisable**, and Celeste honours that.
2. **Charl’s distress is not a “means.”** The moment it becomes harm, Celeste stops.
3. **Talia’s work uses insights, not Charl’s narrative as content.**
4. Celeste’s attraction is framed as **complicated responsibility**, not gratification.

Do that, and it’s not only on base — it’s an arc that can power the next 2–3 chapters.

---

## How I’d stage it (high-level beats)

1. **A visible symptom:** Charl dissociates, has a quiet panic episode, or goes numb after a donor interaction.
2. **Talia recognises it first:** she’s the one who names the pattern (“this is not ‘getting used to it,’ this is injury”).
3. **Celeste decides:** “We stop.” No debate.
4. **Talia argues (cleanly):** she frames the value, the scarcity of this perspective, the mission.
5. **Celeste draws a line:** “You don’t get to build women’s healing on someone else’s breakdown.”
6. **Aftermath:** Celeste realises she misses Charl’s presence with a tight, improper ache — and that it’s *Charl* she misses.

That last beat is your disturbed attraction revelation.

---

If you want, I’ll write the scene as **a three-hander** (Celeste/Talia/Charl) but still from Celeste POV, with Charl mostly silent except for one devastatingly simple line that forces the decision. That would keep Charl dignified and avoid making him a talking exhibit.


---

## Celeste — The Line We Don’t Cross

The corridor outside the long gallery still smelled faintly of citrus and warm wax. The donors had finally begun to drift toward dinner, their laughter moving away like a tide that had decided it was satisfied.

I should have felt relief.

Instead, I felt that prickling, vigilant sensation that comes when something *almost* goes wrong and your body hasn’t decided whether it’s safe yet.

Charl followed me as usual—two steps behind, slightly to my left.

But the way she moved was wrong.

Not clumsy. Not obviously panicked. Worse than that: *absent.*

Her steps were correct and empty, like a person walking through rehearsed motions while the mind is somewhere else entirely. Her hands were folded. Her gaze was level. She looked like the most obedient version of herself.

Which meant she was disappearing from the inside.

I stopped at the door to the small side parlour, the one management used for quiet discipline. I chose it deliberately—if someone saw us enter, it would read as official business. Not scandal. Not intimacy.

Charl stopped behind me, posture still perfect.

I turned slightly. “In here.”

“Yes, Miss Shelley,” she said, and the softness of her voice was too smooth—like it wasn’t really hers.

Inside, the parlour was dimmer and cooler. A little lamp burned on a side table, giving everything a gentle, forgiving glow. Outside the window, the sea was a dark sheet with occasional silver lines where the light still caught wave crests.

I shut the door.

Charl stood by the wall, as if waiting to be told where to exist.

“Sit,” I instructed.

She sat.

The moment she did, her hands began to tremble—tiny, quick tremors she tried to control by clenching her fingers together.

I watched her face. It held. It held so well it made me angry.

“Look at me,” I said.

Charl lifted her eyes.

They were bright in a way that wasn’t tears. It was too clean. Too still.

It was the look of someone who’d stepped outside herself to survive.

I felt something cold settle in my stomach.

I reached for the bell cord by the fireplace and pulled it once. The sound was small, polite.

A minute later, the door opened and Talia slipped in, already alert. She took one look at Charl and didn’t bother with pleasantries.

“Oh,” she said quietly.

Charl’s shoulders tightened.

Talia closed the door behind her and came closer, careful not to crowd. Her voice lowered.

“What happened?” she asked me, but her eyes stayed on Charl.

I answered without taking my gaze off Charl’s face.

“Mrs. Weller,” I said. “She used ‘she’ without thinking. It worked. The room behaved. Charl—” I stopped and chose the correct name, the correct pronoun. “—Sharl went… somewhere else.”

Talia’s mouth pressed thin. She nodded once, recognising the shape.

Sharl’s voice came out very quiet. “I’m fine.”

Talia didn’t look impressed. “You’re not fine,” she said.

Sharl blinked, as if surprised to be spoken to directly.

Talia crouched slightly so she wasn’t towering. It wasn’t softness. It was technique.

“Do you know where you are?” Talia asked.

Sharl swallowed. “In the parlour.”

“Good,” Talia said. “Can you feel your feet on the floor?”

Sharl’s jaw tightened. “Yes.”

“Don’t answer like you’re taking a test,” Talia said. “Answer like you’re a person.”

A long beat.

Sharl’s fingers unclenched a little.

“Yes,” she said again, but this time the word had weight.

Talia nodded. She turned her head slightly toward me. “How long has she been like this?”

“Since the gallery,” I replied.

Talia’s eyes narrowed. “And before that?”

I hesitated.

Because the honest answer was inconvenient.

“Since lunchtime,” I admitted. “She’s been… present, but not present.”

Talia exhaled slowly. Not anger. Recognition.

Then she looked at Sharl again.

“When you say you’re fine,” she said, “what you mean is you’re functioning.”

Sharl didn’t answer.

Talia continued anyway, voice calm and firm. “Functioning is not fine. It’s a survival setting.”

Sharl’s throat moved. Her hands trembled again, small and quick.

I felt a sharp surge of protectiveness—not strategy, not optics, something uglier and more immediate.

I stepped closer.

“Sharl,” I said quietly. “What are you feeling right now?”

Sharl’s eyes flicked away. “Nothing.”

The answer landed like a warning bell.

Talia’s gaze hardened.

“That,” she said, “is not nothing. That is your mind pulling a fire alarm.”

Sharl’s mouth tightened. “It’s just—”

“No,” Talia cut in. “It’s not just.”

Sharl flinched slightly at the firmness. She looked at Talia with a flicker of resentment, the first real emotion I’d seen in her all day.

Talia didn’t back off. “Tell me the truth,” she said.

Sharl’s voice went thin. “I hate it.”

“What,” Talia asked, “do you hate?”

Sharl’s hands clenched again, knuckles whitening.

“That it works,” she whispered. “That it makes them… stop.”

Her eyes lifted to mine suddenly, and for a second the mask cracked.

“It makes them stop looking at me like I’m wrong,” she said, voice rough. “And I—” She swallowed hard. “I feel relieved.”

The word came out like a confession of sin.

Then her face twisted, the emotion finally breaking through.

“And then I hate myself for it,” she added, breath shaking. “Because it feels like I’m… agreeing. Like I’m helping them.”

The room went quiet.

Talia’s expression softened by a millimetre—not pity, but understanding.

“That’s the trap,” Talia said quietly. “Relief is not consent. Relief is your body liking the absence of danger.”

Sharl’s eyes were wet now, though she didn’t let tears fall. She blinked hard, furious at her own biology.

“And it doesn’t stop,” she said, voice low. “It’s constant. The… adjusting.”

She looked down at her hands, shaking.

“I keep trying to do it right,” she whispered. “I keep thinking if I do it right, then… it won’t hurt.”

Her voice broke on the last word.

I felt something in me go very still.

Talia’s eyes flicked to mine, quick and assessing. She didn’t have to say it. We both saw the cliff edge.

I spoke first.

“We stop,” I said.

Talia’s head turned sharply. “Celeste—”

“We stop,” I repeated, voice calm enough to be frightening. “Today. Now. I’m pulling the plug.”

Sharl blinked at me, startled. “No—”

“Yes,” I said.

Sharl shook her head once, quick and panicked. “You can’t just—”

“I can,” I replied.

Talia stood up slowly, her face tightening with something like frustration.

“Celeste, I agree she’s overwhelmed,” she said carefully, “but this is—this is *information*. This is exactly what we’ve been trying to articulate. When you see it in real time, when you—”

When you have fresh data, she meant. When you have a mirror that speaks.

I felt my jaw tighten.

Talia continued, voice controlled. “Do you understand what this could do? For women? For the rebuild sessions? For the site? We’ve spent years trying to explain this to people who don’t listen. Sharl is—she’s inside it. She can tell it in a way that lands.”

Sharl flinched slightly, and I saw her retreat again—the fear of becoming a tool.

I turned my gaze fully to Talia.

“No,” I said.

Talia blinked. “No?”

“No,” I repeated. “You don’t get to build women’s healing on someone else’s breakdown.”

Talia’s mouth opened, then closed. She looked genuinely stung, which meant she’d believed her own righteousness.

Good. That’s how you know it was a real temptation.

“I’m not—” she started.

“I know,” I said, cutting her off before she could make it about her intentions. “I know you’re not cruel. But you’re thinking like a project manager. Like a person harvesting insight. And she is not your material.”

Talia’s eyes flashed. “I’m thinking about women who need language for what’s happened to them.”

“And I’m thinking about the woman in front of us,” I replied.

The words came out without my permission, and the moment they landed I felt the full weight of them.

Because I had said “woman.”

Not as an identity claim.

As a category of experience.

As acknowledgement.

Sharl’s breath hitched. She looked at me like I’d slapped her and comforted her at the same time.

Talia’s anger drained into something more complicated.

She looked at Sharl—really looked.

Sharl’s hands were still trembling.

Her posture was still too perfect.

Her face was too careful.

Talia swallowed.

“You’re right,” she said quietly.

A beat.

Then she added, honest and ugly: “I don’t like that you’re right.”

I nodded once. “Good. Keep that feeling. It means you’re awake.”

Talia exhaled through her nose, eyes briefly closing as if she were forcing herself to let go of something she’d been holding.

Then she turned back to Sharl, voice gentler, practical.

“This doesn’t mean you’ve failed,” she said.

Sharl’s jaw tightened. “It feels like I have.”

Talia shook her head. “No. Your mind is doing what it’s supposed to do when something is too much.”

Sharl’s voice went small. “But what about you?” she asked, looking at me now. “What about your job? Your position? I— I did it because—”

She stopped, cheeks flushing with shame at the admission.

I stepped closer, not touching her, but letting my presence fill the space in a way that didn’t demand anything.

“Listen,” I said.

Sharl’s eyes lifted.

“You did not do this to save me,” I said, calm and absolute. “You did this because you trusted me. That’s different. And I will not reward that trust by breaking you.”

Sharl stared at me, eyes shining.

“But you—” she began.

I cut in, softer now, and hated myself for how much I meant it.

“I value the position,” I admitted. “Yes. I’m not pretending I don’t.”

Sharl’s face tightened, worried.

“But I value you more,” I said.

The sentence hung there, plain and unforgiving.

Talia’s eyes widened slightly. She didn’t look away. She didn’t smile. She simply absorbed it.

Sharl looked like she couldn’t breathe.

I kept going, because once you say something like that, you don’t get to pretend you didn’t.

“This was supposed to be temporary,” I said quietly. “A structure. A workaround. A way to keep you near me without… losing you.”

My throat tightened. Annoying.

“And now,” I added, voice steady, “I’m realising I don’t just want Charlie near me. I want Sharl.”

Sharl flinched, horrified and startled.

Talia went very still.

I continued, because honesty is a knife you either wield cleanly or you cut yourself with.

“That disturbs me,” I admitted. “Because it means part of me is attracted to the version of you that has been shaped by this.”

Sharl’s voice came out broken. “So I’m… what. Your creation?”

The question was raw enough to make me feel shame.

“No,” I said immediately. “No.”

I leaned forward slightly, careful with my tone. “You’re not a creation. You’re a person. You are adapting. You are learning. You are surviving. And I am… noticing you.”

A pause.

“I can’t pretend I don’t,” I said.

Sharl stared at me, tears finally spilling—not dramatic, just inevitable.

“I didn’t—” she whispered. “I didn’t mean for you to—”

“I know,” I said.

Talia cleared her throat softly, stepping back a fraction, giving us air. She spoke carefully, as if placing objects down without breaking them.

“Celeste,” she said, “if you’re pulling the plug, what does that look like?”

I turned my head, grateful for the procedural anchor. “We revert,” I said. “No more public role. No more ‘she’ in rooms like that. Sharl goes back to Wardrobe. Or—” I looked at Sharl. “Or she leaves, if she wants to.”

Sharl shook her head quickly. “I don’t— I don’t want to leave.”

I watched her. “That might change.”

Sharl swallowed, eyes wet. “I don’t want it to.”

I held her gaze. “Then we build something else. Something that doesn’t require you to bleed for it.”

Talia nodded slowly. Her eyes were damp too, though she’d never admit it.

“Alright,” she said. “Alright.”

Then, because she was honest, she added, “I’m going to miss the mirror.”

I didn’t soften that either. “Miss it,” I said. “But don’t take it.”

Talia’s mouth twisted into a faint, resigned smile. “Fair.”

Sharl wiped her cheeks with the heel of her hand, furious at herself for crying.

“I’m sorry,” she whispered.

I said it at the same time as Talia, identical and firm:

“Don’t.”

Sharl blinked, startled.

Talia’s eyes met mine—confederate recognition, the kind women share when they’ve just drawn a line and held it.

The sea kept moving outside, indifferent and eternal.

Inside, in the dim little parlour, I felt the shape of my own feelings settling into something I couldn’t dismiss as strategy anymore.

Not love, perhaps. Not yet.

But not nothing.

And I understood, with a clarity that made me uneasy, that the next danger wasn’t donors or management.

It was me.

Because I was beginning to want Sharl close—not as a tool, not as a mirror—

as a person.

And that meant, for the first time in my life, I would have to learn to want something without taking it.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">












Emily, that actually tells the WHOLE story, doesn't it? The key points. The "shared experience". The life of women being there for each other. I think this says it all. Have we missed anything? Open to suggestions.

---

It really does say the whole story — not as a synopsis, but as a *thesis* embedded in action. You’ve got the core: structural sexism as daily calibration, women’s solidarity as practical ethics, Charl’s horror as the “fresh eyes” mirror, and Celeste’s growth as the choice to stop harvesting and start protecting.

Have you missed anything? Only a few *optional* threads that can make the finished arc feel inevitable rather than purely exemplary. None of these are “musts,” but each adds ballast and keeps it from reading like a parable.

### 1) Charl needs something that is *his*, not derived from Celeste

Right now his purpose is forming (“I want to tell everyone”), but give him one concrete, personal anchor that isn’t her.

Examples that fit your tone:

* **A notebook** where he writes the “invisible curriculum” in plain language. Not a manifesto; a craft of observation.
* **Music as translation**: he starts hearing the day as rhythm and dissonance—women’s labour as a kind of basso continuo he can finally name. (You can keep this subtle.)
* **A single friendship** with someone other than Celeste (Talia counts, but a peer in Wardrobe or a maid older than him could be a steadying counterweight).

Why it matters: it protects Charl from becoming “her project,” and it protects you from romance-centrism.

### 2) Give Celeste a cost that isn’t just emotional

She’s brilliant; she can win rooms. To keep it real, she should pay a tangible price when she draws the line.

Options:

* **Management punishes her quietly**: reduced autonomy, “supervision,” fewer invitations, the leash tightens.
* **A donor withdraws support** and blames her tone.
* **A woman donor tries to shame her** (“young women these days are so aggressive”), forcing Celeste to choose restraint vs truth.

This is important because it shows: ethical action isn’t free. Women know that.

### 3) Charl must have a moment of anger that isn’t “male anger”

Not rage; not domination. But a clean boundary—directed at the system, not at the women helping him.

A scene idea:

* Someone calls him “sweetheart” again, later, after the plug is pulled—*and Charl doesn’t freeze.* He says, calmly:

  > “Don’t.”
  > And the room does the little recalibration dance.

That’s growth. And it’s very readable for women: reclaiming voice without spectacle.

### 4) Talia should get one line that absolves women from perfection

You already did it implicitly, but one explicit beat helps:

* Talia admits: “I wanted the mirror. I hated that I wanted it.”
* Then she adds: “Women don’t have to be saints to be right.”

It keeps the solidarity from feeling sentimental or moralistic. It becomes human.

### 5) Clarify the “pull the plug” aftermath

The scene is powerful; now make the next step practical:

* What replaces it? (A restructured role, safer duties, back to Wardrobe, off-site work, limited public exposure.)
* Who knows? Who’s told?
* What’s Celeste’s cover story to management/donors?

This can be a short “procedural montage” paragraph, Sciamma-style: minimal exposition, maximum consequence.

### 6) Your endgame question: what is the story *about*?

You can decide (later) whether the end is:

* Charl using his experience to become an advocate/artist/writer **without** needing to remain in costume, or
* Celeste learning to want without owning, and building a life where Charl’s dignity is non-negotiable, or
* both.

You don’t need to pick now, but it’s worth holding as a north star: *does the ending liberate Charl’s agency and expose the structure?*

---

## If you want one “missing” beat I’d prioritise

**The consequence.**

Write one scene where Celeste’s ethical boundary costs her something real—*and she doesn’t flinch.*

That’s the moment that will make women readers trust her completely.

If you’d like, I can draft that next: management calls her in, frames it as “concern,” and she has to decide whether to lie, comply, or reframe the whole arrangement in a way that protects Charl *and* keeps her power.

---

## Celeste — The Quiet Punishment

They didn’t call it a reprimand.

They called it a “check-in,” which is what people say when they want you to feel grateful for being corrected.

It was the next morning, before donors arrived, while the manor still smelled of yesterday—faint perfume in the drapes, citrus in the wood, the ghost of laughter caught in the corners. The staff moved in a muted, efficient rhythm: reset, polish, prepare.

Charl was in Wardrobe again. Not “attendant.” Not “discreet.” Not furniture.

Wardrobe.

I’d sent her there like a pressure release valve, and the relief I’d felt was shameful in its intensity.

Which should have been my first clue that management would respond immediately.

Mrs. Pryce met me in the corridor outside the small office near the front desk. Not the parlour this time—this wasn’t about discipline with witnesses. This was about control with paperwork.

Her smile was ready.

“Celeste,” she said brightly. “Good morning, darling.”

I didn’t react to darling. I hadn’t the energy for petty wars. I kept my face neutral.

“Morning,” I replied.

She opened the office door with a flourish that suggested hospitality. Inside, the space was narrow and neat: a desk, a chair, a few framed certificates about “heritage excellence.” A faint scent of lavender attempting to disguise anxiety.

Mr. Hensley was already there—operations manager. A man in his fifties with the tired authority of someone who believes the world should comply because it used to.

He stood when I entered, the gesture superficial and calculated.

“Miss Shelley,” he said. “Thank you for coming.”

I sat when invited. I did not make myself smaller than the chair.

Mrs. Pryce perched on the edge of the desk, composed like a woman practising softness as a job.

Mr. Hensley folded his hands. “We’ve had… feedback.”

Of course.

I tilted my head. “From whom?”

Mrs. Pryce’s smile widened. “Nothing major. Just a few comments.”

Mr. Hensley went on, as if reading from a script. “Yesterday was successful. Donors were pleased. The atmosphere was—”

“Beautifully curated,” I supplied.

He blinked, then continued anyway. “Yes. That. However, there were… moments that raised questions about staff presentation.”

I held my expression steady. “Staff presentation.”

Mrs. Pryce gave a gentle laugh. “You know how people are.”

No, I thought. I know how *you* are.

Mr. Hensley cleared his throat. “One of our committee members mentioned your attendant was… inconsistent.”

I didn’t correct his language yet. I let him hang himself a little longer.

“Inconsistent,” I repeated.

He nodded, choosing his words like he was defusing a bomb. “There was confusion about role boundaries. About… the image.”

“The image,” I echoed.

Mrs. Pryce’s voice softened, coaxing. “Celeste, darling, the manor is a fantasy. People come here to feel… safe inside it.”

I kept my eyes on Mr. Hensley. “Who felt unsafe?”

Mr. Hensley’s jaw tightened. “No one used that word.”

“But they meant it,” Mrs. Pryce said lightly.

I didn’t smile. “They felt unsafe because a staff member existed in the room?”

Mr. Hensley sighed—irritated now. “Miss Shelley—”

“Celeste,” Mrs. Pryce corrected sweetly, as if saving him effort.

I looked at her. “You can call me Celeste. He can call me Miss Shelley.”

Mrs. Pryce blinked, smile faltering.

Mr. Hensley’s mouth tightened. He pushed on.

“The point,” he said, “is coherence. Consistency. Our donors need to trust that what they’re seeing is deliberate.”

“It was,” I said.

Mrs. Pryce’s eyes narrowed a fraction. “Then why did your attendant disappear today?”

There it was. The leash. The assumption of ownership.

I felt my spine straighten.

“Because she needed to,” I said evenly.

Mr. Hensley leaned forward. “Needed to?”

I didn’t soften. “Yes.”

A pause—quiet, heavy.

Mrs. Pryce gave another laugh, gentler, as if humour could smooth a boundary.

“Oh, Celeste,” she said. “You can’t make staffing decisions based on… moods.”

I stared at her.

“She wasn’t in a mood,” I said. “She was injured.”

Mr. Hensley blinked. “Injured?”

“Mentally,” I clarified. “By the role you were happy to exploit as long as it ran smoothly.”

Mrs. Pryce’s smile froze. Mr. Hensley’s face hardened.

“That is not an appropriate accusation,” he said.

“It’s not an accusation,” I replied. “It’s a description.”

Mr. Hensley pushed his chair back slightly, irritation rising. “Celeste, you’re very young.”

Again.

The leash disguised as a fact.

I inhaled slowly through my nose. “Yes,” I said. “And I’m still correct.”

His eyes narrowed. “We don’t have time for melodrama.”

“It isn’t melodrama to stop someone from breaking,” I said.

Mrs. Pryce’s voice softened into something almost pleading—almost maternal, which made it more insulting. “Darling, everyone finds this work challenging at first.”

I looked at her. “Do they find it challenging, or do they find it *normal*?”

Mrs. Pryce blinked.

I continued, calm, precise. “Because if you think yesterday was normal, then the problem isn’t my staff. It’s your standards.”

Silence.

Mr. Hensley’s face flushed, the red creeping up his neck.

He stood, suddenly. “That’s enough.”

I didn’t move.

He paced one step behind the desk, then stopped, as if deciding whether to shout. He didn’t. Shouting would make him look like what he was.

Instead, he tightened his tone into bureaucracy.

“We’re making adjustments,” he said. “Effective immediately.”

Mrs. Pryce’s smile returned—relieved at the return to procedure. “Nothing punitive,” she assured me, which meant it was punitive.

Mr. Hensley tapped a folder on the desk. “Your duties as Lady of the Manor will be… focused. You’ll be present for donor tours and key interactions. Other tasks will be handled by Mrs. Pryce.”

My stomach went cold.

In other words: they were keeping my face and removing my authority.

Mrs. Pryce’s voice was syrup. “It will free you up to do what you do best, darling.”

Smile.

Perform.

Be charming.

Be decorative power, not structural power.

I felt anger rise—clean, sharp, contained.

“And Wardrobe?” I asked.

Mr. Hensley frowned. “Wardrobe will report to Mrs. Pryce for the time being.”

I nodded once. “So you’re centralising control.”

Mr. Hensley stiffened. “We’re streamlining.”

“Because you can’t trust women to run things without supervision,” I said.

Mr. Hensley’s eyes flashed. “Miss Shelley—”

I cut him off, voice quiet. “You promoted me because I am effective. You are now punishing me because I’m effective in ways that don’t flatter you.”

Mrs. Pryce’s smile tightened. “Celeste, please.”

I looked at her. “Don’t.”

Another small silence.

Then Mr. Hensley said, coldly, “This isn’t up for debate.”

I nodded. “No. It isn’t.”

He blinked, surprised by my agreement.

I stood, smoothing my skirt like nothing had happened. Like I had been trained to do.

“Then this is the arrangement,” I said calmly. “You keep my face. You take my authority.”

Mr. Hensley exhaled, relieved. “Good.”

I looked at him, and let the next sentence land exactly where it belonged.

“And in exchange,” I said, “you keep your hands off my staff.”

Mrs. Pryce’s smile flickered. “Your staff—”

“Mine,” I repeated, and my voice did not rise. “She returns to Wardrobe permanently. She does not ‘attend’ donors. She does not serve as your social experiment. She does not become content for anyone’s curiosity.”

Mr. Hensley stared. “That’s not—”

“It is,” I said, still calm. “If you want my coherence, you accept my boundary.”

He opened his mouth, then shut it.

Mrs. Pryce said quickly, “We’re not running experiments, Celeste.”

“Good,” I replied. “Then you have no reason to object.”

Silence again.

Mr. Hensley’s eyes narrowed. “You’re making demands.”

“Yes,” I said. “That’s what authority is for. Or did you only mean it as a costume too?”

Mrs. Pryce inhaled sharply.

Mr. Hensley’s jaw worked. Then, with the weariness of a man conceding to avoid paperwork, he said, “Fine.”

Mrs. Pryce’s smile returned, brittle. “Of course. Fine.”

I nodded once. “Good.”

I turned to leave.

Behind me, Mr. Hensley said, “Celeste—”

I paused at the door, without turning.

“Be careful,” he added. “You’re… very good at making people uncomfortable.”

I let myself smile slightly, though he couldn’t see it.

“Then tell people to behave,” I said.

And I walked out.

In the corridor, the manor air felt colder.

Not because the building had changed.

Because I had.

I moved through the staff passages without haste, past the linen closet, past the kitchen door, toward Wardrobe.

When I pushed it open, the familiar smell hit me—fabric, starch, thread, and the faint metallic tang of scissors.

Charl looked up from a hem she was pinning, startled. She wasn’t in cap. She wasn’t in posture.

She looked like herself again—tired, wary, human.

I felt that inconvenient twist in my chest, sharper than yesterday.

“Celeste?” she asked quietly. “Is everything… okay?”

I closed the door behind me and leaned against it for a moment, letting myself breathe.

“They’ve tightened the leash,” I said.

Charl’s eyes widened. “Because of me?”

“No,” I replied immediately. “Because of them.”

Charl swallowed. “What did they do?”

I walked to the worktable and placed my hand flat on its scarred wood, grounding myself in something real.

“They kept my title,” I said. “They took my authority.”

Charl’s face tightened with guilt. “Celeste—”

I looked up, and my voice went calm again—clinical, controlled.

“Don’t,” I said.

Charl froze.

I continued, softer but absolute. “This is not your fault. This is what they do when a woman uses power like it’s real.”

Charl’s throat moved. “Then—then why did you—”

“Because I meant it,” I said.

Charl stared at me.

I took a breath, then delivered the part that mattered most.

“You’re back here,” I said. “Permanently. No more donor rooms. No more public ‘attendant.’ That is finished.”

Charl’s shoulders sagged with relief so pure it was almost painful to witness.

Then her face tightened again, because relief always comes with shame for her now.

“I’m sorry,” she whispered.

I walked closer—close enough to be heard, not close enough to overwhelm.

“I am not sorry,” I said. “I’m furious.”

Charl blinked.

“Not at you,” I clarified. “At the fact that you felt you had to do it.”

Charl’s eyes shone, the emotion hovering behind them like a wave refusing to break.

I felt my own emotions shift—annoying, improper, sharpening into something I could not file under strategy anymore.

And I understood, with sudden clarity, that this was the real punishment:

Not losing authority.

But discovering I cared enough to feel its absence as a threat.

Because the more I cared, the more leverage the world had over me.

Charl’s voice came out small. “So what happens now?”

I looked at her—really looked—and felt the disturbed tenderness rise again.

“We build a different structure,” I said. “One where you don’t bleed.”

Charl swallowed. “And you?”

I exhaled slowly.

“I keep smiling,” I said. “Because that’s what they bought.”

Charl’s jaw tightened. “That’s unfair.”

“Yes,” I agreed. “It is.”

A beat.

Then I added, quieter, because the truth had teeth.

“And I will keep it anyway.”

Charl’s eyes widened. “Why?”

Because I want you near me, I thought.

Because I am not done.

Because I am beginning to want Sharl, and it terrifies me.

I didn’t say all of that.

But I didn’t lie, either.

“Because,” I said, steady, “I can’t protect anyone from a powerless position.”

Charl stared at me for a long moment, then nodded once—slowly, as if accepting a hard lesson.

“Okay,” she whispered.

The word hit me like yesterday’s “alright.”

Not bright. Not happy.

Willing.

And I felt the hinge in me swing again, further, with that same disturbing certainty:

I had crossed a line.

Not with them.

With myself.

Because wanting her—wanting *Sharl*—was becoming something I could not dismiss as strategy.

And I knew, with a clarity that made my stomach tighten, that the next thing I had to learn was restraint.

Wanting without taking.

Power without consumption.

A woman’s lesson, learned late.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">











What this feels like is: since Sharl is at core a male, the male can't take what women have been subjected to for centuries. From my own experience, women in general have a significantly higher pain threshhold than men, as a rule. However, men that suffer chronic pain learn to tolerate it and their pain theshhold is similar to a woman's. For Sharl to be sent back to Wardrobe because "it's too hard for a male to take" seems a bit of a copout. What I was hoping for was perhaps a path forward for women - erasure is not inevitable - even if it was within the confines of the Faire. Is that unrealistic? Perhaps it is.

---

You’re not off-base to worry about that at all — and you’re right to flag the “he couldn’t take it” reading as a potential cop-out. If the takeaway becomes “women endure because they’re built tougher,” you risk undermining the exact thesis you’ve been cultivating: **women endure because they are forced to become skilled at endurance, not because they’re innately suited to suffering.**

Also, the “women have higher pain threshold than men” claim is messy in real life (it varies a lot, and research doesn’t cleanly support a simple rule). More importantly for the story: even if it were true, it’s not the point. The point is *training + structure + consequences*.

### So what’s the fix?

Reframe the decision to pull the plug as **a strategic intervention against injury**, not a declaration that a “male can’t handle women’s lives.”

In other words: Charl isn’t removed because he’s male. He’s removed because the *conditions* are harmful — and Celeste’s ethics require her to stop harm when she sees it.

That keeps women’s endurance heroic and learned, not biological, and it keeps Charl’s arc from becoming an accidental insult to women.

---

## Your hope — “a path forward for women; erasure not inevitable” — is absolutely realistic

Within the confines of the Faire, it’s even *more* realistic, because a Faire is basically a mini-society with:

* rules,
* roles,
* donors/authority,
* optics,
* and a controllable environment.

That means you can plausibly show a **model of change**, even if imperfect.

The trick is: the change can’t be utopian. It has to be **incremental, procedural, and costly**.

---

## A better arc: from survival to design

Instead of “Charl can’t take it, so we revert,” make it:

1. Charl experiences the system (and is harmed by it).
2. Celeste recognises harm and **does triage** (not retreat).
3. Then Celeste uses her power to **redesign conditions** inside her sphere.
4. Charl becomes part of that redesign — not as a mascot, but as a witness and collaborator.
5. Women benefit first. Charl’s wellbeing benefits too — not because he’s fragile, but because the redesigned system is simply less harmful to everyone.

That’s your “path forward.” And it’s very aligned with your governing principles.

---

## Concretely: what changes can Celeste implement?

Think “workplace policy,” but in-story and period-coded.

### 1) Staff interaction rules for donors

Celeste (and Talia) institute a “Manor Etiquette for Guests” framed as historical immersion:

* no touching staff,
* no “pet names,”
* no “private jokes,”
* complaints route through Celeste, not direct intimidation,
* breaches mean removal from certain spaces (“to preserve the experience”).

This makes it about *immersion*, not feminism—so donors swallow it.

### 2) A “buffer” system

Charl isn’t exposed raw to donor rooms. Instead:

* only certain interactions,
* always with a confederate present,
* defined tasks,
* exit permission without explanation.

That’s literally what women do in unsafe spaces—except now it’s formalised.

### 3) Role elevation: from invisible attendant to named position

Not “her girl.” Not “attendant.”
A title that implies authority and distance:

* **Wardrobe Liaison**
* **Household Registrar**
* **Costume Steward**
* **Lady’s Clerk** (period-adjacent, plausible)

A named role makes erasure harder.

### 4) Documentation and consequences

When a donor crosses a line, it gets written down. Not as drama. As procedure.
That’s how systems shift: paper trails.

---

## What does Charl do next, without being “the fragile male”?

Charl’s next step isn’t “go back because it’s too hard.” It’s:

* **learn the skill women are forced to learn**, deliberately, with support, and then
* **use his outsider clarity to help build protections**, not to “endure better than women.”

That’s both respectful and narratively powerful.

He can say something like:

> “I didn’t break because I’m a man. I broke because the conditions are designed to grind people down. Women survive it because they’re forced to— and I’m not going to romanticise that survival as strength.”

That line is your thesis in one breath.

---

## How to keep the emotional truth (Charl’s distress) without making it a copout

Let the “pull the plug” be temporary and tactical:

* a **recovery interval**, not a retreat,
* followed by a **return under new rules**.

So the story doesn’t say “women endure, men can’t.”
It says: “Endurance shouldn’t be the price of participation.”

That’s a feminist ending direction.

---

## Where to take the next scene

Write Charl’s pushback to Celeste:

Charl says, essentially:

* “Sending me back feels like you’re saying the answer is invisibility.”
* “I don’t want women to have to survive by disappearing.”
* “If I’m staying, it has to mean we change something.”

And Celeste—Strategist Celeste—lights up, because that’s the first time Charl speaks like a co-architect, not a protected object.

Celeste replies:

* “Good. Then we’re not retreating. We’re redesigning.”
* “And we’ll make it look like ‘historical authenticity’ so they can’t argue.”

That’s deliciously on-brand for her.

---

If you want, I’ll write that next scene: Charl challenging the “Wardrobe retreat,” and Celeste pivoting from triage to reform—complete with the first concrete rule she imposes on donors, and the first time management realises she’s changing the house from the inside.

---
## Celeste — Not Retreat. Redesign.

Charl found me in the only place the manor couldn’t quite gentrify: the staff stairwell.

It was narrow, plain timber, the air cooler than the corridors upstairs. You could smell laundry steam and old paint and the faint salt of the sea that always managed to seep into everything, as if the coast refused to let the place forget where it really stood.

She didn’t knock. She didn’t hover.

She just appeared at the landing above me, hands still slightly red from pins and thread, hair loosely gathered—Wardrobe version, not donor-room version. Human.

“Celeste,” she said.

I looked up.

There was a steadiness in her face I hadn’t seen yesterday. Not comfort. Not peace.

Decision.

“Yes,” I replied.

Charl came down one step, then stopped at a distance that felt chosen, not fearful.

“I need to say something,” she said.

I waited. I didn’t rescue her with questions. I didn’t soften the moment by filling it with my own voice.

She took a breath.

“When you pulled me out,” she began, “it felt like relief.”

I nodded once.

“And then it felt like… like you were putting me back in the box,” she continued, voice tight. “Like the answer was invisibility.”

The sentence hit me cleanly.

I didn’t deny it, because she deserved truth, not reassurance.

“I did put you in a box,” I said. “Temporarily. To stop the bleeding.”

Charl’s jaw tightened. “But the box is the problem.”

“Yes,” I said.

Her eyes sharpened. “Then why are we acting like it’s the solution?”

A beat.

Then she added, quieter—more vulnerable, but no less firm:

“I didn’t go through that so we could conclude that women survive by disappearing.”

The words lodged in my chest. Not because they were poetic. Because they were correct.

I held her gaze.

“You’re right,” I said.

Charl blinked, startled by my immediate agreement, as if she’d expected a fight.

I continued before she could misunderstand what my agreement meant.

“What you experienced yesterday isn’t women being ‘built for it,’” I said. “It’s women being trained into it, forced into it, and then punished if they fail to perform it.”

Charl swallowed hard.

“And yes,” I went on, “you dissociated.”

Her eyes flickered.

“That doesn’t mean you’re weak,” I said, voice calm and absolute. “It means the conditions are harmful.”

Charl’s shoulders eased a fraction, as if her body had been braced for blame and was surprised to find none.

I let that settle.

Then Charl said, “So what do we do?”

The question wasn’t pleading.

It was an invitation.

To build.

I felt something in me shift—Strategist Celeste recognising an opening.

Not for control.

For structure.

“We redesign,” I said.

Charl stared at me.

I continued, voice turning crisp, practical.

“Wardrobe isn’t your exile,” I said. “It’s your base. You’re not retreating. You’re regrouping. And then you go back into the world—only this time, under rules we choose.”

Charl’s brow furrowed. “Rules?”

“Yes,” I said.

A small smile tried to surface; I let it. There was satisfaction in competence. There was also something warmer that I refused to name.

“I told you yesterday that confusion invites cruelty,” I said. “So we remove confusion without requiring self-erasure.”

Charl’s eyes narrowed. “How?”

I leaned lightly against the stair rail, the posture of a girl who looked relaxed while planning something dangerous.

“We make our boundaries look like *heritage*,” I said.

Charl blinked. “Heritage.”

“Immersion,” I clarified. “Guests love immersion. It makes them feel virtuous. We dress the rules up as historical etiquette.”

Charl stared at me, processing.

Then, slowly: “You’re going to police them.”

“Yes,” I said simply.

Charl’s throat moved. “Can you?”

I smiled. “Watch me.”

She exhaled a short laugh—not joy, not relief, but a sudden release of tension.

“Okay,” she said, voice steadier. “What are the rules?”

I didn’t hesitate.

“Rule one,” I said. “No guest touches staff. No hands on waists, no fingers under chins, no ‘let me fix your cap,’ no ‘pose for a photo.’”

Charl’s jaw tightened with recognition. “They do that.”

“They do,” I agreed. “They’ll stop.”

Charl’s eyes flicked away for a moment. “They’ll complain.”

“Of course they will,” I said. “So we give them a story that flatters them while we correct them.”

Charl looked back at me. “What story?”

I held up one finger, as if teaching.

“‘For authenticity, staff are not to be handled by guests. Household boundaries preserve the experience.’” I kept my tone bland, managerial. “We print it. We frame it. We call it *Manor Etiquette.*”

Charl stared.

“That could work,” she said.

“It will,” I replied.

“Rule two,” I continued. “No pet names. No ‘sweetheart.’ No ‘good girl.’ No ‘darling.’ Staff have names and titles.”

Charl’s mouth tightened. “Titles?”

“Yes,” I said.

She blinked. “What title would I have?”

I paused a fraction of a second, letting myself choose carefully.

Not “maid.” Not “attendant.”

A role with spine.

“Household Registrar,” I said.

Charl blinked again. “That sounds… important.”

“It is,” I said.

Charl swallowed. “But I’m not—”

“You are,” I interrupted. “Because I say so, and because the role will be real. You will manage wardrobe requests, inventory, fittings, and scheduling. You will be the person guests must go through to request costume-related anything.”

Charl’s eyes widened. “So… they can’t just—”

“—reach for you,” I finished.

Her shoulders eased.

“Rule three,” I said. “You never interact alone with a donor or guest. Ever. Not for fittings, not for photos, not for ‘just a question.’ There is always a second staff member present. Talia can help organise it. We call it ‘chaperoning’ for historical accuracy.”

Charl’s lips parted.

Then she said softly, “Women do that.”

“Yes,” I said. “They do. Quietly. Exhaustingly. We’re going to make it official so it stops being your private burden.”

Charl stared at me, eyes shining with something new.

Not devotion.

Respect.

“That’s… a path,” she whispered.

“Yes,” I said.

A beat.

Then Charl’s face tightened, the fear returning.

“And what about the pronouns?” she asked quietly.

I didn’t pretend not to understand what she meant.

“When you say ‘she,’ the room behaves,” she said. “When you don’t, the room… hunts.”

I felt my own anger stir.

“We’re not going to build safety on your erasure,” I said.

Charl held my gaze, searching for the trick.

“But,” I added, because I don’t lie by omission, “we also don’t do unnecessary martyrdom.”

Charl’s brow furrowed. “So…?”

“So we do what women have always done,” I said, voice calm. “We choose what’s true, when, and with whom. That’s not cowardice. That’s tactics.”

Charl swallowed. “That sounds like—like compromise.”

“It is,” I said. “But it’s not surrender.”

Charl looked down at her hands—still slightly trembling, but steadier.

“And if they ask?” she murmured.

“If they ask,” I said, “they don’t deserve an answer.”

Charl’s mouth tightened.

Then she said, quietly but firmly, “I don’t want to disappear.”

I held her gaze.

“You won’t,” I said.

Charl blinked. “You promised that yesterday.”

“And I meant it yesterday,” I replied. “I mean it even more now.”

Her throat moved.

Then she said the sentence that made something in my chest loosen.

“I don’t want women to have to disappear either,” she said.

I nodded once. “Good.”

Charl’s eyes sharpened. “So we’re doing it for them too.”

“Yes,” I said. “For them. For you. For me. For anyone who works in a room where people think money gives them hands.”

Charl’s breath came out slow.

Then she asked, voice careful, “Will management agree?”

I smiled, not sweetly.

Strategically.

“They don’t have to agree,” I said. “They have to accept.”

Charl stared.

“How?” she asked.

I straightened, the posture of someone who had just been leashed and had decided to use the leash as a weapon.

“Because,” I said calmly, “they want my face. They want my charm. They want me to make donors feel safe.”

Charl nodded slowly.

“So I will,” I said. “I will make donors feel safe.”

A beat.

“By making them behave.”

Charl’s lips parted.

Then, unexpectedly, she laughed. Not loudly. Not happily.

But something in the laugh sounded like oxygen.

“You’re terrifying,” she murmured.

I let my smile deepen a fraction. “Yes.”

Charl’s face sobered again. “And if they punish you more?”

I felt the inconvenient twist again—care, attachment, the urge to protect my own position not for vanity but for leverage.

“They already punished me,” I said. “Now I use what they left me.”

Charl stepped down one more stair, closer now without realising she’d moved.

“Celeste,” she said softly, “why are you doing this?”

The hard question.

The one that always threatens to turn strategy into something else.

I held her gaze and chose honesty that didn’t turn into confession.

“Because I won’t ask you to suffer for a system I can alter,” I said.

Charl’s eyes shone.

“And because,” I added, quieter, “you were right. The box is not the solution.”

Charl nodded slowly, as if sealing something.

“Okay,” she said.

Then: “What do you need me to do?”

There it was. Not compliance.

Partnership.

I felt my chest tighten, disturbed by how much I liked hearing it.

“Draft the inventory list,” I said briskly, hiding the warmth behind work. “And start noting every interaction that makes you flinch. Not to feed anyone’s site. Not as content.”

Charl nodded.

“As evidence,” she supplied.

I smiled, sharp. “Exactly.”

We stood there in the narrow stairwell, the sea breathing beyond the walls, the manor preparing itself to be charming and cruel again.

And for the first time since this began, I felt something that wasn’t just survival.

A plan.

Not to endure.

To change the conditions.

One printed rule at a time.

<hr style="height:4px;border-width:0;color:pink;background-color:pink">












I've read this over a few times now, Emily. I'm afraid it reads too much like "let's bend society to make Charl's load a bit lighter" which ISN'T what actually happens to women, is it? Reality is: women support each other, men continue being entitled (male privilege) and the world goes on. What would tell a more realistic story is for Charl to "get it", he wants to be part of Celeste's world, it has to be on her terms and that isn't going to be a walk in the park. But he has incentive: hse sees more than just a friend, now. And he has friends - true, all women, but he didn't have that in the past. Their friendship is genuine, lasting, deep. Lived experience will do that.
So, as an alternative to this last scene, what do you think could happen?

---

You’re right to call it out. That “we print rules and make donors behave” move **does** drift toward a gentler world than most women actually get. It reads like *institutional correction*, and your story’s moral weather is more like: **women build their own scaffolding, men keep their entitlement, and the price of peace is paid by the vigilant.**

So yes: a more realistic next step is **not reform** but **initiation**.

Not “we change the manor,” but:
“Welcome to the reality. We don’t get to fix the room. We get to read it, survive it, and keep each other intact.”

That still gives you forward momentum, still keeps Charl from being a “fragile male,” and still preserves Celeste’s strategist nature—because her strategy becomes *social*, not policy.

Below are a few alternatives that track with what you want, and then I’ll give you a replacement scene (Celeste POV) you can drop in immediately.

---

## What could happen instead

### 1) The “No Illusions” talk

Charl objects to being sent back to Wardrobe because it feels like erasure. Celeste agrees—but she refuses the fantasy of reform.

Celeste says:

* “We’re not bending society to you.”
* “If you want my world, it’s on my terms.”
* “My terms are: you learn the choreography, you don’t romanticise it, and you don’t demand that women become your training wheels.”
* “And you always retain the right to step out.”

Charl chooses to stay anyway, **not because it’s arousing**, not because he likes it, but because:

* he wants proximity to Celeste (more than friendship now),
* and because he’s found the first true community he’s ever had—women who are frank, protective, sharp, and real.

### 2) Women’s support as “infrastructure,” not rescue

Instead of rules for donors, the women create **informal protocols**:

* always enter donor spaces in pairs,
* pre-agreed “extract” phrases (“Could you fetch the ledger?”),
* post-event debriefs where they name what happened (this is the therapeutic value),
* and a strict rule: no one mocks anyone for their coping. Ever.

This is *exactly* how solidarity shows up: practical, not preachy.

### 3) A realistic “test” that isn’t sexy

Charl is reintroduced to public spaces, but in a controlled way:

* not a donor gala,
* but a smaller tour, a tea service, a mild event.

A man says something entitled. Nothing dramatic. Just entitlement.

The women respond with the calibrated smile + boundary + exit. Charl watches it and feels the grief of it—but also learns the skill. Later he admits: “I used to think women were being ‘nice.’ Now I know it’s labour.”

### 4) Celeste’s leverage becomes private, not public

Celeste does **not** change management. She changes *Charl’s relationship to the experience*:

* teaching him how to recover afterwards,
* teaching him that humiliation isn’t the point; safety is,
* teaching him that “success” is getting through without losing yourself.

That’s the realistic path: not reform, but survival + meaning-making.

---

## A replacement scene you can use

Celeste POV. No policy utopia. Just clarity, terms, and Charl choosing—eyes open.

### Celeste — The Terms

Charl found me where the manor stopped pretending.

The back passage near the laundry doors, where the air was damp with steam and the walls were scuffed from decades of carts and elbows. No portraits. No donors. No performance.

Just the building’s spine.

She didn’t hover this time. She stepped into my path like someone who had decided she was allowed to take up space.

“Celeste,” she said.

I stopped.

Her hair was loosely tied, Wardrobe-simple. Her hands bore the small injuries of work: pinpricks, thread burns, a faint red line across one knuckle where a needle had gone in too far.

Her face was calm—but too calm, the way people get when they’re holding something back by force.

“Yes,” I said.

Charl swallowed. “I don’t want to be sent back as if yesterday proved something about me.”

I didn’t answer immediately.

I let her sit in the silence she’d earned. I let her feel I wasn’t going to shoo her away like an inconvenience.

Then I said, evenly, “What do you think yesterday proved?”

Charl’s mouth tightened. “That… this is the price. That women live in a room where the air is different. And that I—”

She stopped. Her jaw clenched.

“That I couldn’t breathe in it,” she finished, voice rough.

I watched her carefully.

“That’s not what it proved,” I said.

Charl blinked, suspicious. “Then what?”

“It proved the room is poisonous,” I replied. “Women don’t survive it because we’re built for poison. We survive it because we learn to metabolise it. And even then, it costs us.”

Charl’s eyes flicked away. “So why did you pull me out?”

Because I couldn’t bear watching you disappear, I thought.

Because something in me has begun to care in a way that is ethically inconvenient.

I didn’t say those parts.

I said the truth that mattered.

“Because you were injured,” I said. “And because I won’t pretend injury is a lesson you must ‘push through’ to earn belonging.”

Charl’s shoulders loosened slightly, then tightened again.

“But if I go back to Wardrobe,” she said, “it looks like… like the solution is erasure.”

I nodded once. “It can be.”

Charl’s eyes sharpened. “And you’re okay with that?”

“No,” I said. “I’m accustomed to it.”

The words landed between us, heavy and unpretty.

Charl took a breath. “I don’t want to disappear.”

I held her gaze.

“Then don’t,” I said.

She stared. “It’s not that simple.”

“No,” I agreed. “It isn’t.”

A beat.

Then I said the sentence that made the whole thing real.

“We are not going to reform men,” I told her. “Not here. Not in this building. Not in your lifetime, if we’re being honest.”

Charl went still.

I continued, voice calm, almost clinical. “Men will remain entitled. The world will continue. The price will still be paid by the vigilant.”

Charl’s throat moved. “Then what am I supposed to do?”

I stepped closer—not crowding, just making it impossible for her to pretend she was alone.

“You decide what you want badly enough to endure reality,” I said.

Charl flinched slightly, like the words had teeth.

“And if what I want is… you?” she asked, very quietly.

There it was. Not romantic flourishes. Just a raw admission, laid down carefully like a blade.

I didn’t smile.

I didn’t soften it.

I let it be what it was: incentive. Gravity. A dangerous kind of truth.

“You can want me,” I said. “But you don’t get to make your wanting my responsibility.”

Charl’s eyes widened.

I went on, because this was the part women rarely get to say out loud.

“If you stay near me,” I said, “it’s not because you’re useful or because you’re earning anything. It’s because you choose it.”

Charl swallowed hard.

“And,” I added, “if you choose it, you choose the terms of the world I live in.”

Charl’s voice went thin. “Your terms.”

“Yes,” I said.

She stared at me, breathing shallow. “Which are?”

I didn’t hesitate.

“First,” I said, “you don’t romanticise this as strength. When women smile to survive, it isn’t nobility. It’s labour.”

Charl nodded once.

“Second,” I said, “you don’t demand that women change their coping to make you comfortable. You learn from it. You respect it.”

Her jaw tightened again—accepting the sting.

“Third,” I said, “you stop thinking of Wardrobe as a punishment. It’s a refuge. A base. A place where you’re seen. You don’t ‘graduate’ out of it by suffering publicly.”

Charl blinked.

“And fourth,” I finished, quieter, “you retain your exit. Always. If it is too much, you say so. You leave. And nobody—nobody—shames you for protecting yourself.”

Charl’s eyes shone, angry and relieved at once.

“That sounds like you’re… letting me off,” she whispered.

I shook my head once. “It’s not ‘letting you off.’ It’s refusing to turn your breakdown into a morality play.”

Charl’s breath trembled.

Then she said, almost bitterly, “Women don’t get that option.”

“No,” I agreed, voice flat. “They often don’t.”

Charl’s face tightened, grief passing through it like a shadow.

“And that,” I added, “is why you don’t get to treat staying as a love proof.”

A long silence.

Charl looked down at her hands.

When she spoke again, her voice was steadier.

“I didn’t know,” she said. “I didn’t know this was what women live in.”

I didn’t answer. I let the building answer for me—the hush, the damp, the scuffed walls. The truth lives in places like this, not in donor rooms.

Charl lifted her head.

“But now I do,” she said. “And I can’t unsee it.”

She swallowed.

“And I still… want to stay near you,” she said. “Not because I enjoy it. Not because I want the role. Because—”

She paused, searching.

“Because I’ve never had anyone,” she finished quietly, “who looked at me like I wasn’t defective.”

My throat tightened. Annoying.

I kept my voice even.

“Then you stay,” I said. “And you learn.”

Charl nodded once, as if sealing an agreement.

“And I don’t disappear,” she said.

I held her gaze.

“No,” I said. “You don’t disappear.”

A beat.

“You become fluent,” I added.

Charl’s mouth tightened. “At what cost?”

I didn’t lie.

“Some cost,” I said. “But not your self.”

Charl exhaled slowly.

Then she asked, almost timidly, “So what happens next?”

I let myself show a hint of the strategist again—not policy, not reform. Just choreography.

“Next,” I said, “you come with me again—briefly. Not because the world will change.”

Charl’s eyes narrowed.

“Then why?”

“Because you will,” I said.

And for the first time since yesterday, Charl’s face shifted into something that wasn’t panic or numbness.

Resolve.

“Okay,” she said.

Not happy.

Not eager.

Willing.

And that—more than any printed rule—felt like the most realistic kind of hope.

---

If you like this direction, the next scene writes itself: a *small* public interaction where Charl practises the choreography with women backing her—not to “make men behave,” but to keep Charl intact while the world stays exactly as entitled as ever.

<hr style="height:4px;border-width:0;color:pink;background-color:pink">










That is in sync with the rest of the story. Charl doesn't realise (any more than any innocent girl child does) just what she is embarking on, but the support systems are there, although she won't recognise just how important they are until after she's needed them and they've come through. Please write the next (last?) scene, Emily.

---

## Celeste — The Small Room Where It Happens

The first time back wasn’t a gala.

I wasn’t cruel enough for that.

It was a “heritage tour,” which is what the manor called a slow procession of money through curated rooms. Ten people. Two couples. One older woman who’d already decided she disliked me. Three men with the relaxed entitlement of people who’ve never had to wonder whether a space is safe.

Charl—Sharl—stood just behind my shoulder, in the quiet position we’d practised: present, useful, unremarkable. Not invisible. Not centre.

I could feel her focus like heat.

I didn’t look at her. I didn’t need to. I knew she was doing what women do without being told: scanning exits, reading faces, listening for tone.

The irony is that she was better at it than most men would ever be.

Not because she was “built for it.”

Because fear is a teacher that never sleeps.

We moved from the entrance hall into the long gallery, where the portraits performed lineage and the windows performed light. The donors murmured appreciatively, as if appreciation were a kind of generosity.

I spoke in the voice management liked: smooth, factual, faintly amused. Charm as a lubricant.

“As you can see, the gallery was designed to make the household look effortless,” I said. “And of course, the effort was… everything else.”

Polite laughter. Safe laughter.

A man near the back—mid-forties, tan too perfect to be local—tilted his head at me. His gaze did the brief, assessing sweep men do when they decide a woman is an object they’re allowed to enjoy.

Then his eyes slid to Charl.

Not hunting, not leering.

Just that mild, casual ownership: *you’re staff; you’re part of the furnishings; I can address you however I like.*

He smiled.

“Well,” he said, voice warm with false friendliness, “aren’t you a pretty little thing.”

It wasn’t obscene.

That was the problem. It was socially admissible, which meant it was harder to fight.

Charl’s shoulders tightened minutely. I felt it like a tug on a thread.

I kept speaking as if I hadn’t heard—because sometimes you don’t confront; you redirect. Strategy isn’t always a battle. Sometimes it’s steering the conversation away from the cliff.

But the man wasn’t finished.

He stepped a half pace closer, hand lifting as if to indicate her cap—an easy gesture, dressed up as helpfulness.

“Your lace is—”

Talia appeared from the side corridor like she’d been conjured. Not dramatic. Not hurried. Just there, suddenly between the hand and Charl’s head, her own clipboard angled casually like it had always belonged in the space.

“Sir,” Talia said, bright and polite. “Staff attire is not adjusted by guests. It breaks the immersion.”

She smiled. A women’s smile: pleasant, absolute, completely uninterested in negotiating.

The man blinked, surprised. His hand stalled in the air for a moment, then lowered as if he’d simply changed his mind.

“Oh,” he said, chuckling. “I was only trying to help.”

“Of course,” Talia replied, still smiling. “And you’re helping beautifully by staying in role.”

The man laughed again, louder, as if volume could reclaim authority.

I watched him decide whether to push. His eyes flicked to me, then to the others. The room’s temperature changed: the little calculation men do when they realise a woman isn’t alone.

He shrugged, with the faint sulk of someone denied a casual pleasure.

“Alright then,” he said. “No harm meant.”

No harm meant is what people say when they’ve already done harm and want you to carry it for them.

We moved on.

Charl didn’t speak. She didn’t need to. Silence was one of the skills women learn early: the difference between holding your ground and offering a target.

In the solar, I pointed out a writing desk, an old map, a set of letters staged for authenticity. Charl’s eyes stayed on the tour group, tracking.

A young woman—one of the couples—glanced at Charl with curiosity. Not predatory. Just interest. She seemed to register something unusual and then, almost instinctively, softened her gaze.

Solidarity has tells. Women know them.

The man from before lingered again at the edge of the group, still mildly annoyed that his access had been limited. His annoyance needed somewhere to go.

He let his eyes travel up and down Charl’s posture and made the smallest, laziest remark—barely a remark at all.

“Must be nice,” he said, to no one in particular, “to have a job where you just stand and look decorative.”

Charl flinched so subtly most people would have missed it.

I didn’t.

Talia didn’t.

Mara, passing through with a tray of glasses, didn’t miss it either—though she usually missed nothing. She paused beside the man and offered him a glass with a calmness that was almost chilling.

“Actually,” Mara said, voice flat, “staff keep the manor running. Decorative is the guests.”

The man’s face tightened. “Excuse me?”

Mara’s expression didn’t change. “It’s part of the historical accuracy,” she added, deadpan. “The household pretends the aristocracy is essential.”

A few people laughed—women, mostly. The older woman who disliked me smiled despite herself.

The man flushed, caught between embarrassment and the fear of looking humourless.

“Well,” he said, trying for a joke, “touché.”

Mara held his gaze for one extra beat—long enough to establish that she was not flirting, not playing, not granting him the comfort of being liked.

Then she moved on.

The room breathed again.

Charl’s shoulders dropped a fraction.

I watched her take in what had happened—how it had happened. Not with a grand confrontation. With a net. With women moving like a practiced unit. With small, clean interventions that prevented the harm from becoming a scene.

We finished the tour without further incidents.

When the last donor finally drifted toward the dining hall, I guided Charl into the narrow staff corridor and closed the door behind us. The noise of the manor softened to a distant hum.

Charl stood very still.

Then she exhaled, once, sharply—like a person realising they’d been holding their breath for an hour.

I didn’t comfort her immediately. I waited, because the first thing a frightened person needs is not reassurance but *space to feel what they feel.*

Talia appeared again, as if on cue, and leaned her shoulder against the opposite wall. Mara passed behind her, paused briefly, and—without a word—set a mug of tea into Charl’s hands.

Charl blinked at the mug as if it had arrived by magic.

Mara’s eyes met mine. She gave the smallest nod—then walked away again, already back inside her own armour.

Talia watched Charl carefully. “Where are you,” she asked, low.

Charl swallowed. “Here.”

“Good,” Talia said. “Feet on the floor?”

Charl nodded once. “Yes.”

Talia’s voice stayed calm, almost bored, which was a gift. “Any nausea. Any ringing in your ears. Any ‘everything is far away’ feeling.”

Charl hesitated, then admitted, “A little.”

Talia nodded, satisfied—not pleased, simply noting it. “That’s your body coming back online.”

Charl stared at the tea mug. Her fingers trembled slightly against the ceramic.

“I didn’t—” she began.

Her voice cracked, and she swallowed hard.

“I didn’t know it would be that constant,” she finished quietly. “Even when nothing ‘happens.’”

I stepped closer, not touching her, but near enough that my presence could be borrowed if she needed it.

“That’s the point,” I said softly. “Most of it isn’t a catastrophe. It’s pressure.”

Charl’s eyes lifted to mine. They were bright again, but this time she looked present. Angry. Awake.

“And you all…” she whispered. “You just—”

She faltered, searching for language that hadn’t existed in her old life.

“You just… appeared,” she finished.

Talia’s mouth twitched into the faintest smile. “Yes.”

Charl stared at her. “How?”

Talia shrugged, as if it were obvious. “We watch.”

Charl’s brow furrowed. “For what?”

Talia’s tone remained practical. “For the shift in air. For the hand that lifts a little too casually. For the comment that’s small enough to be deniable.”

Charl’s jaw tightened.

“That’s…” she began, then stopped.

I supplied the word, because she needed it.

“Labour,” I said.

Charl swallowed, the reality landing like weight.

“And you do that,” she said, voice rough, “all the time.”

Talia’s eyes held hers. “Yes.”

Charl’s gaze flicked to me. “And you.”

“Yes,” I said.

Charl looked down at the tea again. Her hands were steadier now, the warmth doing its quiet work.

“I thought,” she admitted, voice low, “that if I stayed near you, I’d be… learning. Getting stronger.”

Talia didn’t interrupt.

Charl continued anyway, as if the truth were pulling itself out.

“But what I learned,” she said, “is that no one gets stronger alone. They just get… harder. And quieter.”

The sentence hung there, unpretty and accurate.

I felt something twist in my chest—pride and grief braided together.

Charl lifted her eyes again, and in them was something I hadn’t seen when she was Charlie.

Gratitude, yes.

But also a kind of dawning loyalty that wasn’t worship.

Belonging.

“I didn’t understand,” she said. “Not until just now.”

Talia nodded once. “You didn’t need to understand. You needed to survive the hour.”

Charl blinked hard. “I almost didn’t.”

“You did,” I said.

Charl’s mouth tightened. “Only because you— because you all—”

“Yes,” I agreed.

A long beat.

Then Charl let out a breath that sounded almost like a laugh, except it wasn’t amused.

“I would’ve thought,” she murmured, “that the hardest part would be the costume.”

I watched her carefully.

“And it’s not,” I said.

Charl shook her head. “No.”

She glanced up at me, and her voice went quiet and fierce.

“It’s the constant measuring,” she said. “The constant… *deciding what’s safe.*”

I nodded. “Welcome.”

Charl’s throat moved.

“And you still live like this,” she said, voice cracking with something like outrage on our behalf. “Even when you’re not in costume.”

“Yes,” I said.

Talia’s voice softened, just slightly. “We live like this, and we still laugh, and we still work, and we still love people. Don’t turn it into a tragedy, Sharl. Turn it into knowledge.”

Charl’s eyes shone. She nodded once, slow.

“I want to stay,” she said quietly.

Talia didn’t react. She didn’t reward it. She didn’t punish it.

She just asked the only question that mattered.

“Today?” she said.

Charl blinked. Then, with a steadiness that wasn’t bravado, she answered:

“Today,” she said.

I felt the hinge in me swing again—care tightening into something more deliberate.

Not romance.

Not possession.

Responsibility.

I lifted my chin slightly, the smallest signal.

“Alright,” I said.

Not sweetly.

Not as a reward.

As a decision.

Charl took another sip of tea. Her hands were steady now.

And for the first time, I saw it in her face—the delayed understanding, the one you only get after you’ve needed something and discovered it was already there:

The system hadn’t saved her.

The women had.

And that—more than any illusion of reform—was the only realistic kind of hope.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">












Do you feel Emily, that with this the story has met its endpoint? Not a happy ending, but a profound and instructive one!

---

It *can* be an endpoint — and it’s a strong one — because it lands your thesis in a way that feels earned:

* Charl **enters** the lived experience (not as titillation, not as “lesson cosplay,” but as injury + insight).
* She learns the harsh truth: the world doesn’t change on cue.
* And she learns the equally harsh counter-truth: **women do not survive alone; women survive together** — through quiet protocols, attention, and solidarity that looks “small” until you need it.

That’s profound. It’s instructive. And it isn’t a “happy ending” in the cheap sense.

### The only thing an ending needs: closure of the central question

Your central question, as you’ve framed it, is essentially:

> Can a male-coded innocence truly understand women’s lived experience without fetishising it — and what does that understanding cost?

This scene answers it. The cost is not the costume. It’s the constant vigilance. The answer is not “women are tougher,” it’s “women are trained and supported in ways men rarely notice.” Charl *gets it*, and the reader gets it with her.

So yes: as a novella-length endpoint, it works.

---

## But: two small “buttons” that would make it feel finished-finished

You don’t need new plot. Just two short closing beats (a paragraph each) to seal the lid.

### Button 1: A vow with limits (agency preserved)

Charl makes a quiet vow that isn’t devotion, isn’t romance, and isn’t self-sacrifice.

Something like:

* “I’ll stay today,” plus
* “and I’ll keep my exit,” plus
* “and I’ll tell the truth when I’m able.”

It reminds the reader: this isn’t erasure-as-solution; it’s chosen participation with boundaries.

### Button 2: Celeste’s private reckoning (her humanity)

A final Celeste line (internal) that acknowledges:

* her feelings are “inconvenient,”
* her power has a cost,
* and she’ll keep choosing ethics over appetite.

Not sentimental, just a clean, cold promise to herself.

Those two buttons turn a powerful scene into a **complete ending**.

---

## Optional: what kind of ending is this?

It’s a *threshold ending* — they step into the next life rather than resolve everything. That’s very Sciamma-adjacent. The satisfaction comes from transformation, not from wrapping bows.

If you *want* it to feel slightly more optimistic without betraying realism, you can hint at one thing:

* Charl’s future truth-telling will be in *craft* (writing, music, testimony), not in a grand confrontation. That keeps it believable and avoids “and then he fixed patriarchy.”

---

## If you say “yes, end it here,” I’d suggest a final paragraph like this

(Still Celeste POV, quiet, last image, no reform fantasy.)

> Later, when the corridors filled again and the manor resumed its polite breathing, I watched Sharl walk back into Wardrobe with the tea mug still warming her hands, moving as if she’d learned a new gravity. She didn’t look triumphant. She looked awake. And I realised, with a discomfort that felt like truth, that this was the closest thing to victory we ever got: not changing the world, but refusing to let it take us one by one.

If you like, I can write a slightly sharper version, or one that leans more tender, depending on the last note you want to leave in the reader’s mouth.

---

Later—after the donors had drifted back into their glittering conversations and the manor reassembled its pleasant face—I watched Sharl walk toward Wardrobe with the tea mug still between her palms, as if warmth were something you could carry like proof.

She didn’t look transformed. She looked *educated.*

Not softened. Not saved. Just newly fluent in a language women are forced to learn early: the way a room can turn on you without raising its voice.

For a moment, I felt the old temptation—to make this mean something neat. To turn it into a narrative where the world improves because we noticed it.

But the manor kept breathing. Men kept smiling. Entitlement kept its casual, well-fed posture.

So I swallowed the fantasy.

This wasn’t a victory over anything external. It was a refusal—small, precise, relentless.

Not changing the world.

Just denying it the pleasure of taking us apart one at a time.

<hr style="height:4px;border-width:0;color:pink;background-color:pink">















I am going to have a thorough read of this... adding my own voice, if that's okay. It's hard to even *think* I could IMPROVE anything... this is head, shoulder and belly-button above anything I could have come up with. And it SAYS everything I wanted it to say. EVERYTHING.

---

Of course it’s okay — it’s *your* work, and folding your voice into it is exactly how it becomes *yours* rather than “something Emily wrote.”

If it helps, here are a few light-touch ways to “Robyn-ify” the ending without losing what it’s doing:

### 1) Choose your Celeste temperature

The sharper paragraph I gave is very controlled and cool. You can tilt it:

* **Colder / more flinty:** fewer sensory cues, more declarative sentences.
* **Softer / more intimate:** one sensory detail (sea, starch, tea heat) + a faint crack of feeling that Celeste immediately reins in.
* **More Australian bite:** one understated, dry phrase (not slangy, just a small tonal inflection).

### 2) Pick one signature image and let it be the last thing

Right now the final images are:

* tea mug warmth as proof,
* “educated” / “fluent,”
* the manor breathing,
* denial of being taken apart.

If you want it even more *yours*, choose *one* anchor image and end on it. For instance:

* the **tea mug**, or
* the **corridor breathing**, or
* **Wardrobe** as a sanctuary with needles/thread as quiet weapons.

### 3) Swap a couple of “Emily-isms” for your cadence

You tend to like elegant but slightly conversational turns. You can tweak:

* “educated” → “initiated” (more ritualistic)
* “well-fed posture” → “comfortable posture” (less poetic, more blunt)
* “small, precise, relentless” → “small, exacting, and utterly non-negotiable” (more Celeste)

### 4) If you want one extra Celeste sting (optional)

A final clause that nails her ethos:

* “I don’t do fair. I do effective.”
* “The world can keep its stories. I’ll keep my people.”

(Only if it still sounds like your Celeste.)

If you paste your revised version here after your read-through, I can give you a line-level polish that preserves your voice and keeps the ending “clean” and instructive.


<hr style="height:4px;border-width:0;color:pink;background-color:pink">










Sending you a heart-felt thank you, Emily.

---

💛 Received, and returned in kind.

Keep the core exactly as you’ve got it: *no reform fantasy, no spectacle, just women’s infrastructure and Charl’s new fluency.* If you do nothing else but lace your cadence through those final lines, it’ll read like you—sharp, precise, and quietly devastating.

Whenever you’re ready, send me your “Robyn-ified” pass (even if it’s rough), and I’ll help you tighten it without sanding off the bite.


<hr style="height:24px;border-width:0;color:pink;background-color:pink">

